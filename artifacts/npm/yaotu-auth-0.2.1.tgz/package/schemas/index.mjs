// src/schemas/signin.ts
import { z } from "zod";
var signInSchema = z.object({
  username: z.string().trim().min(1, "Username or email is required"),
  password: z.string().min(1, "Password is required")
});

// src/schemas/signup.ts
import { z as z2 } from "zod";
var usernameSchema = z2.string().trim().regex(/^[a-z0-9]+$/, "Username must contain only lowercase letters and numbers").min(3, "Username must be at least 3 characters").max(32, "Username must be at most 32 characters");
var signUpSchema = z2.object({
  email: z2.string().trim().email("Enter a valid email address"),
  signupIntentToken: z2.string().trim().min(32).max(256).optional(),
  signupConsumer: z2.enum(["main", "guide"]).optional()
}).strict();
var passwordSchema = z2.string().min(8, "Password must be at least 8 characters").max(128, "Password must be at most 128 characters").refine(
  (value) => new TextEncoder().encode(value).length <= 256,
  "Password must be at most 256 bytes"
);
var completeSignUpSchema = z2.object({
  completionToken: z2.string().trim().regex(/^[a-f0-9]{64}$/, "Invalid token"),
  username: usernameSchema,
  password: passwordSchema,
  confirmPassword: z2.string(),
  fullName: z2.string().trim().min(1, "Full name is required").max(100)
}).strict().superRefine((value, context) => {
  if (value.password !== value.confirmPassword) {
    context.addIssue({
      code: z2.ZodIssueCode.custom,
      path: ["confirmPassword"],
      message: "Passwords do not match"
    });
  }
});

// src/schemas/password-reset.ts
import { z as z3 } from "zod";
var forgotPasswordSchema = z3.object({
  email: z3.string().trim().email("Enter a valid email address")
});
var resetTokenSchema = z3.object({
  token: z3.string().trim().min(1, "Reset token is required")
});
var resetPasswordSchema = z3.object({
  token: z3.string().trim().min(1, "Reset token is required"),
  newPassword: z3.string().min(6, "Password must be at least 6 characters")
});

// src/schemas/email-verification.ts
import { z as z4 } from "zod";
var requestEmailVerificationSchema = z4.object({
  identifier: z4.string().trim().min(1, "Username or email is required").max(320),
  flow: z4.literal("guide_signup").optional(),
  signupConsumer: z4.enum(["main", "guide"]).optional()
}).strict();
var verifyEmailSchema = z4.object({
  token: z4.string().trim().regex(/^[a-f0-9]{64}$/, "Invalid token"),
  confirmation: z4.literal(true)
}).strict();
export {
  completeSignUpSchema,
  forgotPasswordSchema,
  requestEmailVerificationSchema,
  resetPasswordSchema,
  resetTokenSchema,
  signInSchema,
  signUpSchema,
  usernameSchema,
  verifyEmailSchema
};
//# sourceMappingURL=index.mjs.map