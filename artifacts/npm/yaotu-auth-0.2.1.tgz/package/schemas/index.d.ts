import { z } from 'zod';

declare const signInSchema: z.ZodObject<{
    username: z.ZodString;
    password: z.ZodString;
}, "strip", z.ZodTypeAny, {
    username: string;
    password: string;
}, {
    username: string;
    password: string;
}>;
type SignInSchemaInput = z.input<typeof signInSchema>;
type SignInSchemaOutput = z.output<typeof signInSchema>;

declare const usernameSchema: z.ZodString;
declare const signUpSchema: z.ZodObject<{
    email: z.ZodString;
    signupIntentToken: z.ZodOptional<z.ZodString>;
    signupConsumer: z.ZodOptional<z.ZodEnum<["main", "guide"]>>;
}, "strict", z.ZodTypeAny, {
    email: string;
    signupIntentToken?: string | undefined;
    signupConsumer?: "guide" | "main" | undefined;
}, {
    email: string;
    signupIntentToken?: string | undefined;
    signupConsumer?: "guide" | "main" | undefined;
}>;
declare const completeSignUpSchema: z.ZodEffects<z.ZodObject<{
    completionToken: z.ZodString;
    username: z.ZodString;
    password: z.ZodEffects<z.ZodString, string, string>;
    confirmPassword: z.ZodString;
    fullName: z.ZodString;
}, "strict", z.ZodTypeAny, {
    username: string;
    password: string;
    completionToken: string;
    confirmPassword: string;
    fullName: string;
}, {
    username: string;
    password: string;
    completionToken: string;
    confirmPassword: string;
    fullName: string;
}>, {
    username: string;
    password: string;
    completionToken: string;
    confirmPassword: string;
    fullName: string;
}, {
    username: string;
    password: string;
    completionToken: string;
    confirmPassword: string;
    fullName: string;
}>;
type SignUpSchemaInput = z.input<typeof signUpSchema>;
type SignUpSchemaOutput = z.output<typeof signUpSchema>;
type CompleteSignUpSchemaInput = z.input<typeof completeSignUpSchema>;
type CompleteSignUpSchemaOutput = z.output<typeof completeSignUpSchema>;

declare const forgotPasswordSchema: z.ZodObject<{
    email: z.ZodString;
}, "strip", z.ZodTypeAny, {
    email: string;
}, {
    email: string;
}>;
declare const resetTokenSchema: z.ZodObject<{
    token: z.ZodString;
}, "strip", z.ZodTypeAny, {
    token: string;
}, {
    token: string;
}>;
declare const resetPasswordSchema: z.ZodObject<{
    token: z.ZodString;
    newPassword: z.ZodString;
}, "strip", z.ZodTypeAny, {
    token: string;
    newPassword: string;
}, {
    token: string;
    newPassword: string;
}>;
type ForgotPasswordSchemaInput = z.input<typeof forgotPasswordSchema>;
type ResetTokenSchemaInput = z.input<typeof resetTokenSchema>;
type ResetPasswordSchemaInput = z.input<typeof resetPasswordSchema>;

declare const requestEmailVerificationSchema: z.ZodObject<{
    identifier: z.ZodString;
    flow: z.ZodOptional<z.ZodLiteral<"guide_signup">>;
    signupConsumer: z.ZodOptional<z.ZodEnum<["main", "guide"]>>;
}, "strict", z.ZodTypeAny, {
    identifier: string;
    signupConsumer?: "guide" | "main" | undefined;
    flow?: "guide_signup" | undefined;
}, {
    identifier: string;
    signupConsumer?: "guide" | "main" | undefined;
    flow?: "guide_signup" | undefined;
}>;
declare const verifyEmailSchema: z.ZodObject<{
    token: z.ZodString;
    confirmation: z.ZodLiteral<true>;
}, "strict", z.ZodTypeAny, {
    token: string;
    confirmation: true;
}, {
    token: string;
    confirmation: true;
}>;
type RequestEmailVerificationSchemaInput = z.input<typeof requestEmailVerificationSchema>;
type VerifyEmailSchemaInput = z.input<typeof verifyEmailSchema>;

export { type CompleteSignUpSchemaInput, type CompleteSignUpSchemaOutput, type ForgotPasswordSchemaInput, type RequestEmailVerificationSchemaInput, type ResetPasswordSchemaInput, type ResetTokenSchemaInput, type SignInSchemaInput, type SignInSchemaOutput, type SignUpSchemaInput, type SignUpSchemaOutput, type VerifyEmailSchemaInput, completeSignUpSchema, forgotPasswordSchema, requestEmailVerificationSchema, resetPasswordSchema, resetTokenSchema, signInSchema, signUpSchema, usernameSchema, verifyEmailSchema };
