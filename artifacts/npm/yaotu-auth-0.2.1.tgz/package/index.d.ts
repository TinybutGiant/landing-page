import { AuthApiClientOptions, AuthApiClient, AuthContinuationFlow, SignInSuccess, AuthResultContext, SignUpVerificationRequiredResult, SignInRequest, SignUpRequest, CompleteSignUpRequest, CompleteSignUpResult, UsernameAvailabilityResult, ForgotPasswordRequest, ForgotPasswordResult, ValidateResetTokenRequest, ValidateResetTokenResult, ResetPasswordRequest, ResetPasswordResult, RequestEmailVerificationRequest, RequestEmailVerificationResult, VerifyEmailRequest, VerifyEmailResult, AuthFetcher } from './api/index.js';
export { AuthCanonicalError, AuthCanonicalErrorCode, AuthError, AuthInputError, AuthUserGuideStatus, AuthUserRole, AuthValidationError, AuthenticatedUser, BACKEND_AUTH_ERROR_CODE_MAP, createAuthApiClient, isAuthError, isAuthInputError, mapBackendAuthError, throwAuthError, validationErrorToAuthValidationError } from './api/index.js';
export { CompleteSignUpSchemaInput, CompleteSignUpSchemaOutput, ForgotPasswordSchemaInput, RequestEmailVerificationSchemaInput, ResetPasswordSchemaInput, ResetTokenSchemaInput, SignInSchemaInput, SignInSchemaOutput, SignUpSchemaInput, SignUpSchemaOutput, VerifyEmailSchemaInput, completeSignUpSchema, forgotPasswordSchema, requestEmailVerificationSchema, resetPasswordSchema, resetTokenSchema, signInSchema, signUpSchema, usernameSchema, verifyEmailSchema } from './schemas/index.js';
import * as react from 'react';
import { ComponentType, ReactNode, HTMLAttributes } from 'react';
import * as react_jsx_runtime from 'react/jsx-runtime';
import 'zod';

type AuthLocale = 'en' | 'zh-CN' | 'ja';
type AuthMessageValue = string | AuthMessageTree;
interface AuthMessageTree {
    [key: string]: AuthMessageValue;
}
declare const authMessages: {
    en: {
        loginTitle: string;
        signupTitle: string;
        createAccount: string;
        continue: string;
        signupContinuing: string;
        surfStageLabel: string;
        pickMascot: string;
        mbtiStageLabel: string;
        mascot: {
            diplomat: string;
            entertainer: string;
            logician: string;
            protector: string;
            explorer: string;
            lantern: string;
            unknown: string;
        };
        surf: {
            asakusa: string;
            fuji: string;
            torii: string;
            tokyo: string;
            yokocho: string;
            fujiden: string;
        };
        username: string;
        usernamePlaceholder: string;
        email: string;
        emailPlaceholder: string;
        password: string;
        passwordPlaceholder: string;
        confirmPassword: string;
        confirmPasswordPlaceholder: string;
        forgotPassword: string;
        dontHaveAccount: string;
        alreadyHaveAccount: string;
        loginButton: string;
        signupButton: string;
        signingIn: string;
        signingUp: string;
        firstName: string;
        firstNamePlaceholder: string;
        lastName: string;
        lastNamePlaceholder: string;
        checkingUsername: string;
        suggested: string;
        passwordHint: string;
        emailUpdates: string;
        signupUnexpectedError: string;
        usernameChoosePlaceholder: string;
        usernameHelperText: string;
        passwordCreatePlaceholder: string;
        passwordStrength: {
            weak: string;
            medium: string;
            strong: string;
        };
        error: {
            title: string;
            fillAllFields: string;
            fillName: string;
            passwordTooShort: string;
            passwordMismatch: string;
            agreeTerms: string;
        };
        terms: {
            agreePrefix: string;
            termsOfService: string;
            and: string;
            privacyPolicy: string;
        };
        toast: {
            error: string;
            fillAllFields: string;
            loginSuccessTitle: string;
            loginSuccessDescription: string;
            loginFailedTitle: string;
            loginFailedDescription: string;
            signupSuccessTitle: string;
            signupVerificationRequiredDescription: string;
        };
        usernameValidation: {
            invalidFormat: string;
            taken: string;
            errorChecking: string;
        };
        emailVerification: {
            title: string;
            description: string;
            privacyNote: string;
            existingAccount: string;
            signIn: string;
            confirmPrompt: string;
            confirm: string;
            retryPrompt: string;
            tryAgain: string;
            verifying: string;
            success: string;
            invalidOrExpired: string;
            requestAnother: string;
            sent: string;
            requestReceived: string;
            resendPrompt: string;
            identifierRequired: string;
            identifierLabel: string;
            identifierHelp: string;
            destination: string;
            requestFailed: string;
            resend: string;
        };
        completeSignup: {
            title: string;
            body: string;
            submit: string;
            submitting: string;
            failed: string;
            invalidOrExpired: string;
            expiredTitle: string;
            expiredBody: string;
        };
        rateLimit: {
            title: string;
            retryIn: string;
            retryLater: string;
            unavailableTitle: string;
            unavailable: string;
        };
        forgotPasswordPage: {
            title: string;
            description: string;
            enterEmail: string;
            invalidEmail: string;
            emailSent: string;
            emailSentDesc: string;
            checkEmailDesc: string;
            sendFailed: string;
            sendFailedDesc: string;
            notReceived: string;
            resend: string;
            backToLogin: string;
            sending: string;
            sendLink: string;
        };
        resetPassword: {
            title: string;
            subtitle: string;
            linkInvalid: string;
            linkExpired: string;
            passwordMinLength: string;
            resetSuccess: string;
            resetSuccessDesc: string;
            resetFailed: string;
            resetFailedDesc: string;
            newPassword: string;
            newPasswordPlaceholder: string;
            confirmNewPassword: string;
            confirmNewPasswordPlaceholder: string;
            resetting: string;
            resetButton: string;
            backToLogin: string;
            reapplyButton: string;
        };
    };
    'zh-CN': {
        rateLimit: {
            title: string;
            retryIn: string;
            retryLater: string;
            unavailableTitle: string;
            unavailable: string;
        };
    };
    ja: {
        rateLimit: {
            title: string;
            retryIn: string;
            retryLater: string;
            unavailableTitle: string;
            unavailable: string;
        };
    };
};
declare function resolveAuthMessage(key: string, locale?: AuthLocale, overrides?: AuthMessageTree, values?: Record<string, string | number | null | undefined>, defaultMessage?: string): string;

type AuthToastVariant = 'default' | 'success' | 'destructive';
type AuthToast = {
    title: string;
    description?: string;
    variant?: AuthToastVariant;
};
type AuthLinkProps = {
    href: string;
    className?: string;
    children: ReactNode;
    'data-testid'?: string;
};
type AuthRuntimeConfig = AuthApiClientOptions & {
    apiClient?: AuthApiClient;
    locale?: AuthLocale;
    messages?: AuthMessageTree;
    t?: (key: string, values?: Record<string, string | number | null | undefined>, defaultMessage?: string) => string;
    navigate?: (href: string) => void;
    LinkComponent?: ComponentType<AuthLinkProps>;
    toast?: (toast: AuthToast) => void;
    darkMode?: boolean;
    flow?: AuthContinuationFlow | null;
    onAuthenticated?: (result: SignInSuccess, context: AuthResultContext) => void | Promise<void>;
    onSignupVerificationRequired?: (result: SignUpVerificationRequiredResult, context: AuthResultContext) => void | Promise<void>;
};

declare function AuthRuntimeProvider({ config, children, }: {
    config?: AuthRuntimeConfig;
    children: ReactNode;
}): react_jsx_runtime.JSX.Element;
declare function useAuthRuntime(overrides?: AuthRuntimeConfig): {
    apiClient: {
        signIn(input: SignInRequest): Promise<SignInSuccess>;
        signUp(input: SignUpRequest): Promise<SignUpVerificationRequiredResult>;
        completeSignUp(input: CompleteSignUpRequest): Promise<CompleteSignUpResult>;
        checkUsernameAvailability(username: string): Promise<UsernameAvailabilityResult>;
        forgotPassword(input: ForgotPasswordRequest): Promise<ForgotPasswordResult>;
        validateResetToken(input: ValidateResetTokenRequest): Promise<ValidateResetTokenResult>;
        resetPassword(input: ResetPasswordRequest): Promise<ResetPasswordResult>;
        requestEmailVerification(input: RequestEmailVerificationRequest): Promise<RequestEmailVerificationResult>;
        verifyEmail(input: VerifyEmailRequest): Promise<VerifyEmailResult>;
    };
    t: (key: string, values?: Record<string, string | number | null | undefined>, defaultMessage?: string) => string;
    apiBaseUrl?: string;
    fetcher?: AuthFetcher;
    locale?: AuthLocale;
    messages?: AuthMessageTree;
    navigate?: (href: string) => void;
    LinkComponent?: react.ComponentType<AuthLinkProps>;
    toast?: (toast: AuthToast) => void;
    darkMode?: boolean;
    flow?: AuthContinuationFlow | null;
    onAuthenticated?: (result: SignInSuccess, context: AuthResultContext) => void | Promise<void>;
    onSignupVerificationRequired?: (result: SignUpVerificationRequiredResult, context: AuthResultContext) => void | Promise<void>;
};
declare function AuthLink({ href, className, children, LinkComponent, ...props }: AuthLinkProps & {
    LinkComponent?: AuthRuntimeConfig['LinkComponent'];
}): react_jsx_runtime.JSX.Element;
declare function AuthRoot({ darkMode, className, ...props }: HTMLAttributes<HTMLDivElement> & {
    darkMode?: boolean;
}): react_jsx_runtime.JSX.Element;

type SignInFormProps = AuthRuntimeConfig & {
    className?: string;
    redirectTo?: string | null;
    signUpPath?: string;
    forgotPasswordPath?: string;
    defaultRedirectPath?: string;
    guideRedirectPath?: string;
    readRedirectParam?: boolean;
    signupPromptSlot?: ReactNode;
    onEmailVerificationRequired?: (error: unknown, context: {
        identifier: string;
    }) => void;
};
declare function SignInForm({ className, redirectTo, signUpPath, forgotPasswordPath, defaultRedirectPath, guideRedirectPath, readRedirectParam, signupPromptSlot, onEmailVerificationRequired, ...runtimeOverrides }: SignInFormProps): react_jsx_runtime.JSX.Element;

type SignUpFormProps = AuthRuntimeConfig & {
    className?: string;
    redirectTo?: string | null;
    loginPath?: string;
    verifyEmailPath?: string;
    termsPath?: string;
    privacyPath?: string;
    readRedirectParam?: boolean;
    signupIntentToken?: string | null;
    signupConsumer?: 'main' | 'guide';
    resolveVerifyEmailPath?: (basePath: string, submittedEmail: string) => string;
};
declare function SignUpForm({ className, redirectTo, loginPath, verifyEmailPath, readRedirectParam, signupIntentToken, signupConsumer, resolveVerifyEmailPath, ...runtimeOverrides }: SignUpFormProps): react_jsx_runtime.JSX.Element;

type CompleteSignUpFormProps = AuthRuntimeConfig & {
    completionToken: string;
    className?: string;
    loginPath?: string;
    verifyEmailPath?: string;
    termsPath?: string;
    privacyPath?: string;
    onCompleted?: (result: CompleteSignUpResult) => void | Promise<void>;
    onCompletionUnavailable?: () => void;
};
declare function CompleteSignUpForm({ completionToken, className, loginPath, verifyEmailPath, termsPath, privacyPath, onCompleted, onCompletionUnavailable, ...runtimeOverrides }: CompleteSignUpFormProps): react_jsx_runtime.JSX.Element;

type ForgotPasswordFormProps = AuthRuntimeConfig & {
    className?: string;
    loginPath?: string;
};
declare function ForgotPasswordForm({ className, loginPath, ...runtimeOverrides }: ForgotPasswordFormProps): react_jsx_runtime.JSX.Element;

type ResetPasswordFormProps = AuthRuntimeConfig & {
    className?: string;
    token?: string;
    loginPath?: string;
    forgotPasswordPath?: string;
    autoRedirectMs?: number | null;
};
declare function ResetPasswordForm({ className, token: tokenProp, loginPath, forgotPasswordPath, autoRedirectMs, ...runtimeOverrides }: ResetPasswordFormProps): react_jsx_runtime.JSX.Element;

type EmailVerificationNoticeProps = AuthRuntimeConfig & {
    className?: string;
    token?: string;
    sentFromSignup?: boolean;
    initialIdentifier?: string;
    verificationDestination?: string;
    loginPath?: string;
    requestFlow?: 'guide_signup';
    signupConsumer?: 'main' | 'guide';
    clearTokenFromUrl?: boolean;
    onVerified?: (result: VerifyEmailResult) => void | Promise<void>;
    onRequestSent?: (identifier: string) => void | Promise<void>;
};
declare function EmailVerificationNotice({ className, token: tokenProp, sentFromSignup, initialIdentifier, verificationDestination, loginPath, requestFlow, signupConsumer, clearTokenFromUrl, onVerified, onRequestSent, ...runtimeOverrides }: EmailVerificationNoticeProps): react_jsx_runtime.JSX.Element;

type LoginMascotId = 'diplomat' | 'entertainer' | 'logician' | 'protector' | 'explorer' | 'lantern';
declare const LOGIN_MASCOT_COLOR_PICKER_IDS: readonly ["logician", "protector", "entertainer", "diplomat"];
type LoginMascotColorPickerId = (typeof LOGIN_MASCOT_COLOR_PICKER_IDS)[number];
declare const LOGIN_MASCOT_UNKNOWN_ID: "unknown";
type LoginMascotUnknownId = typeof LOGIN_MASCOT_UNKNOWN_ID;
type LoginMascotPickerOptionId = LoginMascotColorPickerId | LoginMascotUnknownId;
declare const LOGIN_MASCOT_PICKER_OPTION_IDS: readonly ["logician", "protector", "entertainer", "diplomat", "unknown"];
type LoginMascotTheme = {
    glow: string;
    ring: string;
    button: string;
    buttonHover: string;
    buttonShadow: string;
    focusRing: string;
};
declare const UNKNOWN_MASCOT_THEME: LoginMascotTheme;
declare const UNKNOWN_MASCOT_AVATAR_IMAGE_VAR = "var(--yt-auth-mbti-avatar-unknown)";
declare function isLoginMascotPickerOptionId(value: string | null | undefined): value is LoginMascotPickerOptionId;
type LoginMascotDef = {
    id: LoginMascotId;
    imageVar: string;
    nameKey: string;
    mbtiCode: string;
    theme: LoginMascotTheme;
    float: {
        y: number;
        duration: number;
    };
};
declare const LOGIN_MASCOT_STORAGE_KEY = "lg-login-mascot";
declare const LOGIN_MASCOTS: LoginMascotDef[];
declare const DEFAULT_LOGIN_MASCOT_ID: LoginMascotId;
declare function getLoginMascot(id: LoginMascotId): LoginMascotDef;
declare function isLoginMascotId(value: string | null | undefined): value is LoginMascotId;
declare function readStoredLoginMascotId(): LoginMascotId;
declare function storeLoginMascotId(id: LoginMascotId): void;
declare const MASCOT_ACCENTS: Record<LoginMascotId, string>;

type SurfPlaneDef = {
    id: string;
    imageVar: string;
    nameKey: string;
    accent: string;
};
declare const SURF_PLANES: SurfPlaneDef[];

declare function validateUsername(username: string): boolean;
type PasswordStrength = {
    score: number;
    labelKey: 'passwordStrength.weak' | 'passwordStrength.medium' | 'passwordStrength.strong' | '';
    color: string;
};
declare function calculatePasswordStrength(password: string): PasswordStrength;

export { AuthApiClient, AuthApiClientOptions, AuthContinuationFlow, AuthFetcher, AuthLink, type AuthLinkProps, type AuthLocale, type AuthMessageTree, type AuthMessageValue, AuthResultContext, AuthRoot, type AuthRuntimeConfig, AuthRuntimeProvider, type AuthToast, type AuthToastVariant, CompleteSignUpForm, type CompleteSignUpFormProps, CompleteSignUpRequest, CompleteSignUpResult, DEFAULT_LOGIN_MASCOT_ID, EmailVerificationNotice, type EmailVerificationNoticeProps, ForgotPasswordForm, type ForgotPasswordFormProps, ForgotPasswordRequest, ForgotPasswordResult, LOGIN_MASCOTS, LOGIN_MASCOT_COLOR_PICKER_IDS, LOGIN_MASCOT_PICKER_OPTION_IDS, LOGIN_MASCOT_STORAGE_KEY, LOGIN_MASCOT_UNKNOWN_ID, type LoginMascotColorPickerId, type LoginMascotDef, type LoginMascotId, type LoginMascotPickerOptionId, type LoginMascotTheme, type LoginMascotUnknownId, MASCOT_ACCENTS, RequestEmailVerificationRequest, RequestEmailVerificationResult, ResetPasswordForm, type ResetPasswordFormProps, ResetPasswordRequest, ResetPasswordResult, SURF_PLANES, SignInForm, type SignInFormProps, SignInRequest, SignInSuccess, SignUpForm, type SignUpFormProps, SignUpRequest, SignUpVerificationRequiredResult, type SurfPlaneDef, UNKNOWN_MASCOT_AVATAR_IMAGE_VAR, UNKNOWN_MASCOT_THEME, UsernameAvailabilityResult, ValidateResetTokenRequest, ValidateResetTokenResult, VerifyEmailRequest, VerifyEmailResult, authMessages, calculatePasswordStrength, getLoginMascot, isLoginMascotId, isLoginMascotPickerOptionId, readStoredLoginMascotId, resolveAuthMessage, storeLoginMascotId, useAuthRuntime, validateUsername };
