// src/api/errors.ts
var AuthError = class extends Error {
  constructor(error) {
    super(error.message);
    this.name = "AuthError";
    this.code = error.code;
    this.status = error.status;
    this.backendCode = error.backendCode;
    this.verificationRequired = error.verificationRequired;
    this.verificationEmailMasked = error.verificationEmailMasked;
    this.retryAfterSeconds = error.retryAfterSeconds;
    this.details = error.details;
  }
};
var AuthInputError = class extends Error {
  constructor(error) {
    super("Validation failed");
    this.code = "VALIDATION_ERROR";
    this.name = "AuthInputError";
    this.fields = error.fields;
  }
};
var BACKEND_AUTH_ERROR_CODE_MAP = {
  email_verification_required: "EMAIL_VERIFICATION_REQUIRED",
  USERNAME_TAKEN: "USERNAME_TAKEN",
  PUBLIC_SIGNUP_CLOSED: "PUBLIC_SIGNUP_CLOSED",
  SIGNUP_INTENT_INVALID: "SIGNUP_INTENT_INVALID",
  INVALID_OR_EXPIRED_TOKEN: "INVALID_OR_EXPIRED_TOKEN"
};
function validationErrorToAuthValidationError(error) {
  const fields = {};
  const issues = error && typeof error === "object" && Array.isArray(error.issues) ? error.issues : [];
  for (const issue of issues) {
    const path = Array.isArray(issue.path) ? issue.path.map(String).join(".") : "";
    const key = path || "_form";
    fields[key] ?? (fields[key] = typeof issue.message === "string" ? issue.message : "Invalid value");
  }
  return { code: "VALIDATION_ERROR", fields: Object.keys(fields).length ? fields : { _form: "Invalid input" } };
}
function mapBackendAuthError(status, body) {
  const payload = body && typeof body === "object" ? body : {};
  const backendCode = typeof payload.code === "string" ? payload.code : void 0;
  const canonicalCode = backendCode && backendCode in BACKEND_AUTH_ERROR_CODE_MAP ? BACKEND_AUTH_ERROR_CODE_MAP[backendCode] : void 0;
  const message = typeof payload.message === "string" ? payload.message : typeof payload.error === "string" ? payload.error : "Authentication request failed";
  if (canonicalCode === "EMAIL_VERIFICATION_REQUIRED") {
    return {
      code: canonicalCode,
      message,
      status,
      backendCode,
      verificationRequired: payload.verificationRequired === true,
      verificationEmailMasked: typeof payload.verificationEmailMasked === "string" ? payload.verificationEmailMasked : null
    };
  }
  if (status === 401) {
    return { code: "INVALID_CREDENTIALS", message, status, backendCode };
  }
  if (status === 429) {
    const retryAfterSeconds = typeof payload.retryAfterSeconds === "number" && payload.retryAfterSeconds > 0 ? payload.retryAfterSeconds : void 0;
    return {
      code: "RATE_LIMITED",
      message,
      status,
      backendCode,
      ...retryAfterSeconds === void 0 ? {} : { retryAfterSeconds }
    };
  }
  if (status === 503) {
    return { code: "SERVICE_UNAVAILABLE", message, status, backendCode };
  }
  if (status === 400 && /username/i.test(message) && /exists|taken/i.test(message)) {
    return { code: "USERNAME_TAKEN", message, status, backendCode };
  }
  if (status === 400 && /invalid|expired/i.test(message) && /token|link/i.test(message)) {
    return { code: "INVALID_OR_EXPIRED_TOKEN", message, status, backendCode };
  }
  if (canonicalCode === "PUBLIC_SIGNUP_CLOSED" || canonicalCode === "SIGNUP_INTENT_INVALID" || canonicalCode === "INVALID_OR_EXPIRED_TOKEN") {
    return { code: canonicalCode, message, status, backendCode, details: body };
  }
  return { code: "REQUEST_FAILED", message, status, backendCode, details: body };
}
function throwAuthError(error) {
  if (error.code === "VALIDATION_ERROR") {
    throw new AuthInputError(error);
  }
  throw new AuthError(error);
}
function isAuthError(error, code) {
  if (!(error instanceof AuthError)) return false;
  return code ? error.code === code : true;
}
function isAuthInputError(error) {
  return error instanceof AuthInputError;
}

// src/schemas/signin.ts
import { z } from "zod";
var signInSchema = z.object({
  username: z.string().trim().min(1, "Username or email is required"),
  password: z.string().min(1, "Password is required")
});

// src/schemas/signup.ts
import { z as z2 } from "zod";
var usernameSchema = z2.string().trim().regex(/^[a-z0-9]+$/, "Username must contain only lowercase letters and numbers").min(3, "Username must be at least 3 characters").max(32, "Username must be at most 32 characters");
var signUpSchema = z2.object({
  email: z2.string().trim().email("Enter a valid email address"),
  signupIntentToken: z2.string().trim().min(32).max(256).optional(),
  signupConsumer: z2.enum(["main", "guide"]).optional()
}).strict();
var passwordSchema = z2.string().min(8, "Password must be at least 8 characters").max(128, "Password must be at most 128 characters").refine(
  (value) => new TextEncoder().encode(value).length <= 256,
  "Password must be at most 256 bytes"
);
var completeSignUpSchema = z2.object({
  completionToken: z2.string().trim().regex(/^[a-f0-9]{64}$/, "Invalid token"),
  username: usernameSchema,
  password: passwordSchema,
  confirmPassword: z2.string(),
  fullName: z2.string().trim().min(1, "Full name is required").max(100)
}).strict().superRefine((value, context) => {
  if (value.password !== value.confirmPassword) {
    context.addIssue({
      code: z2.ZodIssueCode.custom,
      path: ["confirmPassword"],
      message: "Passwords do not match"
    });
  }
});

// src/schemas/password-reset.ts
import { z as z3 } from "zod";
var forgotPasswordSchema = z3.object({
  email: z3.string().trim().email("Enter a valid email address")
});
var resetTokenSchema = z3.object({
  token: z3.string().trim().min(1, "Reset token is required")
});
var resetPasswordSchema = z3.object({
  token: z3.string().trim().min(1, "Reset token is required"),
  newPassword: z3.string().min(6, "Password must be at least 6 characters")
});

// src/schemas/email-verification.ts
import { z as z4 } from "zod";
var requestEmailVerificationSchema = z4.object({
  identifier: z4.string().trim().min(1, "Username or email is required").max(320),
  flow: z4.literal("guide_signup").optional(),
  signupConsumer: z4.enum(["main", "guide"]).optional()
}).strict();
var verifyEmailSchema = z4.object({
  token: z4.string().trim().regex(/^[a-f0-9]{64}$/, "Invalid token"),
  confirmation: z4.literal(true)
}).strict();

// src/api/client.ts
function resolveUrl(apiBaseUrl, path) {
  if (!apiBaseUrl) return path;
  return `${apiBaseUrl.replace(/\/+$/, "")}/${path.replace(/^\/+/, "")}`;
}
async function readResponseBody(response) {
  const contentType = response.headers.get("content-type") ?? "";
  if (contentType.includes("application/json")) {
    return response.json().catch(() => null);
  }
  return response.text().catch(() => null);
}
function parseWithSchema(schema, input) {
  const parsed = schema.safeParse(input);
  if (parsed.success) return parsed.data;
  throwAuthError(validationErrorToAuthValidationError(parsed.error));
}
function createAuthApiClient(options = {}) {
  const fetcher = options.fetcher ?? globalThis.fetch.bind(globalThis);
  async function request(path, init) {
    const response = await fetcher(resolveUrl(options.apiBaseUrl, path), {
      ...init,
      headers: {
        "Content-Type": "application/json",
        ...init.headers
      }
    });
    const body = await readResponseBody(response);
    if (!response.ok) {
      throwAuthError(mapBackendAuthError(response.status, body));
    }
    return body;
  }
  return {
    async signIn(input) {
      const payload = parseWithSchema(signInSchema, input);
      const result = await request("/api/auth/login", {
        method: "POST",
        body: JSON.stringify(payload)
      });
      if (!result || typeof result.token !== "string" || !result.id) {
        throwAuthError({
          code: "UNEXPECTED_RESPONSE",
          message: "Login response did not include an authenticated session."
        });
      }
      return result;
    },
    async signUp(input) {
      const payload = parseWithSchema(signUpSchema, input);
      const result = await request("/api/auth/signup", {
        method: "POST",
        body: JSON.stringify(payload)
      });
      const resultRecord = result && typeof result === "object" ? result : null;
      const allowedKeys = /* @__PURE__ */ new Set(["success", "verificationRequired", "message"]);
      if (!resultRecord || resultRecord.success !== true || resultRecord.verificationRequired !== true || typeof resultRecord.message !== "string" || Object.keys(resultRecord).some((key) => !allowedKeys.has(key))) {
        throwAuthError({
          code: "UNEXPECTED_RESPONSE",
          message: "Signup response must be the generic accepted result without account metadata or an auth token.",
          details: result
        });
      }
      return resultRecord;
    },
    async completeSignUp(input) {
      const payload = parseWithSchema(completeSignUpSchema, input);
      const result = await request("/api/auth/signup/complete", {
        method: "POST",
        body: JSON.stringify(payload)
      });
      const resultRecord = result && typeof result === "object" ? result : null;
      const allowedKeys = /* @__PURE__ */ new Set(["success", "completed", "flow"]);
      if (!resultRecord || resultRecord.success !== true || resultRecord.completed !== true || resultRecord.flow !== "standard" && resultRecord.flow !== "guide_signup" || Object.keys(resultRecord).some((key) => !allowedKeys.has(key))) {
        throwAuthError({
          code: "UNEXPECTED_RESPONSE",
          message: "Signup completion response was invalid.",
          details: result
        });
      }
      return resultRecord;
    },
    async checkUsernameAvailability(username) {
      const normalized = parseWithSchema(usernameSchema, username);
      return request(
        `/api/auth/check-username?username=${encodeURIComponent(normalized)}`,
        { method: "GET" }
      );
    },
    async forgotPassword(input) {
      const payload = parseWithSchema(forgotPasswordSchema, input);
      return request("/api/auth/forgot-password", {
        method: "POST",
        body: JSON.stringify(payload)
      });
    },
    async validateResetToken(input) {
      const payload = parseWithSchema(resetTokenSchema, input);
      return request("/api/auth/validate-reset-token", {
        method: "POST",
        body: JSON.stringify(payload)
      });
    },
    async resetPassword(input) {
      const payload = parseWithSchema(resetPasswordSchema, input);
      return request("/api/auth/reset-password", {
        method: "POST",
        body: JSON.stringify(payload)
      });
    },
    async requestEmailVerification(input) {
      const payload = parseWithSchema(requestEmailVerificationSchema, input);
      return request("/api/auth/email-verification/request", {
        method: "POST",
        body: JSON.stringify(payload)
      });
    },
    async verifyEmail(input) {
      const payload = parseWithSchema(verifyEmailSchema, input);
      const result = await request("/api/auth/email-verification/verify", {
        method: "POST",
        body: JSON.stringify(payload)
      });
      const resultRecord = result && typeof result === "object" ? result : null;
      const allowedKeys = /* @__PURE__ */ new Set([
        "success",
        "completionToken",
        "completionExpiresAt",
        "flow"
      ]);
      if (!resultRecord || resultRecord.success !== true || typeof resultRecord.completionToken !== "string" || !/^[a-f0-9]{64}$/.test(resultRecord.completionToken) || typeof resultRecord.completionExpiresAt !== "string" || !Number.isFinite(Date.parse(resultRecord.completionExpiresAt)) || resultRecord.flow !== "standard" && resultRecord.flow !== "guide_signup" || Object.keys(resultRecord).some((key) => !allowedKeys.has(key))) {
        throwAuthError({
          code: "UNEXPECTED_RESPONSE",
          message: "Email verification response did not include a valid completion capability.",
          details: result
        });
      }
      return resultRecord;
    }
  };
}
export {
  AuthError,
  AuthInputError,
  BACKEND_AUTH_ERROR_CODE_MAP,
  createAuthApiClient,
  isAuthError,
  isAuthInputError,
  mapBackendAuthError,
  throwAuthError,
  validationErrorToAuthValidationError
};
//# sourceMappingURL=index.mjs.map