// src/schemas/signin.ts
import { z } from "zod";
var signInSchema = z.object({
  username: z.string().trim().min(1, "Username or email is required"),
  password: z.string().min(1, "Password is required")
});

// src/schemas/signup.ts
import { z as z2 } from "zod";
var usernameSchema = z2.string().trim().regex(/^[a-z0-9]+$/, "Username must contain only lowercase letters and numbers").min(3, "Username must be at least 3 characters");
var signUpSchema = z2.object({
  username: usernameSchema,
  email: z2.string().trim().email("Enter a valid email address"),
  password: z2.string().min(8, "Password must be at least 8 characters"),
  fullName: z2.string().trim().min(1, "Full name is required"),
  emailUpdates: z2.boolean().optional(),
  signupIntentToken: z2.string().trim().min(32).max(256).optional()
});

// src/schemas/password-reset.ts
import { z as z3 } from "zod";
var forgotPasswordSchema = z3.object({
  email: z3.string().trim().email("Enter a valid email address")
});
var resetTokenSchema = z3.object({
  token: z3.string().trim().min(1, "Reset token is required")
});
var resetPasswordSchema = z3.object({
  token: z3.string().trim().min(1, "Reset token is required"),
  newPassword: z3.string().min(6, "Password must be at least 6 characters")
});

// src/schemas/email-verification.ts
import { z as z4 } from "zod";
var requestEmailVerificationSchema = z4.object({
  identifier: z4.string().trim().min(1, "Username or email is required").max(320)
});
var verifyEmailSchema = z4.object({
  token: z4.string().trim().regex(/^[a-f0-9]{64}$/, "Invalid token"),
  confirmation: z4.literal(true)
}).strict();
export {
  forgotPasswordSchema,
  requestEmailVerificationSchema,
  resetPasswordSchema,
  resetTokenSchema,
  signInSchema,
  signUpSchema,
  usernameSchema,
  verifyEmailSchema
};
//# sourceMappingURL=index.mjs.map