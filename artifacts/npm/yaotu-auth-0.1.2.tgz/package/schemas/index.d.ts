import { z } from 'zod';

declare const signInSchema: z.ZodObject<{
    username: z.ZodString;
    password: z.ZodString;
}, "strip", z.ZodTypeAny, {
    username: string;
    password: string;
}, {
    username: string;
    password: string;
}>;
type SignInSchemaInput = z.input<typeof signInSchema>;
type SignInSchemaOutput = z.output<typeof signInSchema>;

declare const usernameSchema: z.ZodString;
declare const signUpSchema: z.ZodObject<{
    username: z.ZodString;
    email: z.ZodString;
    password: z.ZodString;
    fullName: z.ZodString;
    emailUpdates: z.ZodOptional<z.ZodBoolean>;
    signupIntentToken: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    username: string;
    password: string;
    email: string;
    fullName: string;
    emailUpdates?: boolean | undefined;
    signupIntentToken?: string | undefined;
}, {
    username: string;
    password: string;
    email: string;
    fullName: string;
    emailUpdates?: boolean | undefined;
    signupIntentToken?: string | undefined;
}>;
type SignUpSchemaInput = z.input<typeof signUpSchema>;
type SignUpSchemaOutput = z.output<typeof signUpSchema>;

declare const forgotPasswordSchema: z.ZodObject<{
    email: z.ZodString;
}, "strip", z.ZodTypeAny, {
    email: string;
}, {
    email: string;
}>;
declare const resetTokenSchema: z.ZodObject<{
    token: z.ZodString;
}, "strip", z.ZodTypeAny, {
    token: string;
}, {
    token: string;
}>;
declare const resetPasswordSchema: z.ZodObject<{
    token: z.ZodString;
    newPassword: z.ZodString;
}, "strip", z.ZodTypeAny, {
    token: string;
    newPassword: string;
}, {
    token: string;
    newPassword: string;
}>;
type ForgotPasswordSchemaInput = z.input<typeof forgotPasswordSchema>;
type ResetTokenSchemaInput = z.input<typeof resetTokenSchema>;
type ResetPasswordSchemaInput = z.input<typeof resetPasswordSchema>;

declare const requestEmailVerificationSchema: z.ZodObject<{
    identifier: z.ZodString;
}, "strip", z.ZodTypeAny, {
    identifier: string;
}, {
    identifier: string;
}>;
declare const verifyEmailSchema: z.ZodObject<{
    token: z.ZodString;
    confirmation: z.ZodLiteral<true>;
}, "strict", z.ZodTypeAny, {
    token: string;
    confirmation: true;
}, {
    token: string;
    confirmation: true;
}>;
type RequestEmailVerificationSchemaInput = z.input<typeof requestEmailVerificationSchema>;
type VerifyEmailSchemaInput = z.input<typeof verifyEmailSchema>;

export { type ForgotPasswordSchemaInput, type RequestEmailVerificationSchemaInput, type ResetPasswordSchemaInput, type ResetTokenSchemaInput, type SignInSchemaInput, type SignInSchemaOutput, type SignUpSchemaInput, type SignUpSchemaOutput, type VerifyEmailSchemaInput, forgotPasswordSchema, requestEmailVerificationSchema, resetPasswordSchema, resetTokenSchema, signInSchema, signUpSchema, usernameSchema, verifyEmailSchema };
