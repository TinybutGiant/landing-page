// src/api/errors.ts
var AuthError = class extends Error {
  constructor(error) {
    super(error.message);
    this.name = "AuthError";
    this.code = error.code;
    this.status = error.status;
    this.backendCode = error.backendCode;
    this.verificationRequired = error.verificationRequired;
    this.verificationEmailMasked = error.verificationEmailMasked;
    this.details = error.details;
  }
};
var AuthInputError = class extends Error {
  constructor(error) {
    super("Validation failed");
    this.code = "VALIDATION_ERROR";
    this.name = "AuthInputError";
    this.fields = error.fields;
  }
};
var BACKEND_AUTH_ERROR_CODE_MAP = {
  email_verification_required: "EMAIL_VERIFICATION_REQUIRED",
  PUBLIC_SIGNUP_CLOSED: "PUBLIC_SIGNUP_CLOSED",
  SIGNUP_INTENT_INVALID: "SIGNUP_INTENT_INVALID"
};
function validationErrorToAuthValidationError(error) {
  const fields = {};
  const issues = error && typeof error === "object" && Array.isArray(error.issues) ? error.issues : [];
  for (const issue of issues) {
    const path = Array.isArray(issue.path) ? issue.path.map(String).join(".") : "";
    const key = path || "_form";
    fields[key] ?? (fields[key] = typeof issue.message === "string" ? issue.message : "Invalid value");
  }
  return { code: "VALIDATION_ERROR", fields: Object.keys(fields).length ? fields : { _form: "Invalid input" } };
}
function mapBackendAuthError(status, body) {
  const payload = body && typeof body === "object" ? body : {};
  const backendCode = typeof payload.code === "string" ? payload.code : void 0;
  const canonicalCode = backendCode && backendCode in BACKEND_AUTH_ERROR_CODE_MAP ? BACKEND_AUTH_ERROR_CODE_MAP[backendCode] : void 0;
  const message = typeof payload.message === "string" ? payload.message : typeof payload.error === "string" ? payload.error : "Authentication request failed";
  if (canonicalCode === "EMAIL_VERIFICATION_REQUIRED") {
    return {
      code: canonicalCode,
      message,
      status,
      backendCode,
      verificationRequired: payload.verificationRequired === true,
      verificationEmailMasked: typeof payload.verificationEmailMasked === "string" ? payload.verificationEmailMasked : null
    };
  }
  if (status === 401) {
    return { code: "INVALID_CREDENTIALS", message, status, backendCode };
  }
  if (status === 400 && /username/i.test(message) && /exists|taken/i.test(message)) {
    return { code: "USERNAME_TAKEN", message, status, backendCode };
  }
  if (status === 400 && /invalid|expired/i.test(message) && /token|link/i.test(message)) {
    return { code: "INVALID_OR_EXPIRED_TOKEN", message, status, backendCode };
  }
  if (canonicalCode === "PUBLIC_SIGNUP_CLOSED" || canonicalCode === "SIGNUP_INTENT_INVALID") {
    return { code: canonicalCode, message, status, backendCode, details: body };
  }
  return { code: "REQUEST_FAILED", message, status, backendCode, details: body };
}
function throwAuthError(error) {
  if (error.code === "VALIDATION_ERROR") {
    throw new AuthInputError(error);
  }
  throw new AuthError(error);
}
function isAuthError(error, code) {
  if (!(error instanceof AuthError)) return false;
  return code ? error.code === code : true;
}
function isAuthInputError(error) {
  return error instanceof AuthInputError;
}

// src/schemas/signin.ts
import { z } from "zod";
var signInSchema = z.object({
  username: z.string().trim().min(1, "Username or email is required"),
  password: z.string().min(1, "Password is required")
});

// src/schemas/signup.ts
import { z as z2 } from "zod";
var usernameSchema = z2.string().trim().regex(/^[a-z0-9]+$/, "Username must contain only lowercase letters and numbers").min(3, "Username must be at least 3 characters");
var signUpSchema = z2.object({
  username: usernameSchema,
  email: z2.string().trim().email("Enter a valid email address"),
  password: z2.string().min(8, "Password must be at least 8 characters"),
  fullName: z2.string().trim().min(1, "Full name is required"),
  emailUpdates: z2.boolean().optional(),
  signupIntentToken: z2.string().trim().min(32).max(256).optional()
});

// src/schemas/password-reset.ts
import { z as z3 } from "zod";
var forgotPasswordSchema = z3.object({
  email: z3.string().trim().email("Enter a valid email address")
});
var resetTokenSchema = z3.object({
  token: z3.string().trim().min(1, "Reset token is required")
});
var resetPasswordSchema = z3.object({
  token: z3.string().trim().min(1, "Reset token is required"),
  newPassword: z3.string().min(6, "Password must be at least 6 characters")
});

// src/schemas/email-verification.ts
import { z as z4 } from "zod";
var requestEmailVerificationSchema = z4.object({
  identifier: z4.string().trim().min(1, "Username or email is required").max(320)
});
var verifyEmailSchema = z4.object({
  token: z4.string().trim().regex(/^[a-f0-9]{64}$/, "Invalid token"),
  confirmation: z4.literal(true)
}).strict();

// src/api/client.ts
function resolveUrl(apiBaseUrl, path) {
  if (!apiBaseUrl) return path;
  return `${apiBaseUrl.replace(/\/+$/, "")}/${path.replace(/^\/+/, "")}`;
}
async function readResponseBody(response) {
  const contentType = response.headers.get("content-type") ?? "";
  if (contentType.includes("application/json")) {
    return response.json().catch(() => null);
  }
  return response.text().catch(() => null);
}
function parseWithSchema(schema, input) {
  const parsed = schema.safeParse(input);
  if (parsed.success) return parsed.data;
  throwAuthError(validationErrorToAuthValidationError(parsed.error));
}
function createAuthApiClient(options = {}) {
  const fetcher = options.fetcher ?? globalThis.fetch.bind(globalThis);
  async function request(path, init) {
    const response = await fetcher(resolveUrl(options.apiBaseUrl, path), {
      ...init,
      headers: {
        "Content-Type": "application/json",
        ...init.headers
      }
    });
    const body = await readResponseBody(response);
    if (!response.ok) {
      throwAuthError(mapBackendAuthError(response.status, body));
    }
    return body;
  }
  return {
    async signIn(input) {
      const payload = parseWithSchema(signInSchema, input);
      const result = await request("/api/auth/login", {
        method: "POST",
        body: JSON.stringify(payload)
      });
      if (!result || typeof result.token !== "string" || !result.id) {
        throwAuthError({
          code: "UNEXPECTED_RESPONSE",
          message: "Login response did not include an authenticated session."
        });
      }
      return result;
    },
    async signUp(input) {
      const payload = parseWithSchema(signUpSchema, input);
      const result = await request("/api/auth/signup", {
        method: "POST",
        body: JSON.stringify(payload)
      });
      const resultRecord = result && typeof result === "object" ? result : null;
      const allowedKeys = /* @__PURE__ */ new Set(["success", "verificationRequired", "message"]);
      if (!resultRecord || resultRecord.success !== true || resultRecord.verificationRequired !== true || typeof resultRecord.message !== "string" || Object.keys(resultRecord).some((key) => !allowedKeys.has(key))) {
        throwAuthError({
          code: "UNEXPECTED_RESPONSE",
          message: "Signup response must be the generic accepted result without account metadata or an auth token.",
          details: result
        });
      }
      return resultRecord;
    },
    async checkUsernameAvailability(username) {
      const normalized = parseWithSchema(usernameSchema, username);
      return request(
        `/api/auth/check-username?username=${encodeURIComponent(normalized)}`,
        { method: "GET" }
      );
    },
    async forgotPassword(input) {
      const payload = parseWithSchema(forgotPasswordSchema, input);
      return request("/api/auth/forgot-password", {
        method: "POST",
        body: JSON.stringify(payload)
      });
    },
    async validateResetToken(input) {
      const payload = parseWithSchema(resetTokenSchema, input);
      return request("/api/auth/validate-reset-token", {
        method: "POST",
        body: JSON.stringify(payload)
      });
    },
    async resetPassword(input) {
      const payload = parseWithSchema(resetPasswordSchema, input);
      return request("/api/auth/reset-password", {
        method: "POST",
        body: JSON.stringify(payload)
      });
    },
    async requestEmailVerification(input) {
      const payload = parseWithSchema(requestEmailVerificationSchema, input);
      return request("/api/auth/email-verification/request", {
        method: "POST",
        body: JSON.stringify(payload)
      });
    },
    async verifyEmail(input) {
      const payload = parseWithSchema(verifyEmailSchema, input);
      return request("/api/auth/email-verification/verify", {
        method: "POST",
        body: JSON.stringify(payload)
      });
    }
  };
}

// src/runtime/AuthRuntimeProvider.tsx
import {
  createContext,
  useContext,
  useMemo
} from "react";

// src/i18n/messages.ts
var authMessages = {
  en: {
    loginTitle: "Login",
    signupTitle: "Pre-launch access",
    createAccount: "Create an account",
    surfStageLabel: "Destination card river",
    pickMascot: "Choose your MBTI color",
    mbtiStageLabel: "MBTI card river",
    mascot: {
      diplomat: "Green",
      entertainer: "Yellow",
      logician: "Purple",
      protector: "Blue",
      explorer: "Trail",
      lantern: "Lantern",
      unknown: "I don't know"
    },
    surf: {
      asakusa: "Asakusa",
      fuji: "Mount Fuji",
      torii: "Torii path",
      tokyo: "Tokyo Tower",
      yokocho: "Yokocho alley",
      fujiden: "Fujiden shop"
    },
    username: "Username",
    usernamePlaceholder: "Enter your username",
    email: "Email address",
    emailPlaceholder: "Enter your email address",
    password: "Password",
    passwordPlaceholder: "Enter your password",
    confirmPassword: "Confirm password",
    confirmPasswordPlaceholder: "Re-enter your password",
    forgotPassword: "Forgot Password?",
    dontHaveAccount: "New to YaoTu?",
    alreadyHaveAccount: "Already have an account?",
    loginButton: "Sign in",
    signupButton: "Explore pre-launch access",
    signingIn: "Signing in...",
    signingUp: "Signing up...",
    firstName: "First name",
    firstNamePlaceholder: "First name",
    lastName: "Last name",
    lastNamePlaceholder: "Last name",
    checkingUsername: "Checking availability...",
    suggested: "Suggested:",
    passwordHint: "Password must contain: letters, numbers, and special characters",
    emailUpdates: "Send me occasional updates by email. Unsubscribe anytime.",
    signupUnexpectedError: "An unexpected error occurred while creating your account.",
    usernameChoosePlaceholder: "Choose a username for your profile",
    usernameHelperText: "Lowercase letters and numbers only. You can sign in later with your username or email.",
    passwordCreatePlaceholder: "Create a password with at least 8 characters",
    passwordStrength: {
      weak: "Weak",
      medium: "Medium",
      strong: "Strong"
    },
    error: {
      title: "Error",
      fillAllFields: "Please fill in all fields",
      fillName: "Please enter your name",
      passwordTooShort: "Password must be at least 8 characters",
      passwordMismatch: "Passwords do not match",
      agreeTerms: "Please agree to the Terms of Service and Privacy Policy"
    },
    terms: {
      agreePrefix: "I agree to the",
      termsOfService: "Terms of Service",
      and: "and",
      privacyPolicy: "Privacy Policy"
    },
    toast: {
      error: "Error",
      fillAllFields: "Please fill in all fields",
      loginSuccessTitle: "Logged in successfully",
      loginSuccessDescription: "Welcome back!",
      loginFailedTitle: "Login failed",
      loginFailedDescription: "Please check your credentials and try again.",
      signupSuccessTitle: "Request received",
      signupVerificationRequiredDescription: "If these details can be used for an account, check your inbox. You can also sign in or request a verification email."
    },
    usernameValidation: {
      invalidFormat: "Username must be at least 3 characters and contain only lowercase letters and numbers",
      taken: "Username is already taken",
      errorChecking: "Error checking username availability"
    },
    emailVerification: {
      title: "Verify your email",
      description: "If these details can be used for an account, check your inbox. Otherwise, sign in or request a verification email below.",
      confirmPrompt: "Opening this link does not verify your email. Confirm below to continue.",
      confirm: "Confirm email",
      retryPrompt: "We couldn't verify your email right now. Please try again.",
      tryAgain: "Try again",
      verifying: "Verifying your email...",
      success: "Your email is verified. You can now sign in.",
      invalidOrExpired: "This verification link is invalid or expired. Request a new one below.",
      requestAnother: "Request another email",
      sent: "Request received. Check your inbox if account setup can continue, or use the options below.",
      requestReceived: "Request received. If this account still needs verification, check your inbox and spam folder.",
      identifierRequired: "Enter your username or email address.",
      identifierLabel: "Account username or registered email",
      identifierHelp: "Enter the same email address used to create this account (or the account username). The verification email will not be sent to a different address.",
      destination: "Verification emails are sent to: {email}",
      requestFailed: "Unable to send a verification email. Please try again.",
      resend: "Send verification email"
    },
    forgotPasswordPage: {
      title: "Forgot Password",
      description: "Enter your email address and we'll send you a reset link.",
      enterEmail: "Please enter your email address",
      invalidEmail: "Please enter a valid email address",
      emailSent: "Email Sent",
      emailSentDesc: "If the email is registered, you will receive a password reset email",
      checkEmailDesc: "If the email address is registered, you will receive a password reset email. Please check your inbox (including spam folder).",
      sendFailed: "Send Failed",
      sendFailedDesc: "An error occurred while sending the reset email. Please try again later.",
      notReceived: "Didn't receive the email? Please wait a few minutes or check your spam folder.",
      resend: "Resend",
      backToLogin: "Back to Login",
      sending: "Sending...",
      sendLink: "Send Reset Link"
    },
    resetPassword: {
      title: "Reset Password",
      subtitle: "Please enter your new password",
      linkInvalid: "Invalid Link",
      linkExpired: "The reset password link has expired or is invalid. Please request a new one.",
      passwordMinLength: "Password must be at least 6 characters",
      resetSuccess: "Password Reset Successful",
      resetSuccessDesc: "Your password has been reset successfully. Redirecting to login page...",
      resetFailed: "Reset Failed",
      resetFailedDesc: "An error occurred while resetting password. Please try again.",
      newPassword: "New Password",
      newPasswordPlaceholder: "Enter new password (at least 6 characters)",
      confirmNewPassword: "Confirm New Password",
      confirmNewPasswordPlaceholder: "Re-enter new password",
      resetting: "Resetting...",
      resetButton: "Reset Password",
      backToLogin: "Back to Login",
      reapplyButton: "Request New Reset Link"
    }
  },
  "zh-CN": {},
  ja: {}
};
function readMessage(tree, key) {
  let current = tree;
  for (const part of key.split(".")) {
    if (!current || typeof current === "string") return void 0;
    current = current[part];
  }
  return typeof current === "string" ? current : void 0;
}
function resolveAuthMessage(key, locale = "en", overrides, values, defaultMessage) {
  const raw = (overrides ? readMessage(overrides, key) : void 0) ?? readMessage(authMessages[locale], key) ?? readMessage(authMessages.en, key) ?? defaultMessage ?? key;
  if (!values) return raw;
  return raw.replace(/\{(\w+)\}/g, (_match, name) => {
    const value = values[name];
    return value == null ? "" : String(value);
  });
}

// src/utils/cx.ts
import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";
function cn(...inputs) {
  return twMerge(clsx(inputs));
}

// src/runtime/AuthRuntimeProvider.tsx
import { jsx } from "react/jsx-runtime";
var AuthRuntimeContext = createContext(null);
function AuthRuntimeProvider({
  config,
  children
}) {
  const value = useMemo(() => config ?? {}, [config]);
  return /* @__PURE__ */ jsx(AuthRuntimeContext.Provider, { value, children });
}
function useAuthRuntime(overrides) {
  const context = useContext(AuthRuntimeContext);
  const config = { ...context ?? {}, ...overrides ?? {} };
  const apiClient = useMemo(
    () => config.apiClient ?? createAuthApiClient({
      apiBaseUrl: config.apiBaseUrl,
      fetcher: config.fetcher
    }),
    [config.apiBaseUrl, config.apiClient, config.fetcher]
  );
  const t = useMemo(
    () => config.t ?? ((key, values, defaultMessage) => resolveAuthMessage(key, config.locale ?? "en", config.messages, values, defaultMessage)),
    [config.locale, config.messages, config.t]
  );
  return {
    ...config,
    apiClient,
    t
  };
}
function AuthLink({
  href,
  className,
  children,
  LinkComponent,
  ...props
}) {
  if (LinkComponent) {
    return /* @__PURE__ */ jsx(LinkComponent, { href, className, ...props, children });
  }
  return /* @__PURE__ */ jsx("a", { href, className, ...props, children });
}
function AuthRoot({
  darkMode,
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx("div", { className: cn("yt-auth-root", darkMode && "dark", className), ...props });
}

// src/components/SignInForm.tsx
import {
  useEffect as useEffect3,
  useRef as useRef3,
  useState as useState3
} from "react";

// src/utils/validation.ts
function validateUsername(username) {
  return /^[a-z0-9]+$/.test(username) && username.length >= 3;
}
function generateUsernameSuggestion(baseUsername) {
  const randomNum = Math.floor(Math.random() * 1e3);
  return `${baseUsername}${randomNum}`;
}
function calculatePasswordStrength(password) {
  let score = 0;
  if (password.length >= 8) score += 1;
  if (/[a-z]/.test(password)) score += 1;
  if (/[A-Z]/.test(password)) score += 1;
  if (/[0-9]/.test(password)) score += 1;
  if (/[^a-zA-Z0-9]/.test(password)) score += 1;
  if (!password) return { score: 0, labelKey: "", color: "" };
  if (score <= 2) return { score, labelKey: "passwordStrength.weak", color: "text-red-500" };
  if (score <= 3) {
    return { score, labelKey: "passwordStrength.medium", color: "text-yellow-500" };
  }
  return { score, labelKey: "passwordStrength.strong", color: "text-green-500" };
}
function readTokenFromLocation(location = window.location) {
  const hashParams = new URLSearchParams(location.hash.replace(/^#/, ""));
  const fragmentToken = hashParams.get("token")?.trim();
  if (fragmentToken) return fragmentToken;
  return new URLSearchParams(location.search).get("token")?.trim() ?? "";
}
function readRedirectFromLocation(location = window.location) {
  return new URLSearchParams(location.search).get("redirect");
}

// src/components/AuthField.tsx
import * as React2 from "react";
import { Eye, EyeOff } from "lucide-react";

// src/components/ui/input.tsx
import * as React from "react";
import { jsx as jsx2 } from "react/jsx-runtime";
var Input = React.forwardRef(
  ({ className, type, ...props }, ref) => {
    return /* @__PURE__ */ jsx2(
      "input",
      {
        type,
        className: cn(
          "flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 dark:text-white",
          className
        ),
        ref,
        ...props
      }
    );
  }
);
Input.displayName = "Input";

// src/components/authShell.ts
var AUTH_DARK_SHELL = "#0e0e0e";
var AUTH_FIELD_GAP = "space-y-4";
var AUTH_LABEL_GAP = "mt-1.5";
var AUTH_INPUT_BASE = "h-12 !w-full rounded-2xl border border-stone-200 !bg-white px-3.5 text-base text-stone-900 shadow-none placeholder:text-stone-400 focus-visible:border-yellow-400/50 focus-visible:ring-2 focus-visible:ring-yellow-400 focus-visible:ring-offset-0 dark:border-white/15 dark:!bg-white/[0.08] dark:text-white dark:placeholder:text-white/40";
var AUTH_INPUT_ERROR = "ring-2 ring-red-500 focus-visible:ring-red-500 dark:ring-red-400";
var AUTH_LABEL = "block text-sm font-medium text-stone-800 dark:text-white/75";
var AUTH_TOGGLE = "absolute inset-y-0 right-0 flex items-center px-3 text-sm font-medium text-stone-500 hover:text-yellow-600 dark:text-white/45 dark:hover:text-yellow-300";
var AUTH_RIVER_ANCHOR_CLASS = "left-[48%] top-1/2 will-change-transform sm:left-[50%] lg:left-[52%] xl:left-[54%]";
var AUTH_RIVER_CARD_BOX_CLASS = "h-[26rem] w-[14.5rem] sm:h-[28rem] sm:w-[15.5rem] lg:h-[30rem] lg:w-[16.5rem]";
var AUTH_RIVER_PERSPECTIVE = 1800;
var AUTH_RIVER_PERSPECTIVE_ORIGIN = "50% 50%";

// src/components/AuthField.tsx
import { jsx as jsx3, jsxs } from "react/jsx-runtime";
function authInputClassName(options) {
  return cn(AUTH_INPUT_BASE, options?.error && AUTH_INPUT_ERROR, options?.className);
}
var AuthField = React2.forwardRef(
  ({ label, error, id, className, labelClassName, containerClassName, ...props }, ref) => {
    return /* @__PURE__ */ jsxs("div", { className: containerClassName, children: [
      /* @__PURE__ */ jsx3("label", { htmlFor: id, className: cn(AUTH_LABEL, labelClassName), children: label }),
      /* @__PURE__ */ jsx3(
        Input,
        {
          ref,
          id,
          className: cn(AUTH_LABEL_GAP, authInputClassName({ error, className })),
          "aria-invalid": error || void 0,
          ...props
        }
      )
    ] });
  }
);
AuthField.displayName = "AuthField";
var AuthPasswordField = React2.forwardRef(
  ({
    label,
    error,
    id,
    className,
    labelClassName,
    containerClassName,
    showPassword,
    onToggleShow,
    showLabel = "Show password",
    hideLabel = "Hide password",
    ...props
  }, ref) => {
    return /* @__PURE__ */ jsxs("div", { className: containerClassName, children: [
      /* @__PURE__ */ jsx3("label", { htmlFor: id, className: cn(AUTH_LABEL, labelClassName), children: label }),
      /* @__PURE__ */ jsxs("div", { className: cn("relative", AUTH_LABEL_GAP), children: [
        /* @__PURE__ */ jsx3(
          Input,
          {
            ref,
            id,
            type: showPassword ? "text" : "password",
            className: authInputClassName({ error, className: cn("pr-11", className) }),
            "aria-invalid": error || void 0,
            ...props
          }
        ),
        /* @__PURE__ */ jsx3(
          "button",
          {
            type: "button",
            onClick: onToggleShow,
            className: AUTH_TOGGLE,
            "aria-label": showPassword ? hideLabel : showLabel,
            children: showPassword ? /* @__PURE__ */ jsx3(EyeOff, { className: "h-4 w-4" }) : /* @__PURE__ */ jsx3(Eye, { className: "h-4 w-4" })
          }
        )
      ] })
    ] });
  }
);
AuthPasswordField.displayName = "AuthPasswordField";

// src/components/AuthSplitStage.tsx
import { jsx as jsx4, jsxs as jsxs2 } from "react/jsx-runtime";
function AuthSplitStage({
  stage,
  children,
  className,
  formWidthPx,
  formWidth,
  contentMaxWidthPx = 656,
  stickyStage = false
}) {
  return /* @__PURE__ */ jsxs2(
    "div",
    {
      className: cn(
        "relative flex min-h-[calc(100vh-4rem)] w-full flex-col bg-white dark:bg-[#0e0e0e] md:flex-row",
        className
      ),
      style: {
        ["--auth-form-w"]: formWidth ?? (formWidthPx ? `${formWidthPx}px` : "35%"),
        ["--auth-content-w"]: `${contentMaxWidthPx}px`
      },
      children: [
        /* @__PURE__ */ jsx4(
          "div",
          {
            className: cn(
              "relative min-h-[min(52vh,28rem)] min-w-0 flex-1 overflow-hidden md:min-h-[calc(100vh-4rem)]",
              stickyStage && "md:sticky md:top-16 md:h-[calc(100vh-4rem)] md:max-h-[calc(100vh-4rem)] md:self-start"
            ),
            children: /* @__PURE__ */ jsx4("div", { className: "absolute inset-0 overflow-hidden", children: stage })
          }
        ),
        /* @__PURE__ */ jsx4(
          "aside",
          {
            className: cn(
              "relative z-10 flex w-full shrink-0 flex-col border-t border-stone-100 bg-white dark:border-white/10 dark:bg-[#0e0e0e] md:w-[var(--auth-form-w)] md:border-l md:border-t-0",
              stickyStage ? "md:min-h-0" : "md:min-h-[calc(100vh-4rem)]",
              !stickyStage && "min-h-0 flex-1"
            ),
            children: /* @__PURE__ */ jsx4("div", { className: "flex flex-1 flex-col justify-center px-10 py-10 sm:px-12 sm:py-12 md:px-[2.75rem] md:py-12", children: /* @__PURE__ */ jsx4("div", { className: "mx-auto w-full max-w-[var(--auth-content-w)]", children }) })
          }
        )
      ]
    }
  );
}

// src/components/ui/button.tsx
import * as React3 from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva } from "class-variance-authority";
import { jsx as jsx5 } from "react/jsx-runtime";
var buttonVariants = cva(
  "inline-flex min-h-10 items-center justify-center gap-2 whitespace-nowrap rounded-xl text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-35 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "btn-lip-press rounded-xl bg-[var(--yt-auth-primary)] text-[var(--yt-auth-on-primary)] font-bold shadow-[var(--yt-auth-shadow-btn-lip)] hover:bg-yellow-500 hover:brightness-100 disabled:shadow-none focus-visible:ring-[var(--yt-auth-btn-lip)] dark:text-black",
        destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90 dark:text-white",
        outline: "rounded-xl border border-[var(--yt-auth-btn-secondary-border)] bg-[var(--yt-auth-btn-secondary-bg)] text-foreground font-medium shadow-none hover:border-[#D4D4D4] hover:bg-[var(--yt-auth-surface-interactive)] dark:border-[var(--yt-auth-btn-secondary-border)] dark:bg-[var(--yt-auth-btn-secondary-bg)] dark:text-white dark:hover:bg-[var(--yt-auth-surface-interactive)]",
        secondary: "rounded-xl border border-[var(--yt-auth-btn-secondary-border)] bg-[var(--yt-auth-btn-secondary-bg)] text-foreground font-medium shadow-none hover:border-[#D4D4D4] hover:bg-[var(--yt-auth-surface-interactive)] dark:border-[var(--yt-auth-btn-secondary-border)] dark:bg-[var(--yt-auth-btn-secondary-bg)] dark:text-white dark:hover:bg-[var(--yt-auth-surface-interactive)]",
        ghost: "bg-transparent hover:bg-[var(--yt-auth-surface-interactive)] hover:text-foreground dark:text-white dark:hover:bg-white/10",
        link: "text-primary underline-offset-4 hover:underline"
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 px-3",
        lg: "h-11 px-8",
        icon: "h-11 w-11 min-h-11 min-w-11 rounded-full"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);
var Button = React3.forwardRef(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return /* @__PURE__ */ jsx5(Comp, { className: cn(buttonVariants({ variant, size, className })), ref, ...props });
  }
);
Button.displayName = "Button";

// src/components/visual/LoginSurfImmersive.tsx
import { useEffect as useEffect2, useMemo as useMemo2, useRef as useRef2, useState as useState2 } from "react";
import {
  AnimatePresence,
  motion,
  useMotionValueEvent as useMotionValueEvent2,
  useReducedMotion,
  useSpring as useSpring2,
  useTransform
} from "framer-motion";

// src/components/visual/AuthRiverFog.tsx
import { jsx as jsx6, jsxs as jsxs3 } from "react/jsx-runtime";
function AuthRiverWash({ darkMode = false, accent }) {
  const wash = accent ?? (darkMode ? "rgba(255,255,255,0.22)" : "rgba(255,255,255,0.85)");
  return /* @__PURE__ */ jsx6(
    "div",
    {
      className: "pointer-events-none absolute inset-[-10%] blur-3xl transition-[background,opacity] duration-700",
      "aria-hidden": true,
      style: {
        opacity: darkMode ? 0.34 : 0.42,
        background: `radial-gradient(ellipse at 35% 45%, ${wash}55, transparent 58%)`
      }
    }
  );
}
function AuthRiverVignette({ darkMode = false }) {
  return /* @__PURE__ */ jsxs3("div", { className: "pointer-events-none absolute inset-0 z-[2]", "aria-hidden": true, children: [
    /* @__PURE__ */ jsx6(
      "div",
      {
        className: cn(
          "absolute inset-0",
          darkMode ? "bg-gradient-to-r from-black/30 via-transparent to-black/45" : "bg-gradient-to-r from-white/35 via-transparent to-white/40"
        )
      }
    ),
    /* @__PURE__ */ jsx6(
      "div",
      {
        className: cn(
          "absolute inset-0",
          darkMode ? "bg-gradient-to-b from-black/35 via-transparent to-black/50" : "bg-gradient-to-b from-white/20 via-transparent to-white/45"
        )
      }
    )
  ] });
}

// src/components/visual/LoginMascotSurf.ts
var SURF_PLANES = [
  {
    id: "asakusa",
    imageVar: "var(--yt-auth-surf-asakusa)",
    nameKey: "surf.asakusa",
    accent: "#E5A245"
  },
  {
    id: "torii",
    imageVar: "var(--yt-auth-surf-torii)",
    nameKey: "surf.torii",
    accent: "#D4A056"
  },
  {
    id: "tokyo",
    imageVar: "var(--yt-auth-surf-tokyo)",
    nameKey: "surf.tokyo",
    accent: "#C9893A"
  },
  {
    id: "yokocho",
    imageVar: "var(--yt-auth-surf-yokocho)",
    nameKey: "surf.yokocho",
    accent: "#E8B86D"
  },
  {
    id: "fuji",
    imageVar: "var(--yt-auth-surf-fuji)",
    nameKey: "surf.fuji",
    accent: "#F0C27A"
  },
  {
    id: "fujiden",
    imageVar: "var(--yt-auth-surf-fujiden)",
    nameKey: "surf.fujiden",
    accent: "#B8862E"
  }
];

// src/components/visual/useAuthRiverDrive.ts
import { useCallback, useEffect, useRef, useState } from "react";
import {
  useMotionValue,
  useMotionValueEvent,
  useSpring,
  useVelocity
} from "framer-motion";
function wrapScroll(value, period, scrollResetAt) {
  let next = value;
  while (next >= scrollResetAt) next -= period;
  while (next < period) next += period;
  return next;
}
function useAuthRiverDrive({
  baseSpeed,
  maxSpeed = baseSpeed * 4.2,
  period,
  scrollStart,
  scrollResetAt,
  reduceMotion
}) {
  const scrollX = useMotionValue(scrollStart);
  const speed = useMotionValue(baseSpeed);
  const smoothSpeed = useSpring(speed, { stiffness: 140, damping: 26, mass: 0.4 });
  const scrollVelocity = useVelocity(scrollX);
  const smoothVelocity = useSpring(scrollVelocity, { stiffness: 100, damping: 28, mass: 0.45 });
  const wave = useSpring(0, { stiffness: 80, damping: 18 });
  const draggingRef = useRef(false);
  const lastPanAtRef = useRef(0);
  const [viewportEl, setViewportEl] = useState(null);
  const middleDragRef = useRef({ active: false, lastX: 0 });
  const nudgeScroll = useCallback(
    (deltaPx, velocityHint = 0) => {
      if (reduceMotion || deltaPx === 0) return;
      draggingRef.current = true;
      lastPanAtRef.current = performance.now();
      scrollX.set(wrapScroll(scrollX.get() + deltaPx, period, scrollResetAt));
      const signed = velocityHint || deltaPx * 24;
      const magnitude = Math.min(maxSpeed, Math.max(Math.abs(signed), Math.abs(baseSpeed) * 0.35));
      speed.set(Math.sign(signed || 1) * magnitude);
    },
    [baseSpeed, maxSpeed, period, reduceMotion, scrollResetAt, scrollX, speed]
  );
  const endSurf = useCallback(() => {
    draggingRef.current = false;
    lastPanAtRef.current = performance.now();
    speed.set(baseSpeed);
  }, [baseSpeed, speed]);
  useMotionValueEvent(smoothVelocity, "change", (latest) => {
    if (reduceMotion) {
      wave.set(0);
      return;
    }
    wave.set(Math.min(Math.abs(latest) * 0.05, 48));
  });
  useEffect(() => {
    if (reduceMotion) return;
    let frame = 0;
    let last = performance.now();
    const tick = (now) => {
      const dt = Math.min(48, now - last);
      last = now;
      if (!draggingRef.current && now - lastPanAtRef.current > 140) {
        if (Math.abs(speed.get() - baseSpeed) > 0.4) {
          speed.set(baseSpeed);
        }
      } else if (!middleDragRef.current.active && now - lastPanAtRef.current > 160) {
        draggingRef.current = false;
      }
      const cruise = Math.max(-maxSpeed, Math.min(maxSpeed, smoothSpeed.get()));
      scrollX.set(wrapScroll(scrollX.get() + cruise * dt / 1e3, period, scrollResetAt));
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [baseSpeed, maxSpeed, period, reduceMotion, scrollResetAt, scrollX, smoothSpeed, speed]);
  useEffect(() => {
    const el = viewportEl;
    if (!el || reduceMotion) return;
    const onWheel = (event) => {
      const dominant = Math.abs(event.deltaX) > Math.abs(event.deltaY) ? event.deltaX : event.deltaY;
      if (dominant === 0) return;
      event.preventDefault();
      nudgeScroll(dominant * 0.95, dominant * 14);
    };
    const onPointerDown = (event) => {
      if (event.button !== 1) return;
      event.preventDefault();
      middleDragRef.current = { active: true, lastX: event.clientX };
      draggingRef.current = true;
      el.setPointerCapture?.(event.pointerId);
    };
    const onPointerMove = (event) => {
      if (!middleDragRef.current.active) return;
      const dx = event.clientX - middleDragRef.current.lastX;
      middleDragRef.current.lastX = event.clientX;
      nudgeScroll(-dx * 1.05, -dx * 22);
    };
    const onPointerUp = (event) => {
      if (!middleDragRef.current.active) return;
      if (event.button !== 1 && event.type !== "pointercancel") return;
      middleDragRef.current.active = false;
      try {
        el.releasePointerCapture?.(event.pointerId);
      } catch {
      }
      endSurf();
    };
    const onAuxClick = (event) => {
      if (event.button === 1) event.preventDefault();
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    el.addEventListener("pointerdown", onPointerDown);
    el.addEventListener("pointermove", onPointerMove);
    el.addEventListener("pointerup", onPointerUp);
    el.addEventListener("pointercancel", onPointerUp);
    el.addEventListener("auxclick", onAuxClick);
    return () => {
      el.removeEventListener("wheel", onWheel);
      el.removeEventListener("pointerdown", onPointerDown);
      el.removeEventListener("pointermove", onPointerMove);
      el.removeEventListener("pointerup", onPointerUp);
      el.removeEventListener("pointercancel", onPointerUp);
      el.removeEventListener("auxclick", onAuxClick);
    };
  }, [endSurf, nudgeScroll, reduceMotion, viewportEl]);
  const handlePan = useCallback(
    (_event, info) => {
      if (reduceMotion) return;
      draggingRef.current = true;
      lastPanAtRef.current = performance.now();
      if (info.delta.x !== 0) {
        nudgeScroll(-info.delta.x * 1.05, -info.velocity.x * 0.22 - info.delta.x * 22);
      }
    },
    [nudgeScroll, reduceMotion]
  );
  const handlePanEnd = useCallback(() => {
    endSurf();
  }, [endSurf]);
  return {
    scrollX,
    wave,
    speed,
    handlePan,
    handlePanEnd,
    setViewportRef: setViewportEl,
    isDraggingRef: draggingRef
  };
}

// src/components/visual/LoginSurfImmersive.tsx
import { jsx as jsx7, jsxs as jsxs4 } from "react/jsx-runtime";
var COUNT = SURF_PLANES.length;
var SPACING = 210;
var PERIOD = COUNT * SPACING;
var COPIES = 3;
var AUTOPLAY_SPEED = 36;
var SCROLL_START = PERIOD;
var SCROLL_RESET_AT = PERIOD * 2;
var PHOTO_FILTER = "drop-shadow(0 36px 48px rgba(0, 0, 0, 0.4))";
var SCRAMBLE_GLYPHS = "ABCDEFGHJKLMNPQRSTUVWXYZ\u30A1\u30A2\u30A6\u30A8\u30AA\u30AB\u30AD\u30AF\u30B1\u30B3";
var STRIP_SLOTS = Array.from({ length: COPIES * COUNT }, (_, slot) => {
  const planeIndex = slot % COUNT;
  const copy = Math.floor(slot / COUNT);
  return {
    slot,
    planeIndex,
    key: `${copy}-${SURF_PLANES[planeIndex].id}`
  };
});
function nearestPlaneIndex(scroll) {
  const idx = Math.round(scroll / SPACING);
  return (idx % COUNT + COUNT) % COUNT;
}
function ScrambleLabel({ text, reduceMotion }) {
  const [display, setDisplay] = useState2(reduceMotion ? text : "");
  useEffect2(() => {
    if (reduceMotion) {
      setDisplay(text);
      return;
    }
    let frame = 0;
    const settleAt = Math.max(14, text.length * 2 + 6);
    const id = window.setInterval(() => {
      frame += 1;
      setDisplay(
        text.split("").map((ch, index) => {
          if (ch === " " || ch === "\u8DEF") return ch;
          if (frame > index * 2 + 5) return text[index];
          return SCRAMBLE_GLYPHS[Math.floor(Math.random() * SCRAMBLE_GLYPHS.length)];
        }).join("")
      );
      if (frame >= settleAt) {
        setDisplay(text);
        window.clearInterval(id);
      }
    }, 26);
    return () => window.clearInterval(id);
  }, [text, reduceMotion]);
  return /* @__PURE__ */ jsx7("span", { className: "tabular-nums tracking-[0.14em]", children: display || "\xA0" });
}
function ImmersivePlane({
  slot,
  planeIndex,
  scrollX,
  wave,
  reduceMotion,
  darkMode,
  onGazeChange
}) {
  const runtime = useAuthRuntime();
  const plane = SURF_PLANES[planeIndex];
  const label = runtime.t(plane.nameKey);
  const indexLabel = String(planeIndex + 1).padStart(2, "0");
  const [gazed, setGazed] = useState2(false);
  const [near, setNear] = useState2(true);
  const gaze = useSpring2(0, { stiffness: 260, damping: 26, mass: 0.4 });
  const x = useTransform(scrollX, (latest) => slot * SPACING - latest);
  const yBase = useTransform([x, wave], ([latestX, latestWave]) => {
    const ribbon = latestX * 0.28;
    if (reduceMotion) return ribbon;
    return ribbon + Math.sin(latestX / 100) * (latestWave * 0.55);
  });
  const liftY = useTransform(gaze, [0, 1], [0, -18]);
  const y = useTransform([yBase, liftY], ([base, lift]) => base + lift);
  const z5 = useTransform(x, (latestX) => {
    const depth = -latestX * 0.55;
    const nearBoost = Math.max(0, 1 - Math.abs(latestX) / (SPACING * 1.35));
    return depth + nearBoost * 24;
  });
  const scale = useTransform(x, (latestX) => {
    const t = Math.max(-1, Math.min(1, latestX / (SPACING * 2.1)));
    return 1 - Math.abs(t) * 0.025;
  });
  const opacity = useTransform(x, (latestX) => {
    const abs = Math.abs(latestX);
    if (abs > SPACING * 3.2) return 0;
    if (abs > SPACING * 2.4) return 1 - (abs - SPACING * 2.4) / (SPACING * 0.8);
    return 1;
  });
  const rotateY = reduceMotion ? -18 : -32;
  const rotateX = useTransform(wave, (w) => reduceMotion ? 6 : 10 + w / 22);
  const rotateZ = reduceMotion ? -3 : -6;
  useMotionValueEvent2(x, "change", (latestX) => {
    setNear(Math.abs(latestX) < SPACING * 2.15);
  });
  useEffect2(() => {
    gaze.set(gazed && !reduceMotion ? 1 : 0);
  }, [gazed, gaze, reduceMotion]);
  useEffect2(() => {
    if (near || !gazed) return;
    setGazed(false);
    onGazeChange?.(slot, null);
  }, [near, gazed, onGazeChange, slot]);
  return /* @__PURE__ */ jsx7(
    motion.div,
    {
      "aria-hidden": true,
      className: cn("pointer-events-none absolute", AUTH_RIVER_ANCHOR_CLASS),
      style: {
        x,
        y,
        z: z5,
        scale,
        opacity,
        rotateX,
        rotateY,
        rotateZ,
        transformStyle: "preserve-3d"
      },
      transformTemplate: ({ x: tx, y: ty, z: tz, scale: sc, rotateX: rx, rotateY: ry, rotateZ: rz }) => `translateX(calc(-50% + ${tx ?? 0})) translateY(calc(-50% + ${ty ?? 0})) translateZ(${tz ?? 0}) scale(${sc ?? 1}) rotateX(${rx ?? 0}) rotateY(${ry ?? 0}) rotateZ(${rz ?? 0})`,
      children: /* @__PURE__ */ jsxs4("div", { className: "relative flex flex-col items-center", children: [
        /* @__PURE__ */ jsxs4(
          motion.div,
          {
            className: cn(
              "yt-auth-bg-image relative cursor-default overflow-hidden rounded-[24px] bg-black",
              AUTH_RIVER_CARD_BOX_CLASS,
              near ? "pointer-events-auto" : "pointer-events-none"
            ),
            style: {
              backgroundImage: plane.imageVar,
              transformStyle: "preserve-3d",
              backfaceVisibility: "hidden",
              filter: PHOTO_FILTER,
              boxShadow: `0 0 0 1px ${plane.accent}33, 0 0 28px ${plane.accent}18`
            },
            onHoverStart: () => {
              setGazed(true);
              onGazeChange?.(slot, planeIndex);
            },
            onHoverEnd: () => {
              setGazed(false);
              onGazeChange?.(slot, null);
            },
            children: [
              /* @__PURE__ */ jsx7("div", { className: "absolute inset-0 bg-gradient-to-t from-black/45 via-transparent to-black/15" }),
              /* @__PURE__ */ jsx7("span", { className: "absolute left-2.5 top-2.5 font-mono text-[10px] font-medium tracking-[0.22em] text-white/40", children: indexLabel })
            ]
          }
        ),
        /* @__PURE__ */ jsx7("div", { className: "pointer-events-none mt-3 flex h-10 items-center justify-center", children: /* @__PURE__ */ jsx7(AnimatePresence, { mode: "wait", children: gazed ? /* @__PURE__ */ jsx7(
          motion.p,
          {
            initial: reduceMotion ? false : { opacity: 0, y: 8, filter: "blur(5px)" },
            animate: { opacity: 1, y: 0, filter: "blur(0px)" },
            exit: { opacity: 0, y: 4, filter: "blur(3px)" },
            transition: { duration: 0.28, ease: [0.22, 1, 0.36, 1] },
            className: cn(
              "whitespace-nowrap text-center text-base font-bold uppercase sm:text-lg",
              darkMode ? "text-white" : "text-stone-900"
            ),
            style: {
              textShadow: darkMode ? "0 2px 12px rgba(0,0,0,0.65)" : "0 1px 8px rgba(255,255,255,0.9)"
            },
            children: /* @__PURE__ */ jsx7(ScrambleLabel, { text: label, reduceMotion: Boolean(reduceMotion) })
          },
          label
        ) : null }) })
      ] })
    }
  );
}
function LoginSurfImmersive({
  className,
  darkMode = true,
  onActiveIndexChange,
  onAccentChange
}) {
  const runtime = useAuthRuntime();
  const reduceMotion = useReducedMotion();
  const { scrollX, wave, handlePan, handlePanEnd, setViewportRef } = useAuthRiverDrive({
    baseSpeed: AUTOPLAY_SPEED,
    period: PERIOD,
    scrollStart: SCROLL_START,
    scrollResetAt: SCROLL_RESET_AT,
    reduceMotion
  });
  const [activeIndex, setActiveIndex] = useState2(nearestPlaneIndex(SCROLL_START));
  const [gazeIndex, setGazeIndex] = useState2(null);
  const gazeSlotRef = useRef2(null);
  const slots = useMemo2(() => STRIP_SLOTS, []);
  const bleedIndex = gazeIndex ?? activeIndex;
  const bleedAccent = SURF_PLANES[bleedIndex]?.accent ?? SURF_PLANES[0].accent;
  useEffect2(() => {
    onAccentChange?.(bleedAccent);
  }, [bleedAccent, onAccentChange]);
  const handleGazeChange = (slot, planeIndex) => {
    if (planeIndex != null) {
      gazeSlotRef.current = slot;
      setGazeIndex(planeIndex);
      return;
    }
    if (gazeSlotRef.current === slot) {
      gazeSlotRef.current = null;
      setGazeIndex(null);
    }
  };
  useMotionValueEvent2(scrollX, "change", (latest) => {
    const idx = nearestPlaneIndex(latest);
    setActiveIndex(idx);
    onActiveIndexChange?.(idx);
  });
  if (reduceMotion) {
    return /* @__PURE__ */ jsx7(
      "div",
      {
        className: cn(
          "pointer-events-none absolute inset-0 flex items-center justify-center gap-4 overflow-hidden opacity-45",
          className
        ),
        "aria-hidden": true,
        children: SURF_PLANES.slice(0, 3).map((p) => /* @__PURE__ */ jsx7(
          "div",
          {
            className: "yt-auth-bg-image h-64 w-44 rounded-[24px] object-cover shadow-2xl",
            style: { backgroundImage: p.imageVar }
          },
          p.id
        ))
      }
    );
  }
  return /* @__PURE__ */ jsxs4(
    "div",
    {
      className: cn("absolute inset-0 overflow-hidden", className),
      "aria-hidden": true,
      "aria-label": runtime.t("surfStageLabel"),
      children: [
        /* @__PURE__ */ jsx7("div", { className: "absolute inset-0", style: { backgroundColor: darkMode ? AUTH_DARK_SHELL : "#ffffff" } }),
        /* @__PURE__ */ jsx7(AuthRiverWash, { darkMode, accent: bleedAccent }),
        /* @__PURE__ */ jsx7(
          motion.div,
          {
            ref: setViewportRef,
            className: "absolute inset-0 z-[1] cursor-grab touch-none active:cursor-grabbing",
            style: {
              perspective: AUTH_RIVER_PERSPECTIVE,
              perspectiveOrigin: AUTH_RIVER_PERSPECTIVE_ORIGIN
            },
            onPan: handlePan,
            onPanEnd: handlePanEnd,
            children: /* @__PURE__ */ jsx7("div", { className: "relative h-full w-full", style: { transformStyle: "preserve-3d" }, children: slots.map((item) => /* @__PURE__ */ jsx7(
              ImmersivePlane,
              {
                slot: item.slot,
                planeIndex: item.planeIndex,
                scrollX,
                wave,
                reduceMotion,
                darkMode,
                onGazeChange: handleGazeChange
              },
              item.key
            )) })
          }
        ),
        /* @__PURE__ */ jsx7(AuthRiverVignette, { darkMode })
      ]
    }
  );
}

// src/components/SignInForm.tsx
import { jsx as jsx8, jsxs as jsxs5 } from "react/jsx-runtime";
function SignInForm({
  className,
  redirectTo,
  signUpPath = "/signup",
  forgotPasswordPath = "/forgot-password",
  defaultRedirectPath = "/",
  guideRedirectPath = "/guide",
  readRedirectParam = true,
  signupPromptSlot,
  onEmailVerificationRequired,
  ...runtimeOverrides
}) {
  const runtime = useAuthRuntime(runtimeOverrides);
  const [username, setUsername] = useState3("");
  const [password, setPassword] = useState3("");
  const [showPassword, setShowPassword] = useState3(false);
  const [isSubmitting, setIsSubmitting] = useState3(false);
  const [resolvedRedirectTo, setResolvedRedirectTo] = useState3(redirectTo ?? null);
  const [accent, setAccent] = useState3(SURF_PLANES[0].accent);
  const usernameRef = useRef3(null);
  const darkMode = runtime.darkMode ?? false;
  useEffect3(() => {
    if (redirectTo !== void 0) {
      setResolvedRedirectTo(redirectTo);
      return;
    }
    if (readRedirectParam && typeof window !== "undefined") {
      setResolvedRedirectTo(readRedirectFromLocation());
    }
  }, [readRedirectParam, redirectTo]);
  function navigateAfterLogin(role) {
    const target = resolvedRedirectTo ?? (role === "guide" ? guideRedirectPath : defaultRedirectPath);
    runtime.navigate?.(target);
  }
  async function handleSubmit(event) {
    event.preventDefault();
    if (!username || !password) {
      runtime.toast?.({
        title: runtime.t("error.title"),
        description: runtime.t("error.fillAllFields"),
        variant: "destructive"
      });
      return;
    }
    setIsSubmitting(true);
    try {
      const result = await runtime.apiClient.signIn({ username, password });
      await runtime.onAuthenticated?.(result, {
        redirectTo: resolvedRedirectTo,
        flow: runtime.flow ?? null
      });
      runtime.toast?.({
        title: runtime.t("toast.loginSuccessTitle"),
        description: runtime.t("toast.loginSuccessDescription"),
        variant: "success"
      });
      navigateAfterLogin(result.role);
    } catch (error) {
      if (isAuthError(error, "EMAIL_VERIFICATION_REQUIRED")) {
        onEmailVerificationRequired?.(error, { identifier: username });
        runtime.toast?.({
          title: runtime.t("emailVerification.title"),
          description: runtime.t("emailVerification.description"),
          variant: "destructive"
        });
      } else {
        runtime.toast?.({
          title: runtime.t("toast.loginFailedTitle"),
          description: runtime.t("toast.loginFailedDescription"),
          variant: "destructive"
        });
      }
    } finally {
      setIsSubmitting(false);
    }
  }
  const signupHref = resolvedRedirectTo ? `${signUpPath}?redirect=${encodeURIComponent(resolvedRedirectTo)}` : signUpPath;
  return /* @__PURE__ */ jsx8(AuthRoot, { darkMode, className, children: /* @__PURE__ */ jsx8(
    AuthSplitStage,
    {
      formWidth: "35%",
      stickyStage: true,
      stage: /* @__PURE__ */ jsx8("div", { className: "absolute inset-0", style: { "--surf-accent": accent }, children: /* @__PURE__ */ jsx8(LoginSurfImmersive, { darkMode, onAccentChange: setAccent }) }),
      children: /* @__PURE__ */ jsxs5("div", { id: "login-form", className: cn("w-full space-y-6"), children: [
        /* @__PURE__ */ jsxs5("div", { className: "text-left", children: [
          /* @__PURE__ */ jsx8("h2", { className: "text-3xl font-bold tracking-tight text-stone-800 dark:text-gray-100", children: runtime.t("loginTitle") }),
          signupPromptSlot ?? /* @__PURE__ */ jsxs5("p", { className: "mt-2 text-sm leading-normal text-stone-600 dark:text-gray-300", children: [
            runtime.t("dontHaveAccount", void 0, "New to YaoTu?"),
            " ",
            /* @__PURE__ */ jsx8(
              AuthLink,
              {
                href: signupHref,
                LinkComponent: runtime.LinkComponent,
                className: "font-semibold text-primary underline-offset-2 hover:text-primary/90 hover:underline",
                children: runtime.t("signupButton", void 0, "Explore pre-launch access")
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxs5("form", { className: "space-y-6", onSubmit: handleSubmit, "data-testid": "voyage-login-form", children: [
          /* @__PURE__ */ jsxs5("div", { className: AUTH_FIELD_GAP, children: [
            /* @__PURE__ */ jsx8(
              AuthField,
              {
                ref: usernameRef,
                id: "immersive-username",
                name: "username",
                type: "text",
                autoComplete: "username",
                value: username,
                onChange: (event) => setUsername(event.target.value),
                label: runtime.t("username"),
                placeholder: runtime.t("usernamePlaceholder"),
                labelClassName: "text-gray-900 dark:text-white",
                "data-testid": "voyage-login-username"
              }
            ),
            /* @__PURE__ */ jsx8(
              AuthPasswordField,
              {
                id: "immersive-password",
                name: "password",
                autoComplete: "current-password",
                value: password,
                onChange: (event) => setPassword(event.target.value),
                label: runtime.t("password"),
                placeholder: runtime.t("passwordPlaceholder"),
                showPassword,
                onToggleShow: () => setShowPassword((value) => !value),
                labelClassName: "text-gray-900 dark:text-white",
                "data-testid": "voyage-login-password"
              }
            )
          ] }),
          /* @__PURE__ */ jsx8("div", { children: /* @__PURE__ */ jsx8(
            AuthLink,
            {
              href: forgotPasswordPath,
              LinkComponent: runtime.LinkComponent,
              className: "text-sm font-medium text-stone-600 underline-offset-2 hover:text-primary hover:underline dark:text-gray-300",
              children: runtime.t("forgotPassword")
            }
          ) }),
          /* @__PURE__ */ jsx8(
            Button,
            {
              type: "submit",
              "data-testid": "voyage-login-submit",
              disabled: isSubmitting,
              className: "btn-primary h-12 w-full rounded-2xl text-base text-stone-900",
              children: isSubmitting ? runtime.t("signingIn") : runtime.t("loginButton")
            }
          )
        ] })
      ] })
    }
  ) });
}

// src/components/SignUpForm.tsx
import { useEffect as useEffect5, useRef as useRef5, useState as useState5 } from "react";

// src/components/ui/checkbox.tsx
import * as React4 from "react";
import * as CheckboxPrimitive from "@radix-ui/react-checkbox";
import { Check } from "lucide-react";
import { jsx as jsx9 } from "react/jsx-runtime";
var Checkbox = React4.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx9(
  CheckboxPrimitive.Root,
  {
    ref,
    className: cn(
      "peer h-10 w-10 shrink-0 rounded-md border border-primary ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground sm:h-8 sm:w-8",
      className
    ),
    ...props,
    children: /* @__PURE__ */ jsx9(CheckboxPrimitive.Indicator, { className: "flex items-center justify-center text-current", children: /* @__PURE__ */ jsx9(Check, { className: "h-4 w-4" }) })
  }
));
Checkbox.displayName = CheckboxPrimitive.Root.displayName;

// src/components/visual/loginMascots.ts
var LOGIN_MASCOT_COLOR_PICKER_IDS = [
  "logician",
  "protector",
  "entertainer",
  "diplomat"
];
var LOGIN_MASCOT_UNKNOWN_ID = "unknown";
var LOGIN_MASCOT_PICKER_OPTION_IDS = [
  ...LOGIN_MASCOT_COLOR_PICKER_IDS,
  LOGIN_MASCOT_UNKNOWN_ID
];
var UNKNOWN_MASCOT_THEME = {
  glow: "from-stone-100/90 via-amber-50/50 to-transparent dark:from-stone-900/40 dark:via-stone-950/20",
  ring: "ring-stone-300",
  button: "bg-[#F3EEE6]",
  buttonHover: "hover:bg-[#EBE4DA]",
  buttonShadow: "shadow-[0_4px_0_0_#C9B8A0]",
  focusRing: "focus-visible:ring-stone-400"
};
var UNKNOWN_MASCOT_AVATAR_IMAGE_VAR = "var(--yt-auth-mbti-avatar-unknown)";
function isLoginMascotPickerOptionId(value) {
  return value === LOGIN_MASCOT_UNKNOWN_ID || LOGIN_MASCOT_COLOR_PICKER_IDS.includes(value ?? "");
}
var LOGIN_MASCOT_STORAGE_KEY = "lg-login-mascot";
var LOGIN_MASCOTS = [
  {
    id: "logician",
    imageVar: "var(--yt-auth-mbti-purple)",
    nameKey: "mascot.logician",
    mbtiCode: "INTP",
    theme: {
      glow: "from-violet-100/90 via-purple-50/50 to-transparent dark:from-violet-950/40 dark:via-purple-950/20",
      ring: "ring-violet-400",
      button: "bg-violet-400",
      buttonHover: "hover:bg-violet-500",
      buttonShadow: "shadow-[0_4px_0_0_#7c3aed]",
      focusRing: "focus-visible:ring-violet-500"
    },
    float: { y: -11, duration: 3.8 }
  },
  {
    id: "protector",
    imageVar: "var(--yt-auth-mbti-blue)",
    nameKey: "mascot.protector",
    mbtiCode: "ISFJ",
    theme: {
      glow: "from-sky-100/90 via-cyan-50/50 to-transparent dark:from-sky-950/40 dark:via-cyan-950/20",
      ring: "ring-sky-400",
      button: "bg-sky-400",
      buttonHover: "hover:bg-sky-500",
      buttonShadow: "shadow-[0_4px_0_0_#0284c7]",
      focusRing: "focus-visible:ring-sky-500"
    },
    float: { y: -12, duration: 3.4 }
  },
  {
    id: "entertainer",
    imageVar: "var(--yt-auth-mbti-yellow)",
    nameKey: "mascot.entertainer",
    mbtiCode: "ESFP",
    theme: {
      glow: "from-amber-100/90 via-yellow-50/50 to-transparent dark:from-amber-950/40 dark:via-yellow-950/20",
      ring: "ring-yellow-400",
      button: "bg-yellow-400",
      buttonHover: "hover:bg-yellow-500",
      buttonShadow: "shadow-[0_4px_0_0_#ca8a04]",
      focusRing: "focus-visible:ring-yellow-500"
    },
    float: { y: -14, duration: 3.1 }
  },
  {
    id: "diplomat",
    imageVar: "var(--yt-auth-mbti-green)",
    nameKey: "mascot.diplomat",
    mbtiCode: "INFP",
    theme: {
      glow: "from-lime-100/90 via-emerald-50/50 to-transparent dark:from-lime-950/40 dark:via-emerald-950/20",
      ring: "ring-lime-400",
      button: "bg-lime-400",
      buttonHover: "hover:bg-lime-500",
      buttonShadow: "shadow-[0_4px_0_0_#65a30d]",
      focusRing: "focus-visible:ring-lime-500"
    },
    float: { y: -12, duration: 3.5 }
  },
  {
    id: "explorer",
    imageVar: "var(--yt-auth-mbti-explorer)",
    nameKey: "mascot.explorer",
    mbtiCode: "ENFP",
    theme: {
      glow: "from-emerald-100/90 via-green-50/50 to-transparent dark:from-emerald-950/40 dark:via-green-950/20",
      ring: "ring-emerald-400",
      button: "bg-emerald-400",
      buttonHover: "hover:bg-emerald-500",
      buttonShadow: "shadow-[0_4px_0_0_#059669]",
      focusRing: "focus-visible:ring-emerald-500"
    },
    float: { y: -13, duration: 3.3 }
  },
  {
    id: "lantern",
    imageVar: "var(--yt-auth-mbti-lantern)",
    nameKey: "mascot.lantern",
    mbtiCode: "ENFJ",
    theme: {
      glow: "from-teal-100/90 via-emerald-50/50 to-transparent dark:from-teal-950/40 dark:via-emerald-950/20",
      ring: "ring-teal-400",
      button: "bg-teal-400",
      buttonHover: "hover:bg-teal-500",
      buttonShadow: "shadow-[0_4px_0_0_#0f766e]",
      focusRing: "focus-visible:ring-teal-500"
    },
    float: { y: -12, duration: 3.6 }
  }
];
var DEFAULT_LOGIN_MASCOT_ID = "logician";
function getLoginMascot(id) {
  return LOGIN_MASCOTS.find((m) => m.id === id) ?? LOGIN_MASCOTS[0];
}
function isLoginMascotId(value) {
  return LOGIN_MASCOTS.some((m) => m.id === value);
}
function readStoredLoginMascotId() {
  if (typeof window === "undefined") return DEFAULT_LOGIN_MASCOT_ID;
  try {
    const raw = window.localStorage.getItem(LOGIN_MASCOT_STORAGE_KEY);
    if (isLoginMascotId(raw)) return raw;
  } catch {
  }
  return DEFAULT_LOGIN_MASCOT_ID;
}
function storeLoginMascotId(id) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(LOGIN_MASCOT_STORAGE_KEY, id);
  } catch {
  }
}
var MASCOT_ACCENTS = {
  diplomat: "#84cc16",
  entertainer: "#facc15",
  logician: "#a78bfa",
  protector: "#38bdf8",
  explorer: "#34d399",
  lantern: "#2dd4bf"
};

// src/components/visual/LoginMascotPicker.tsx
import { jsx as jsx10, jsxs as jsxs6 } from "react/jsx-runtime";
var AVATAR_SPRITE_POSITION = {
  protector: "0% 0%",
  logician: "100% 0%",
  entertainer: "0% 100%",
  diplomat: "100% 100%"
};
function LoginMascotPicker({ selectedId, onSelect }) {
  const runtime = useAuthRuntime();
  return /* @__PURE__ */ jsxs6("div", { children: [
    /* @__PURE__ */ jsx10("p", { className: "mb-3 text-center text-sm font-medium text-stone-600 dark:text-gray-300 lg:text-left", children: runtime.t("pickMascot") }),
    /* @__PURE__ */ jsx10(
      "div",
      {
        className: "grid grid-cols-5 items-start gap-1 sm:gap-2 lg:gap-3",
        role: "radiogroup",
        "aria-label": runtime.t("pickMascot"),
        children: LOGIN_MASCOT_PICKER_OPTION_IDS.map((id) => {
          const isUnknown = id === LOGIN_MASCOT_UNKNOWN_ID;
          const mascot = isUnknown ? null : getLoginMascot(id);
          const theme = mascot?.theme ?? UNKNOWN_MASCOT_THEME;
          const selected = id === selectedId;
          const name = isUnknown ? runtime.t("mascot.unknown") : runtime.t(mascot.nameKey);
          return /* @__PURE__ */ jsxs6(
            "button",
            {
              type: "button",
              role: "radio",
              "aria-checked": selected,
              "aria-label": name,
              title: name,
              onClick: () => onSelect(id),
              className: cn(
                "group flex w-full min-w-0 flex-col items-center gap-1 border-0 bg-transparent p-0 transition-transform hover:scale-105 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 dark:ring-offset-[#0e0e0e]",
                theme.ring,
                selected && "scale-105 sm:scale-110"
              ),
              children: [
                /* @__PURE__ */ jsx10("span", { className: "sr-only", children: name }),
                /* @__PURE__ */ jsx10(
                  "span",
                  {
                    "aria-hidden": "true",
                    className: cn(
                      "block h-11 w-11 bg-contain bg-center bg-no-repeat transition-[filter,opacity] sm:h-14 sm:w-14",
                      selected ? "opacity-100 drop-shadow-[0_3px_4px_rgba(0,0,0,0.2)]" : "opacity-65 grayscale group-hover:opacity-90"
                    ),
                    style: {
                      backgroundImage: isUnknown ? UNKNOWN_MASCOT_AVATAR_IMAGE_VAR : "var(--yt-auth-mbti-avatar-sprite)",
                      backgroundPosition: isUnknown ? "center" : AVATAR_SPRITE_POSITION[id],
                      backgroundSize: isUnknown ? "contain" : "200% 200%"
                    }
                  }
                ),
                /* @__PURE__ */ jsx10(
                  "span",
                  {
                    "aria-hidden": "true",
                    className: cn(
                      "w-full text-center text-[11px] font-medium leading-tight text-stone-500 transition-colors sm:text-sm sm:leading-5 dark:text-gray-400",
                      selected && "text-stone-800 dark:text-gray-100"
                    ),
                    children: name
                  }
                )
              ]
            },
            id
          );
        })
      }
    )
  ] });
}

// src/components/visual/LoginMascotPullImmersive.tsx
import { useEffect as useEffect4, useMemo as useMemo3, useRef as useRef4, useState as useState4 } from "react";
import {
  AnimatePresence as AnimatePresence2,
  motion as motion2,
  useMotionValue as useMotionValue2,
  useMotionValueEvent as useMotionValueEvent3,
  useReducedMotion as useReducedMotion2,
  useSpring as useSpring3,
  useTransform as useTransform2
} from "framer-motion";
import { jsx as jsx11, jsxs as jsxs7 } from "react/jsx-runtime";
var COUNT2 = LOGIN_MASCOTS.length;
var SPACING2 = 210;
var PERIOD2 = COUNT2 * SPACING2;
var COPIES2 = 3;
var AUTOPLAY_SPEED2 = 30;
var SCROLL_START2 = PERIOD2;
var SCROLL_RESET_AT2 = PERIOD2 * 2;
var SCRAMBLE_GLYPHS2 = "ABCDEFGHJKLMNPQRSTUVWXYZ\u30A1\u30A2\u30A6\u30A8\u30AA\u30AB\u30AD\u30AF\u30B1\u30B3";
var STRIP_SLOTS2 = Array.from({ length: COPIES2 * COUNT2 }, (_, slot) => {
  const planeIndex = slot % COUNT2;
  const copy = Math.floor(slot / COUNT2);
  return {
    slot,
    planeIndex,
    key: `${copy}-${LOGIN_MASCOTS[planeIndex].id}`
  };
});
function nearestPlaneIndex2(scroll) {
  const idx = Math.round(scroll / SPACING2);
  return (idx % COUNT2 + COUNT2) % COUNT2;
}
function ScrambleLabel2({ text, reduceMotion }) {
  const [display, setDisplay] = useState4(reduceMotion ? text : "");
  useEffect4(() => {
    if (reduceMotion) {
      setDisplay(text);
      return;
    }
    let frame = 0;
    const settleAt = Math.max(14, text.length * 2 + 6);
    const id = window.setInterval(() => {
      frame += 1;
      setDisplay(
        text.split("").map((ch, index) => {
          if (ch === " " || ch === "\u8DEF") return ch;
          if (frame > index * 2 + 5) return text[index];
          return SCRAMBLE_GLYPHS2[Math.floor(Math.random() * SCRAMBLE_GLYPHS2.length)];
        }).join("")
      );
      if (frame >= settleAt) {
        setDisplay(text);
        window.clearInterval(id);
      }
    }, 26);
    return () => window.clearInterval(id);
  }, [text, reduceMotion]);
  return /* @__PURE__ */ jsx11("span", { className: "tabular-nums tracking-[0.14em]", children: display || "\xA0" });
}
function MascotPullPlane({
  slot,
  planeIndex,
  scrollX,
  wave,
  scrollPull,
  reduceMotion,
  darkMode,
  selected,
  onGazeChange,
  onSelect
}) {
  const runtime = useAuthRuntime();
  const mascot = LOGIN_MASCOTS[planeIndex];
  const label = mascot.mbtiCode;
  const a11yLabel = runtime.t(mascot.nameKey);
  const [gazed, setGazed] = useState4(false);
  const [near, setNear] = useState4(true);
  const gaze = useSpring3(0, { stiffness: 260, damping: 26, mass: 0.4 });
  const x = useTransform2(scrollX, (latest) => slot * SPACING2 - latest);
  const yBase = useTransform2([x, wave], ([latestX, latestWave]) => {
    const ribbon = latestX * 0.28;
    if (reduceMotion) return ribbon;
    return ribbon + Math.sin(latestX / 100) * (latestWave * 0.55);
  });
  const liftY = useTransform2(gaze, [0, 1], [0, -6]);
  const y = useTransform2(
    [yBase, liftY, scrollPull],
    ([base, lift, pull]) => base + lift + pull
  );
  const z5 = useTransform2(x, (latestX) => {
    const depth = -latestX * 0.55;
    const nearBoost = Math.max(0, 1 - Math.abs(latestX) / (SPACING2 * 1.35));
    return depth + nearBoost * 24;
  });
  const scale = useTransform2(x, (latestX) => {
    const t = Math.max(-1, Math.min(1, latestX / (SPACING2 * 2.1)));
    return 1 - Math.abs(t) * 0.025;
  });
  const opacity = useTransform2(x, (latestX) => {
    const abs = Math.abs(latestX);
    if (abs > SPACING2 * 3.2) return 0;
    if (abs > SPACING2 * 2.4) return 1 - (abs - SPACING2 * 2.4) / (SPACING2 * 0.8);
    return 1;
  });
  const rotateY = reduceMotion ? -18 : -32;
  const rotateX = useTransform2(wave, (w) => reduceMotion ? 6 : 10 + w / 22);
  const rotateZ = reduceMotion ? -3 : -6;
  useMotionValueEvent3(x, "change", (latestX) => {
    setNear(Math.abs(latestX) < SPACING2 * 2.15);
  });
  useEffect4(() => {
    gaze.set(gazed && !reduceMotion ? 1 : 0);
  }, [gazed, gaze, reduceMotion]);
  useEffect4(() => {
    if (near || !gazed) return;
    setGazed(false);
    onGazeChange?.(slot, null);
  }, [near, gazed, onGazeChange, slot]);
  return /* @__PURE__ */ jsx11(
    motion2.div,
    {
      className: cn("pointer-events-none absolute", AUTH_RIVER_ANCHOR_CLASS),
      style: {
        x,
        y,
        z: z5,
        scale,
        opacity,
        rotateX,
        rotateY,
        rotateZ,
        transformStyle: "preserve-3d"
      },
      transformTemplate: ({ x: tx, y: ty, z: tz, scale: sc, rotateX: rx, rotateY: ry, rotateZ: rz }) => `translateX(calc(-50% + ${tx ?? 0})) translateY(calc(-50% + ${ty ?? 0})) translateZ(${tz ?? 0}) scale(${sc ?? 1}) rotateX(${rx ?? 0}) rotateY(${ry ?? 0}) rotateZ(${rz ?? 0})`,
      children: /* @__PURE__ */ jsxs7("div", { className: "relative flex flex-col items-center", children: [
        /* @__PURE__ */ jsx11(
          motion2.button,
          {
            type: "button",
            "aria-label": a11yLabel,
            "aria-pressed": selected,
            className: cn(
              "yt-auth-bg-image relative block cursor-pointer overflow-hidden rounded-[24px] border-0 bg-black p-0 shadow-none outline-none focus:outline-none focus-visible:outline-none",
              AUTH_RIVER_CARD_BOX_CLASS,
              near ? "pointer-events-auto" : "pointer-events-none",
              selected && "ring-2 ring-yellow-400 ring-offset-2 ring-offset-transparent dark:ring-offset-[#0e0e0e]"
            ),
            style: {
              backgroundImage: mascot.imageVar,
              transformStyle: "preserve-3d",
              backfaceVisibility: "hidden",
              boxShadow: selected ? `0 0 0 1px ${MASCOT_ACCENTS[mascot.id]}66, 0 0 28px ${MASCOT_ACCENTS[mascot.id]}33` : void 0
            },
            onHoverStart: () => {
              setGazed(true);
              onGazeChange?.(slot, planeIndex);
            },
            onHoverEnd: () => {
              setGazed(false);
              onGazeChange?.(slot, null);
            },
            onClick: () => onSelect?.(mascot.id)
          }
        ),
        /* @__PURE__ */ jsx11("div", { className: "pointer-events-none mt-3 flex h-10 items-center justify-center", children: /* @__PURE__ */ jsx11(AnimatePresence2, { mode: "wait", children: gazed ? /* @__PURE__ */ jsx11(
          motion2.p,
          {
            initial: reduceMotion ? false : { opacity: 0, y: 8, filter: "blur(5px)" },
            animate: { opacity: 1, y: 0, filter: "blur(0px)" },
            exit: { opacity: 0, y: 4, filter: "blur(3px)" },
            transition: { duration: 0.28, ease: [0.22, 1, 0.36, 1] },
            className: cn(
              "whitespace-nowrap text-center text-base font-bold tracking-[0.18em] sm:text-lg",
              darkMode ? "text-white" : "text-stone-900"
            ),
            style: {
              textShadow: darkMode ? "0 2px 12px rgba(0,0,0,0.65)" : "0 1px 8px rgba(255,255,255,0.9)"
            },
            children: /* @__PURE__ */ jsx11(ScrambleLabel2, { text: label, reduceMotion: Boolean(reduceMotion) })
          },
          label
        ) : null }) })
      ] })
    }
  );
}
function LoginMascotPullImmersive({
  className,
  darkMode = false,
  selectedId = null,
  onSelect,
  onAccentChange
}) {
  const runtime = useAuthRuntime();
  const reduceMotion = useReducedMotion2();
  const { scrollX, wave, handlePan, handlePanEnd, setViewportRef } = useAuthRiverDrive({
    baseSpeed: AUTOPLAY_SPEED2,
    period: PERIOD2,
    scrollStart: SCROLL_START2,
    scrollResetAt: SCROLL_RESET_AT2,
    reduceMotion
  });
  const scrollPullTarget = useMotionValue2(0);
  const scrollPull = useSpring3(scrollPullTarget, { stiffness: 120, damping: 24, mass: 0.55 });
  const [activeIndex, setActiveIndex] = useState4(nearestPlaneIndex2(SCROLL_START2));
  const [gazeIndex, setGazeIndex] = useState4(null);
  const gazeSlotRef = useRef4(null);
  const slots = useMemo3(() => STRIP_SLOTS2, []);
  const selectedIndex = selectedId ? LOGIN_MASCOTS.findIndex((m) => m.id === selectedId) : -1;
  const bleedIndex = gazeIndex ?? (selectedIndex >= 0 ? selectedIndex : activeIndex);
  const bleedAccent = MASCOT_ACCENTS[LOGIN_MASCOTS[bleedIndex]?.id ?? "entertainer"] ?? "#facc15";
  useEffect4(() => {
    onAccentChange?.(bleedAccent);
  }, [bleedAccent, onAccentChange]);
  const handleGazeChange = (slot, planeIndex) => {
    if (planeIndex != null) {
      gazeSlotRef.current = slot;
      setGazeIndex(planeIndex);
      return;
    }
    if (gazeSlotRef.current === slot) {
      gazeSlotRef.current = null;
      setGazeIndex(null);
    }
  };
  useMotionValueEvent3(scrollX, "change", (latest) => {
    setActiveIndex(nearestPlaneIndex2(latest));
  });
  useEffect4(() => {
    if (reduceMotion) return;
    const handleWheel = (event) => {
      const next = Math.max(-120, Math.min(120, scrollPullTarget.get() - event.deltaY * 0.16));
      scrollPullTarget.set(next);
    };
    window.addEventListener("wheel", handleWheel, { passive: true });
    return () => window.removeEventListener("wheel", handleWheel);
  }, [reduceMotion, scrollPullTarget]);
  if (reduceMotion) {
    return /* @__PURE__ */ jsx11(
      "div",
      {
        className: cn(
          "absolute inset-0 flex flex-wrap items-center justify-center gap-3 overflow-hidden px-4",
          className
        ),
        "aria-label": runtime.t("pickMascot"),
        children: LOGIN_MASCOTS.map((m) => /* @__PURE__ */ jsx11(
          "button",
          {
            type: "button",
            onClick: () => onSelect?.(m.id),
            className: cn(
              "yt-auth-bg-image overflow-visible border-0 bg-transparent p-0",
              AUTH_RIVER_CARD_BOX_CLASS,
              selectedId === m.id && "outline outline-2 outline-offset-2 outline-yellow-400"
            ),
            style: { backgroundImage: m.imageVar }
          },
          m.id
        ))
      }
    );
  }
  return /* @__PURE__ */ jsxs7(
    "div",
    {
      className: cn("absolute inset-0 overflow-hidden", className),
      "aria-label": runtime.t("mbtiStageLabel"),
      children: [
        /* @__PURE__ */ jsx11("div", { className: "absolute inset-0", style: { backgroundColor: darkMode ? AUTH_DARK_SHELL : "#ffffff" } }),
        /* @__PURE__ */ jsx11(AuthRiverWash, { darkMode, accent: bleedAccent }),
        /* @__PURE__ */ jsx11(
          motion2.div,
          {
            ref: setViewportRef,
            className: "absolute inset-0 z-[1] cursor-grab touch-none active:cursor-grabbing",
            style: {
              perspective: AUTH_RIVER_PERSPECTIVE,
              perspectiveOrigin: AUTH_RIVER_PERSPECTIVE_ORIGIN
            },
            onPan: handlePan,
            onPanEnd: handlePanEnd,
            children: /* @__PURE__ */ jsx11("div", { className: "relative h-full w-full", style: { transformStyle: "preserve-3d" }, children: slots.map((item) => /* @__PURE__ */ jsx11(
              MascotPullPlane,
              {
                slot: item.slot,
                planeIndex: item.planeIndex,
                scrollX,
                wave,
                scrollPull,
                reduceMotion,
                darkMode,
                selected: LOGIN_MASCOTS[item.planeIndex]?.id === selectedId,
                onGazeChange: handleGazeChange,
                onSelect
              },
              item.key
            )) })
          }
        ),
        /* @__PURE__ */ jsx11(AuthRiverVignette, { darkMode })
      ]
    }
  );
}

// src/components/SignUpForm.tsx
import { jsx as jsx12, jsxs as jsxs8 } from "react/jsx-runtime";
function appendQueryParam(path, key, value) {
  const base = typeof window !== "undefined" ? window.location.origin : "https://www.ahhh-yaotu.com";
  const url = new URL(path, base);
  url.searchParams.set(key, value);
  if (/^https?:\/\//i.test(path)) {
    return url.toString();
  }
  return `${url.pathname}${url.search}${url.hash}`;
}
function SignUpForm({
  className,
  redirectTo,
  loginPath = "/login",
  verifyEmailPath = "/verify-email",
  termsPath = "/terms",
  privacyPath = "/privacy",
  readRedirectParam = true,
  signupIntentToken,
  ...runtimeOverrides
}) {
  const runtime = useAuthRuntime(runtimeOverrides);
  const [formData, setFormData] = useState5({
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
    firstName: "",
    lastName: ""
  });
  const [agreedToTerms, setAgreedToTerms] = useState5(false);
  const [resolvedRedirectTo, setResolvedRedirectTo] = useState5(redirectTo ?? null);
  const [mascotId, setMascotId] = useState5(null);
  const [usernameError, setUsernameError] = useState5("");
  const [usernameSuggestion, setUsernameSuggestion] = useState5("");
  const [isCheckingUsername, setIsCheckingUsername] = useState5(false);
  const [passwordError, setPasswordError] = useState5("");
  const [confirmPasswordError, setConfirmPasswordError] = useState5("");
  const [termsError, setTermsError] = useState5("");
  const [formError, setFormError] = useState5("");
  const [showPassword, setShowPassword] = useState5(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState5(false);
  const [isSubmitting, setIsSubmitting] = useState5(false);
  const usernameCheckTimeoutRef = useRef5(null);
  const signupRequestInFlightRef = useRef5(false);
  const scenicMascotId = mascotId && mascotId !== LOGIN_MASCOT_UNKNOWN_ID ? mascotId : null;
  const mascot = scenicMascotId ? getLoginMascot(scenicMascotId) : null;
  const submitTheme = mascotId === LOGIN_MASCOT_UNKNOWN_ID ? UNKNOWN_MASCOT_THEME : mascot?.theme ?? getLoginMascot("entertainer").theme;
  const darkMode = runtime.darkMode ?? false;
  const passwordStrength = calculatePasswordStrength(formData.password);
  useEffect5(() => {
    if (redirectTo !== void 0) {
      setResolvedRedirectTo(redirectTo);
      return;
    }
    if (readRedirectParam && typeof window !== "undefined") {
      setResolvedRedirectTo(readRedirectFromLocation());
    }
  }, [readRedirectParam, redirectTo]);
  useEffect5(() => {
    return () => {
      if (usernameCheckTimeoutRef.current) {
        window.clearTimeout(usernameCheckTimeoutRef.current);
      }
    };
  }, []);
  function selectMascot(id) {
    setMascotId(id);
    if (id === LOGIN_MASCOT_UNKNOWN_ID) return;
    storeLoginMascotId(id);
  }
  async function checkUsernameAvailability(username) {
    if (!validateUsername(username)) {
      setUsernameError(runtime.t("usernameValidation.invalidFormat"));
      setUsernameSuggestion("");
      return;
    }
    setIsCheckingUsername(true);
    try {
      const data = await runtime.apiClient.checkUsernameAvailability(username);
      if (data.available) {
        setUsernameError("");
        setUsernameSuggestion("");
      } else {
        setUsernameError(runtime.t("usernameValidation.taken"));
        setUsernameSuggestion(generateUsernameSuggestion(username));
      }
    } catch {
      setUsernameError(runtime.t("usernameValidation.errorChecking"));
    } finally {
      setIsCheckingUsername(false);
    }
  }
  function handleChange(event) {
    const { name, value } = event.target;
    if (name === "username") {
      const lowercaseValue = value.toLowerCase();
      setFormData((current) => ({ ...current, [name]: lowercaseValue }));
      if (usernameCheckTimeoutRef.current) {
        window.clearTimeout(usernameCheckTimeoutRef.current);
      }
      if (lowercaseValue.length >= 3) {
        usernameCheckTimeoutRef.current = window.setTimeout(() => {
          void checkUsernameAvailability(lowercaseValue);
        }, 500);
      } else {
        setUsernameError("");
        setUsernameSuggestion("");
      }
      return;
    }
    setFormData((current) => ({ ...current, [name]: value }));
  }
  async function handleSubmit(event) {
    event.preventDefault();
    if (signupRequestInFlightRef.current) return;
    setUsernameError("");
    setUsernameSuggestion("");
    setFormError("");
    setPasswordError("");
    setConfirmPasswordError("");
    setTermsError("");
    if (!formData.firstName || !formData.lastName) {
      setFormError(runtime.t("error.fillName"));
      return;
    }
    if (!validateUsername(formData.username)) {
      setUsernameError(runtime.t("usernameValidation.invalidFormat"));
      return;
    }
    if (formData.password.length < 8) {
      setPasswordError(runtime.t("error.passwordTooShort"));
      return;
    }
    if (passwordStrength.score <= 2) {
      setPasswordError(runtime.t("passwordHint"));
      return;
    }
    if (formData.password !== formData.confirmPassword) {
      setConfirmPasswordError(runtime.t("error.passwordMismatch"));
      return;
    }
    if (!agreedToTerms) {
      setTermsError(runtime.t("error.agreeTerms"));
      return;
    }
    const { firstName, lastName, confirmPassword: _confirmPassword, ...rest } = formData;
    const signupData = {
      ...rest,
      fullName: `${firstName} ${lastName}`,
      signupIntentToken: signupIntentToken?.trim() || void 0
    };
    signupRequestInFlightRef.current = true;
    setIsSubmitting(true);
    try {
      const result = await runtime.apiClient.signUp(signupData);
      if (mascotId && mascotId !== LOGIN_MASCOT_UNKNOWN_ID) storeLoginMascotId(mascotId);
      await runtime.onSignupVerificationRequired?.(result, {
        redirectTo: resolvedRedirectTo,
        flow: runtime.flow ?? null,
        submittedEmail: signupData.email
      });
      runtime.toast?.({
        title: runtime.t("toast.signupSuccessTitle"),
        description: runtime.t("toast.signupVerificationRequiredDescription"),
        variant: "success"
      });
      runtime.navigate?.(appendQueryParam(verifyEmailPath, "sent", "1"));
    } catch (error) {
      if (isAuthError(error, "USERNAME_TAKEN")) {
        setUsernameError(runtime.t("usernameValidation.taken"));
      } else {
        setFormError(error instanceof Error ? error.message : runtime.t("signupUnexpectedError"));
      }
    } finally {
      signupRequestInFlightRef.current = false;
      setIsSubmitting(false);
    }
  }
  const loginHref = resolvedRedirectTo ? `${loginPath}?redirect=${encodeURIComponent(resolvedRedirectTo)}` : loginPath;
  return /* @__PURE__ */ jsx12(AuthRoot, { darkMode, className, children: /* @__PURE__ */ jsx12(
    AuthSplitStage,
    {
      formWidth: "35%",
      stickyStage: true,
      stage: /* @__PURE__ */ jsx12(
        LoginMascotPullImmersive,
        {
          darkMode,
          selectedId: scenicMascotId,
          onSelect: (id) => {
            if (isLoginMascotPickerOptionId(id)) selectMascot(id);
          }
        }
      ),
      children: /* @__PURE__ */ jsxs8("div", { className: "w-full space-y-6", children: [
        /* @__PURE__ */ jsxs8("div", { className: "text-left", children: [
          /* @__PURE__ */ jsx12("h2", { className: "text-3xl font-bold tracking-tight text-stone-800 dark:text-gray-100", children: runtime.t("createAccount") }),
          /* @__PURE__ */ jsxs8("p", { className: "mt-2 text-sm leading-normal text-stone-600 dark:text-gray-300", children: [
            runtime.t("alreadyHaveAccount"),
            " ",
            /* @__PURE__ */ jsx12(
              AuthLink,
              {
                href: loginHref,
                LinkComponent: runtime.LinkComponent,
                "data-testid": "signup-sign-in",
                className: "font-semibold text-primary underline-offset-2 hover:text-primary/90 hover:underline",
                children: runtime.t("loginButton")
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsx12(LoginMascotPicker, { selectedId: mascotId, onSelect: selectMascot }),
        /* @__PURE__ */ jsxs8("form", { className: "space-y-6", onSubmit: handleSubmit, "data-testid": "voyage-signup-form", children: [
          /* @__PURE__ */ jsxs8("div", { className: "-ml-5 w-[calc(100%+20px)] space-y-4 pr-2.5", children: [
            formError && /* @__PURE__ */ jsx12("p", { className: "text-sm text-red-500", role: "alert", children: formError }),
            /* @__PURE__ */ jsxs8("div", { className: "mt-2 grid grid-cols-2 gap-4", children: [
              /* @__PURE__ */ jsx12(
                AuthField,
                {
                  id: "firstName",
                  name: "firstName",
                  type: "text",
                  value: formData.firstName,
                  onChange: handleChange,
                  label: runtime.t("firstName"),
                  placeholder: runtime.t("firstNamePlaceholder"),
                  labelClassName: "text-gray-900 dark:text-white",
                  required: true
                }
              ),
              /* @__PURE__ */ jsx12(
                AuthField,
                {
                  id: "lastName",
                  name: "lastName",
                  type: "text",
                  value: formData.lastName,
                  onChange: handleChange,
                  label: runtime.t("lastName"),
                  placeholder: runtime.t("lastNamePlaceholder"),
                  labelClassName: "text-gray-900 dark:text-white",
                  required: true
                }
              )
            ] }),
            /* @__PURE__ */ jsxs8("div", { children: [
              /* @__PURE__ */ jsx12(
                AuthField,
                {
                  id: "username",
                  name: "username",
                  type: "text",
                  value: formData.username,
                  onChange: handleChange,
                  error: Boolean(usernameError),
                  label: runtime.t("username"),
                  placeholder: runtime.t("usernameChoosePlaceholder"),
                  labelClassName: "text-gray-900 dark:text-white",
                  required: true
                }
              ),
              /* @__PURE__ */ jsx12("p", { className: "mt-1 text-xs text-gray-500 dark:text-white", children: runtime.t("usernameHelperText") }),
              isCheckingUsername && /* @__PURE__ */ jsx12("p", { className: "mt-1 text-sm text-gray-500 dark:text-white", children: runtime.t("checkingUsername") }),
              usernameError && /* @__PURE__ */ jsx12("p", { className: "mt-1 text-sm text-red-500", children: usernameError }),
              usernameSuggestion && /* @__PURE__ */ jsxs8("div", { className: "mt-1", children: [
                /* @__PURE__ */ jsx12("p", { className: "text-sm text-gray-600 dark:text-white", children: runtime.t("suggested") }),
                /* @__PURE__ */ jsx12(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      setFormData((current) => ({ ...current, username: usernameSuggestion }));
                      setUsernameError("");
                      setUsernameSuggestion("");
                    },
                    className: "text-sm text-blue-500 underline hover:text-blue-700",
                    children: usernameSuggestion
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsx12("div", { children: /* @__PURE__ */ jsx12(
              AuthField,
              {
                id: "email",
                name: "email",
                type: "email",
                value: formData.email,
                onChange: handleChange,
                label: runtime.t("email"),
                placeholder: runtime.t("emailPlaceholder"),
                labelClassName: "text-gray-900 dark:text-white"
              }
            ) }),
            /* @__PURE__ */ jsxs8("div", { children: [
              /* @__PURE__ */ jsx12(
                AuthPasswordField,
                {
                  id: "password",
                  name: "password",
                  autoComplete: "new-password",
                  value: formData.password,
                  onChange: handleChange,
                  error: Boolean(passwordError),
                  label: runtime.t("password"),
                  placeholder: runtime.t("passwordCreatePlaceholder"),
                  labelClassName: "text-gray-900 dark:text-white",
                  showPassword,
                  onToggleShow: () => setShowPassword((value) => !value),
                  required: true
                }
              ),
              formData.password && /* @__PURE__ */ jsxs8("div", { className: "mt-2", children: [
                /* @__PURE__ */ jsxs8("div", { className: "flex items-center space-x-2", children: [
                  /* @__PURE__ */ jsx12("div", { className: "h-2 flex-1 rounded-full bg-gray-200", children: /* @__PURE__ */ jsx12(
                    "div",
                    {
                      className: cn(
                        "h-2 rounded-full transition-all duration-300",
                        passwordStrength.score <= 2 ? "bg-red-500" : passwordStrength.score <= 3 ? "bg-yellow-500" : "bg-green-500"
                      ),
                      style: { width: `${passwordStrength.score / 5 * 100}%` }
                    }
                  ) }),
                  /* @__PURE__ */ jsx12("span", { className: cn("text-sm font-medium", passwordStrength.color), children: passwordStrength.labelKey ? runtime.t(passwordStrength.labelKey) : "" })
                ] }),
                /* @__PURE__ */ jsx12("div", { className: "mt-1 text-xs text-gray-500 dark:text-white", children: runtime.t("passwordHint") })
              ] }),
              passwordError && /* @__PURE__ */ jsx12("p", { className: "mt-1 text-sm text-red-500", children: passwordError })
            ] }),
            /* @__PURE__ */ jsxs8("div", { children: [
              /* @__PURE__ */ jsx12(
                AuthPasswordField,
                {
                  id: "confirmPassword",
                  name: "confirmPassword",
                  autoComplete: "new-password",
                  value: formData.confirmPassword,
                  onChange: handleChange,
                  error: Boolean(confirmPasswordError),
                  label: runtime.t("confirmPassword"),
                  placeholder: runtime.t("confirmPasswordPlaceholder"),
                  labelClassName: "text-gray-900 dark:text-white",
                  showPassword: showConfirmPassword,
                  onToggleShow: () => setShowConfirmPassword((value) => !value)
                }
              ),
              confirmPasswordError && /* @__PURE__ */ jsx12("p", { className: "mt-1 text-sm text-red-500", children: confirmPasswordError })
            ] })
          ] }),
          /* @__PURE__ */ jsxs8("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsxs8("div", { className: "flex items-start space-x-2", children: [
              /* @__PURE__ */ jsx12(
                Checkbox,
                {
                  id: "terms",
                  checked: agreedToTerms,
                  onCheckedChange: (checked) => setAgreedToTerms(Boolean(checked)),
                  className: "mt-1"
                }
              ),
              /* @__PURE__ */ jsxs8("label", { htmlFor: "terms", className: "text-sm leading-relaxed text-gray-600 dark:text-white", children: [
                runtime.t("terms.agreePrefix"),
                " ",
                /* @__PURE__ */ jsx12(
                  AuthLink,
                  {
                    href: termsPath,
                    LinkComponent: runtime.LinkComponent,
                    className: "inline-flex min-h-10 items-center align-middle text-primary underline hover:text-primary/90",
                    children: runtime.t("terms.termsOfService")
                  }
                ),
                " ",
                runtime.t("terms.and"),
                " ",
                /* @__PURE__ */ jsx12(
                  AuthLink,
                  {
                    href: privacyPath,
                    LinkComponent: runtime.LinkComponent,
                    className: "inline-flex min-h-10 items-center align-middle text-primary underline hover:text-primary/90",
                    children: runtime.t("terms.privacyPolicy")
                  }
                )
              ] })
            ] }),
            termsError && /* @__PURE__ */ jsx12("p", { className: "mt-1 text-sm text-red-500", children: termsError })
          ] }),
          /* @__PURE__ */ jsx12(
            Button,
            {
              type: "submit",
              disabled: isSubmitting,
              className: cn(
                "btn-lip-press h-12 w-full rounded-2xl text-base font-bold text-stone-900 dark:text-stone-900",
                submitTheme.button,
                submitTheme.buttonHover,
                submitTheme.buttonShadow
              ),
              children: isSubmitting ? runtime.t("signingUp") : runtime.t("createAccount")
            }
          )
        ] })
      ] })
    }
  ) });
}

// src/components/ForgotPasswordForm.tsx
import { useState as useState6 } from "react";
import { jsx as jsx13, jsxs as jsxs9 } from "react/jsx-runtime";
function ForgotPasswordForm({
  className,
  loginPath = "/login",
  ...runtimeOverrides
}) {
  const runtime = useAuthRuntime(runtimeOverrides);
  const [email, setEmail] = useState6("");
  const [isLoading, setIsLoading] = useState6(false);
  const [isSubmitted, setIsSubmitted] = useState6(false);
  const darkMode = runtime.darkMode ?? false;
  async function handleSubmit(event) {
    event.preventDefault();
    if (!email) {
      runtime.toast?.({
        title: runtime.t("toast.error"),
        description: runtime.t("forgotPasswordPage.enterEmail"),
        variant: "destructive"
      });
      return;
    }
    setIsLoading(true);
    try {
      await runtime.apiClient.forgotPassword({ email });
      setIsSubmitted(true);
      runtime.toast?.({
        title: runtime.t("forgotPasswordPage.emailSent"),
        description: runtime.t("forgotPasswordPage.emailSentDesc")
      });
    } catch {
      runtime.toast?.({
        title: runtime.t("forgotPasswordPage.sendFailed"),
        description: runtime.t("forgotPasswordPage.sendFailedDesc"),
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  }
  if (isSubmitted) {
    return /* @__PURE__ */ jsx13(
      AuthRoot,
      {
        darkMode,
        className: className ?? "flex min-h-[calc(100vh-4rem)] items-center justify-center px-4 py-12 sm:px-6 lg:px-8",
        children: /* @__PURE__ */ jsxs9("div", { className: "w-full max-w-md space-y-8", children: [
          /* @__PURE__ */ jsxs9("div", { className: "text-center", children: [
            /* @__PURE__ */ jsx13("div", { className: "mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-yellow-100", children: /* @__PURE__ */ jsx13("span", { className: "text-2xl text-yellow-600", "aria-hidden": true, children: "@" }) }),
            /* @__PURE__ */ jsx13("h2", { className: "mt-6 text-3xl font-bold tracking-tight", children: runtime.t("forgotPasswordPage.emailSent") }),
            /* @__PURE__ */ jsx13("p", { className: "mt-2 text-sm text-gray-600", children: runtime.t("forgotPasswordPage.checkEmailDesc") })
          ] }),
          /* @__PURE__ */ jsxs9("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsx13("p", { className: "text-center text-sm text-gray-600", children: runtime.t("forgotPasswordPage.notReceived") }),
            /* @__PURE__ */ jsxs9("div", { className: "flex flex-col space-y-2", children: [
              /* @__PURE__ */ jsx13(
                Button,
                {
                  onClick: () => {
                    setIsSubmitted(false);
                    setEmail("");
                  },
                  variant: "outline",
                  className: "w-full",
                  children: runtime.t("forgotPasswordPage.resend")
                }
              ),
              /* @__PURE__ */ jsx13(Button, { variant: "ghost", className: "w-full", asChild: true, children: /* @__PURE__ */ jsx13(AuthLink, { href: loginPath, LinkComponent: runtime.LinkComponent, children: runtime.t("forgotPasswordPage.backToLogin") }) })
            ] })
          ] })
        ] })
      }
    );
  }
  return /* @__PURE__ */ jsx13(
    AuthRoot,
    {
      darkMode,
      className: className ?? "flex min-h-[calc(100vh-4rem)] items-center justify-center px-4 py-12 sm:px-6 lg:px-8",
      children: /* @__PURE__ */ jsxs9("div", { className: "w-full max-w-md space-y-8", children: [
        /* @__PURE__ */ jsxs9("div", { className: "text-center", children: [
          /* @__PURE__ */ jsx13("h2", { className: "text-3xl font-bold tracking-tight", children: runtime.t("forgotPasswordPage.title") }),
          /* @__PURE__ */ jsx13("p", { className: "mt-2 text-sm text-gray-600", children: runtime.t("forgotPasswordPage.description") })
        ] }),
        /* @__PURE__ */ jsxs9("form", { className: "mt-8 space-y-6", onSubmit: handleSubmit, children: [
          /* @__PURE__ */ jsxs9("div", { children: [
            /* @__PURE__ */ jsx13("label", { htmlFor: "email", className: "block text-sm font-medium", children: runtime.t("email") }),
            /* @__PURE__ */ jsx13(
              Input,
              {
                id: "email",
                name: "email",
                type: "email",
                value: email,
                onChange: (event) => setEmail(event.target.value),
                className: "mt-1",
                placeholder: runtime.t("emailPlaceholder"),
                disabled: isLoading
              }
            )
          ] }),
          /* @__PURE__ */ jsx13(Button, { type: "submit", className: "w-full", disabled: isLoading, children: isLoading ? runtime.t("forgotPasswordPage.sending") : runtime.t("forgotPasswordPage.sendLink") }),
          /* @__PURE__ */ jsx13("div", { className: "text-center", children: /* @__PURE__ */ jsx13(
            AuthLink,
            {
              href: loginPath,
              LinkComponent: runtime.LinkComponent,
              className: "inline-flex min-h-10 items-center justify-center text-sm text-primary hover:text-primary/90",
              children: runtime.t("forgotPasswordPage.backToLogin")
            }
          ) })
        ] })
      ] })
    }
  );
}

// src/components/ResetPasswordForm.tsx
import { useEffect as useEffect6, useState as useState7 } from "react";
import { jsx as jsx14, jsxs as jsxs10 } from "react/jsx-runtime";
function ResetPasswordForm({
  className,
  token: tokenProp,
  loginPath = "/login",
  forgotPasswordPath = "/forgot-password",
  autoRedirectMs = 3e3,
  ...runtimeOverrides
}) {
  const runtime = useAuthRuntime(runtimeOverrides);
  const [token, setToken] = useState7(tokenProp ?? "");
  const [newPassword, setNewPassword] = useState7("");
  const [confirmPassword, setConfirmPassword] = useState7("");
  const [isLoading, setIsLoading] = useState7(false);
  const [isSuccess, setIsSuccess] = useState7(false);
  const [isValidToken, setIsValidToken] = useState7(true);
  const darkMode = runtime.darkMode ?? false;
  useEffect6(() => {
    const tokenToValidate = tokenProp ?? (typeof window !== "undefined" ? readTokenFromLocation() : "");
    if (!tokenToValidate) {
      setIsValidToken(false);
      return;
    }
    setToken(tokenToValidate);
    runtime.apiClient.validateResetToken({ token: tokenToValidate }).then(() => setIsValidToken(true)).catch(() => {
      setIsValidToken(false);
      runtime.toast?.({
        title: runtime.t("resetPassword.linkInvalid"),
        description: runtime.t("resetPassword.linkExpired"),
        variant: "destructive"
      });
    });
  }, [runtime.apiClient, runtime.toast, runtime.t, tokenProp]);
  async function handleSubmit(event) {
    event.preventDefault();
    if (!newPassword || !confirmPassword) {
      runtime.toast?.({
        title: runtime.t("toast.error"),
        description: runtime.t("toast.fillAllFields", void 0, "Please fill in all fields"),
        variant: "destructive"
      });
      return;
    }
    if (newPassword.length < 6) {
      runtime.toast?.({
        title: runtime.t("toast.error"),
        description: runtime.t("resetPassword.passwordMinLength"),
        variant: "destructive"
      });
      return;
    }
    if (newPassword !== confirmPassword) {
      runtime.toast?.({
        title: runtime.t("toast.error"),
        description: runtime.t("error.passwordMismatch"),
        variant: "destructive"
      });
      return;
    }
    setIsLoading(true);
    try {
      await runtime.apiClient.resetPassword({ token, newPassword });
      setIsSuccess(true);
      runtime.toast?.({
        title: runtime.t("resetPassword.resetSuccess"),
        description: runtime.t("resetPassword.resetSuccessDesc")
      });
      if (autoRedirectMs != null) {
        window.setTimeout(() => runtime.navigate?.(loginPath), autoRedirectMs);
      }
    } catch (error) {
      const invalid = isAuthError(error, "INVALID_OR_EXPIRED_TOKEN");
      runtime.toast?.({
        title: invalid ? runtime.t("resetPassword.linkInvalid") : runtime.t("resetPassword.resetFailed"),
        description: invalid ? runtime.t("resetPassword.linkExpired") : runtime.t("resetPassword.resetFailedDesc"),
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  }
  const rootClass = className ?? "flex min-h-[calc(100vh-4rem)] items-center justify-center px-4 py-12 sm:px-6 lg:px-8";
  if (!isValidToken) {
    return /* @__PURE__ */ jsx14(AuthRoot, { darkMode, className: rootClass, children: /* @__PURE__ */ jsxs10("div", { className: "w-full max-w-md space-y-8", children: [
      /* @__PURE__ */ jsxs10("div", { className: "text-center", children: [
        /* @__PURE__ */ jsx14("div", { className: "mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-red-100 text-red-600", children: "!" }),
        /* @__PURE__ */ jsx14("h2", { className: "mt-6 text-3xl font-bold tracking-tight", children: runtime.t("resetPassword.linkInvalid") }),
        /* @__PURE__ */ jsx14("p", { className: "mt-2 text-sm text-gray-600 dark:text-gray-400", children: runtime.t("resetPassword.linkExpired") })
      ] }),
      /* @__PURE__ */ jsxs10("div", { className: "space-y-4", children: [
        /* @__PURE__ */ jsx14(Button, { className: "w-full", asChild: true, children: /* @__PURE__ */ jsx14(AuthLink, { href: forgotPasswordPath, LinkComponent: runtime.LinkComponent, children: runtime.t("resetPassword.reapplyButton") }) }),
        /* @__PURE__ */ jsx14(Button, { variant: "outline", className: "w-full", asChild: true, children: /* @__PURE__ */ jsx14(AuthLink, { href: loginPath, LinkComponent: runtime.LinkComponent, children: runtime.t("resetPassword.backToLogin") }) })
      ] })
    ] }) });
  }
  if (isSuccess) {
    return /* @__PURE__ */ jsx14(AuthRoot, { darkMode, className: rootClass, children: /* @__PURE__ */ jsxs10("div", { className: "w-full max-w-md space-y-8", children: [
      /* @__PURE__ */ jsxs10("div", { className: "text-center", children: [
        /* @__PURE__ */ jsx14("div", { className: "mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-green-100 text-green-600", children: "\u2713" }),
        /* @__PURE__ */ jsx14("h2", { className: "mt-6 text-3xl font-bold tracking-tight", children: runtime.t("resetPassword.resetSuccess") }),
        /* @__PURE__ */ jsx14("p", { className: "mt-2 text-sm text-gray-600 dark:text-gray-400", children: runtime.t("resetPassword.resetSuccessDesc") })
      ] }),
      /* @__PURE__ */ jsx14(Button, { className: "w-full", asChild: true, children: /* @__PURE__ */ jsx14(AuthLink, { href: loginPath, LinkComponent: runtime.LinkComponent, children: runtime.t("loginButton") }) })
    ] }) });
  }
  return /* @__PURE__ */ jsx14(AuthRoot, { darkMode, className: rootClass, children: /* @__PURE__ */ jsxs10("div", { className: "w-full max-w-md space-y-8", children: [
    /* @__PURE__ */ jsxs10("div", { className: "text-center", children: [
      /* @__PURE__ */ jsx14("h2", { className: "text-3xl font-bold tracking-tight", children: runtime.t("resetPassword.title") }),
      /* @__PURE__ */ jsx14("p", { className: "mt-2 text-sm text-gray-600", children: runtime.t("resetPassword.subtitle") })
    ] }),
    /* @__PURE__ */ jsxs10("form", { className: "mt-8 space-y-6", onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxs10("div", { className: "space-y-4", children: [
        /* @__PURE__ */ jsxs10("div", { children: [
          /* @__PURE__ */ jsx14("label", { htmlFor: "newPassword", className: "block text-sm font-medium", children: runtime.t("resetPassword.newPassword") }),
          /* @__PURE__ */ jsx14(
            Input,
            {
              id: "newPassword",
              name: "newPassword",
              type: "password",
              value: newPassword,
              onChange: (event) => setNewPassword(event.target.value),
              className: "mt-1",
              placeholder: runtime.t("resetPassword.newPasswordPlaceholder"),
              disabled: isLoading
            }
          )
        ] }),
        /* @__PURE__ */ jsxs10("div", { children: [
          /* @__PURE__ */ jsx14("label", { htmlFor: "confirmPassword", className: "block text-sm font-medium", children: runtime.t("resetPassword.confirmNewPassword") }),
          /* @__PURE__ */ jsx14(
            Input,
            {
              id: "confirmPassword",
              name: "confirmPassword",
              type: "password",
              value: confirmPassword,
              onChange: (event) => setConfirmPassword(event.target.value),
              className: "mt-1",
              placeholder: runtime.t("resetPassword.confirmNewPasswordPlaceholder"),
              disabled: isLoading
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsx14(Button, { type: "submit", className: "w-full", disabled: isLoading, children: isLoading ? runtime.t("resetPassword.resetting") : runtime.t("resetPassword.resetButton") }),
      /* @__PURE__ */ jsx14("div", { className: "text-center", children: /* @__PURE__ */ jsx14(
        AuthLink,
        {
          href: loginPath,
          LinkComponent: runtime.LinkComponent,
          className: "inline-flex min-h-10 items-center justify-center text-sm text-primary hover:text-primary/90",
          children: runtime.t("resetPassword.backToLogin")
        }
      ) })
    ] })
  ] }) });
}

// src/components/EmailVerificationNotice.tsx
import { useLayoutEffect, useMemo as useMemo4, useRef as useRef6, useState as useState8 } from "react";
import { CheckCircle2, Loader2, Mail } from "lucide-react";

// src/components/ui/card.tsx
import * as React5 from "react";
import { jsx as jsx15 } from "react/jsx-runtime";
var Card = React5.forwardRef(
  ({ className, ...props }, ref) => /* @__PURE__ */ jsx15(
    "div",
    {
      ref,
      className: cn(
        "rounded-lg border bg-card text-card-foreground shadow-card transition-all duration-200 hover:shadow-card-hover",
        className
      ),
      ...props
    }
  )
);
Card.displayName = "Card";
var CardHeader = React5.forwardRef(
  ({ className, ...props }, ref) => /* @__PURE__ */ jsx15("div", { ref, className: cn("flex flex-col space-y-1.5 p-6", className), ...props })
);
CardHeader.displayName = "CardHeader";
var CardTitle = React5.forwardRef(
  ({ className, ...props }, ref) => /* @__PURE__ */ jsx15(
    "h3",
    {
      ref,
      className: cn("text-2xl font-semibold leading-none tracking-tight dark:text-white", className),
      ...props
    }
  )
);
CardTitle.displayName = "CardTitle";
var CardDescription = React5.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx15("p", { ref, className: cn("text-sm text-muted-foreground", className), ...props }));
CardDescription.displayName = "CardDescription";
var CardContent = React5.forwardRef(
  ({ className, ...props }, ref) => /* @__PURE__ */ jsx15("div", { ref, className: cn("p-6 pt-0", className), ...props })
);
CardContent.displayName = "CardContent";

// src/components/EmailVerificationNotice.tsx
import { jsx as jsx16, jsxs as jsxs11 } from "react/jsx-runtime";
function DestinationMessage({ template, email }) {
  const parts = template.split("{email}");
  return /* @__PURE__ */ jsxs11("p", { children: [
    parts[0],
    /* @__PURE__ */ jsx16("strong", { children: email }),
    parts.slice(1).join("{email}")
  ] });
}
function EmailVerificationNotice({
  className,
  token: tokenProp,
  sentFromSignup,
  initialIdentifier = "",
  verificationDestination = "",
  loginPath = "/login",
  clearTokenFromUrl = true,
  onVerified,
  onRequestSent,
  ...runtimeOverrides
}) {
  const runtime = useAuthRuntime(runtimeOverrides);
  const token = useMemo4(
    () => tokenProp ?? (typeof window !== "undefined" ? readTokenFromLocation() : ""),
    [tokenProp]
  );
  const [status, setStatus] = useState8(token ? "ready" : "idle");
  const verificationStartedRef = useRef6(false);
  const [identifier, setIdentifier] = useState8(initialIdentifier);
  const [requesting, setRequesting] = useState8(false);
  const requestInFlightRef = useRef6(null);
  const [requestSent, setRequestSent] = useState8(Boolean(sentFromSignup));
  const [requestReceived, setRequestReceived] = useState8(false);
  const [requestError, setRequestError] = useState8("");
  const darkMode = runtime.darkMode ?? false;
  useLayoutEffect(() => {
    if (!token || !clearTokenFromUrl || typeof window === "undefined") return;
    window.history.replaceState(null, "", window.location.pathname);
  }, [clearTokenFromUrl, token]);
  async function confirmEmail() {
    if (!token || status === "verifying" || verificationStartedRef.current) return;
    verificationStartedRef.current = true;
    setStatus("verifying");
    try {
      await runtime.apiClient.verifyEmail({ token, confirmation: true });
      setStatus("success");
      await onVerified?.();
    } catch (error) {
      verificationStartedRef.current = false;
      if (isAuthError(error) && error.status && error.status < 500) {
        setStatus("error");
      } else {
        setStatus("retryableError");
      }
    }
  }
  async function requestVerification(event) {
    event.preventDefault();
    if (requestInFlightRef.current) {
      await requestInFlightRef.current;
      return;
    }
    const normalizedIdentifier = identifier.trim();
    if (!normalizedIdentifier) {
      setRequestError(runtime.t("emailVerification.identifierRequired"));
      return;
    }
    const request = (async () => {
      setRequestError("");
      setRequestReceived(false);
      setRequesting(true);
      try {
        await runtime.apiClient.requestEmailVerification({ identifier: normalizedIdentifier });
        setRequestSent(true);
        setRequestReceived(true);
        await onRequestSent?.(normalizedIdentifier);
      } catch {
        setRequestError(runtime.t("emailVerification.requestFailed"));
      } finally {
        setRequesting(false);
      }
    })();
    requestInFlightRef.current = request;
    try {
      await request;
    } finally {
      requestInFlightRef.current = null;
    }
  }
  return /* @__PURE__ */ jsx16(
    AuthRoot,
    {
      darkMode,
      className: className ?? "flex min-h-[calc(100vh-4rem)] items-center justify-center px-4 py-12",
      children: /* @__PURE__ */ jsxs11(Card, { className: "w-full max-w-md bg-white dark:bg-muted", children: [
        /* @__PURE__ */ jsxs11(CardHeader, { children: [
          /* @__PURE__ */ jsx16(CardTitle, { children: runtime.t("emailVerification.title") }),
          /* @__PURE__ */ jsx16(CardDescription, { children: runtime.t("emailVerification.description") })
        ] }),
        /* @__PURE__ */ jsxs11(CardContent, { className: "space-y-4", children: [
          status === "ready" && /* @__PURE__ */ jsxs11("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsx16("p", { className: "text-sm text-muted-foreground", children: runtime.t("emailVerification.confirmPrompt") }),
            /* @__PURE__ */ jsx16(Button, { type: "button", className: "w-full", onClick: confirmEmail, children: runtime.t("emailVerification.confirm") })
          ] }),
          status === "verifying" && /* @__PURE__ */ jsxs11("div", { className: "flex items-center gap-2 text-sm text-muted-foreground", role: "status", children: [
            /* @__PURE__ */ jsx16(Loader2, { className: "h-4 w-4 animate-spin" }),
            runtime.t("emailVerification.verifying")
          ] }),
          status === "success" && /* @__PURE__ */ jsxs11("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsxs11("div", { className: "flex items-start gap-3 text-sm", role: "status", children: [
              /* @__PURE__ */ jsx16(CheckCircle2, { className: "mt-0.5 h-5 w-5 text-green-600" }),
              runtime.t("emailVerification.success")
            ] }),
            /* @__PURE__ */ jsx16(Button, { asChild: true, children: /* @__PURE__ */ jsx16(AuthLink, { href: loginPath, LinkComponent: runtime.LinkComponent, children: runtime.t("loginButton") }) })
          ] }),
          status === "error" && /* @__PURE__ */ jsxs11("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsx16("p", { className: "text-sm text-destructive", role: "alert", children: runtime.t("emailVerification.invalidOrExpired") }),
            /* @__PURE__ */ jsx16(Button, { type: "button", variant: "outline", onClick: () => setStatus("idle"), children: runtime.t("emailVerification.requestAnother") })
          ] }),
          status === "retryableError" && /* @__PURE__ */ jsxs11("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsx16("p", { className: "text-sm text-destructive", role: "alert", children: runtime.t("emailVerification.retryPrompt") }),
            /* @__PURE__ */ jsx16(Button, { type: "button", variant: "outline", onClick: confirmEmail, children: runtime.t("emailVerification.tryAgain") }),
            /* @__PURE__ */ jsx16(Button, { type: "button", variant: "ghost", onClick: () => setStatus("idle"), children: runtime.t("emailVerification.requestAnother") })
          ] }),
          status === "idle" && /* @__PURE__ */ jsxs11("form", { className: "space-y-4", onSubmit: requestVerification, children: [
            verificationDestination && /* @__PURE__ */ jsxs11("div", { className: "flex items-start gap-3 text-sm", role: "status", children: [
              /* @__PURE__ */ jsx16(Mail, { className: "mt-0.5 h-5 w-5 shrink-0 text-primary" }),
              /* @__PURE__ */ jsx16(
                DestinationMessage,
                {
                  template: runtime.t("emailVerification.destination"),
                  email: verificationDestination
                }
              )
            ] }),
            requestSent && !requestReceived && /* @__PURE__ */ jsxs11("div", { className: "flex items-start gap-3 text-sm text-muted-foreground", role: "status", children: [
              /* @__PURE__ */ jsx16(Mail, { className: "mt-0.5 h-5 w-5 text-primary" }),
              runtime.t("emailVerification.sent")
            ] }),
            requestReceived && /* @__PURE__ */ jsxs11("div", { className: "flex items-start gap-3 text-sm text-green-700", role: "status", children: [
              /* @__PURE__ */ jsx16(CheckCircle2, { className: "mt-0.5 h-5 w-5 text-green-600" }),
              runtime.t("emailVerification.requestReceived")
            ] }),
            /* @__PURE__ */ jsxs11("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx16("label", { htmlFor: "verification-identifier", className: "text-sm font-medium", children: runtime.t("emailVerification.identifierLabel") }),
              /* @__PURE__ */ jsx16(
                Input,
                {
                  id: "verification-identifier",
                  value: identifier,
                  onChange: (event) => setIdentifier(event.target.value),
                  autoComplete: "username",
                  "aria-describedby": "verification-identifier-help"
                }
              ),
              /* @__PURE__ */ jsx16("p", { id: "verification-identifier-help", className: "text-sm text-muted-foreground", children: runtime.t("emailVerification.identifierHelp") })
            ] }),
            requestError && /* @__PURE__ */ jsx16("p", { className: "text-sm text-destructive", role: "alert", children: requestError }),
            /* @__PURE__ */ jsxs11(Button, { type: "submit", disabled: requesting, className: "w-full", children: [
              requesting && /* @__PURE__ */ jsx16(Loader2, { className: "mr-2 h-4 w-4 animate-spin" }),
              runtime.t("emailVerification.resend")
            ] }),
            /* @__PURE__ */ jsx16(Button, { asChild: true, variant: "ghost", className: "w-full", children: /* @__PURE__ */ jsx16(AuthLink, { href: loginPath, LinkComponent: runtime.LinkComponent, children: runtime.t("loginButton") }) })
          ] })
        ] })
      ] })
    }
  );
}
export {
  AuthError,
  AuthInputError,
  AuthLink,
  AuthRoot,
  AuthRuntimeProvider,
  BACKEND_AUTH_ERROR_CODE_MAP,
  DEFAULT_LOGIN_MASCOT_ID,
  EmailVerificationNotice,
  ForgotPasswordForm,
  LOGIN_MASCOTS,
  LOGIN_MASCOT_COLOR_PICKER_IDS,
  LOGIN_MASCOT_PICKER_OPTION_IDS,
  LOGIN_MASCOT_STORAGE_KEY,
  LOGIN_MASCOT_UNKNOWN_ID,
  MASCOT_ACCENTS,
  ResetPasswordForm,
  SURF_PLANES,
  SignInForm,
  SignUpForm,
  UNKNOWN_MASCOT_AVATAR_IMAGE_VAR,
  UNKNOWN_MASCOT_THEME,
  authMessages,
  calculatePasswordStrength,
  createAuthApiClient,
  forgotPasswordSchema,
  getLoginMascot,
  isAuthError,
  isAuthInputError,
  isLoginMascotId,
  isLoginMascotPickerOptionId,
  mapBackendAuthError,
  readStoredLoginMascotId,
  requestEmailVerificationSchema,
  resetPasswordSchema,
  resetTokenSchema,
  resolveAuthMessage,
  signInSchema,
  signUpSchema,
  storeLoginMascotId,
  throwAuthError,
  useAuthRuntime,
  usernameSchema,
  validateUsername,
  validationErrorToAuthValidationError,
  verifyEmailSchema
};
//# sourceMappingURL=index.mjs.map