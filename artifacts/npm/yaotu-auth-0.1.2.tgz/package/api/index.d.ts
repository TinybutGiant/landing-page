type AuthUserRole = 'traveler' | 'guide' | string;
type AuthUserGuideStatus = {
    isGuide: boolean;
    hasApprovedApplication: boolean;
    applicationStatus?: 'drafted' | 'pending' | 'needs_more_info' | 'approved' | 'rejected';
    shouldShowBecomeGuideButton: boolean;
    shouldShowViewApplicationButton: boolean;
    shouldShowRoleSwitch: boolean;
};
type AuthenticatedUser = {
    id: number;
    username: string;
    email: string;
    fullName?: string | null;
    isGuide?: boolean;
    identityVerified?: boolean;
    emailVerified?: boolean;
    emailVerifiedAt?: string | null;
    role: AuthUserRole;
    profilePicture?: string | null;
    readReceiptsEnabled?: boolean;
    joinedDate?: string | null;
    guideStatus?: AuthUserGuideStatus;
};
type SignInRequest = {
    username: string;
    password: string;
};
type SignInSuccess = AuthenticatedUser & {
    token: string;
};
type SignUpRequest = {
    username: string;
    email: string;
    password: string;
    fullName: string;
    emailUpdates?: boolean;
    signupIntentToken?: string;
};
type SignUpVerificationRequiredResult = {
    success: true;
    verificationRequired: true;
    message: string;
};
type UsernameAvailabilityResult = {
    available: boolean;
};
type ForgotPasswordRequest = {
    email: string;
};
type ForgotPasswordResult = {
    message: string;
};
type ValidateResetTokenRequest = {
    token: string;
};
type ValidateResetTokenResult = {
    message: string;
    valid: true;
};
type ResetPasswordRequest = {
    token: string;
    newPassword: string;
};
type ResetPasswordResult = {
    message: string;
};
type RequestEmailVerificationRequest = {
    identifier: string;
};
type RequestEmailVerificationResult = {
    success: true;
    message: string;
};
type VerifyEmailRequest = {
    token: string;
    confirmation: true;
};
type VerifyEmailResult = {
    success: true;
};
type AuthContinuationFlow = 'guide_application';
type AuthResultContext = {
    redirectTo?: string | null;
    flow?: AuthContinuationFlow | null;
    submittedEmail?: string;
};

type AuthFetcher = (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;
type AuthApiClientOptions = {
    apiBaseUrl?: string;
    fetcher?: AuthFetcher;
};
type AuthApiClient = ReturnType<typeof createAuthApiClient>;
declare function createAuthApiClient(options?: AuthApiClientOptions): {
    signIn(input: SignInRequest): Promise<SignInSuccess>;
    signUp(input: SignUpRequest): Promise<SignUpVerificationRequiredResult>;
    checkUsernameAvailability(username: string): Promise<UsernameAvailabilityResult>;
    forgotPassword(input: ForgotPasswordRequest): Promise<ForgotPasswordResult>;
    validateResetToken(input: ValidateResetTokenRequest): Promise<ValidateResetTokenResult>;
    resetPassword(input: ResetPasswordRequest): Promise<ResetPasswordResult>;
    requestEmailVerification(input: RequestEmailVerificationRequest): Promise<RequestEmailVerificationResult>;
    verifyEmail(input: VerifyEmailRequest): Promise<VerifyEmailResult>;
};

type AuthValidationError = {
    code: 'VALIDATION_ERROR';
    fields: Record<string, string>;
};
type AuthCanonicalErrorCode = 'VALIDATION_ERROR' | 'EMAIL_VERIFICATION_REQUIRED' | 'INVALID_CREDENTIALS' | 'USERNAME_TAKEN' | 'PUBLIC_SIGNUP_CLOSED' | 'SIGNUP_INTENT_INVALID' | 'INVALID_OR_EXPIRED_TOKEN' | 'REQUEST_FAILED' | 'UNEXPECTED_RESPONSE';
type AuthCanonicalError = AuthValidationError | {
    code: Exclude<AuthCanonicalErrorCode, 'VALIDATION_ERROR'>;
    message: string;
    status?: number;
    backendCode?: string;
    verificationRequired?: boolean;
    verificationEmailMasked?: string | null;
    details?: unknown;
};
declare class AuthError extends Error {
    readonly code: Exclude<AuthCanonicalErrorCode, 'VALIDATION_ERROR'>;
    readonly status?: number;
    readonly backendCode?: string;
    readonly verificationRequired?: boolean;
    readonly verificationEmailMasked?: string | null;
    readonly details?: unknown;
    constructor(error: Exclude<AuthCanonicalError, AuthValidationError>);
}
declare class AuthInputError extends Error {
    readonly code: "VALIDATION_ERROR";
    readonly fields: Record<string, string>;
    constructor(error: AuthValidationError);
}
declare const BACKEND_AUTH_ERROR_CODE_MAP: {
    readonly email_verification_required: "EMAIL_VERIFICATION_REQUIRED";
    readonly PUBLIC_SIGNUP_CLOSED: "PUBLIC_SIGNUP_CLOSED";
    readonly SIGNUP_INTENT_INVALID: "SIGNUP_INTENT_INVALID";
};
declare function validationErrorToAuthValidationError(error: unknown): AuthValidationError;
declare function mapBackendAuthError(status: number, body: unknown): AuthCanonicalError;
declare function throwAuthError(error: AuthCanonicalError): never;
declare function isAuthError(error: unknown, code?: AuthCanonicalErrorCode): error is AuthError;
declare function isAuthInputError(error: unknown): error is AuthInputError;

export { type AuthApiClient, type AuthApiClientOptions, type AuthCanonicalError, type AuthCanonicalErrorCode, type AuthContinuationFlow, AuthError, type AuthFetcher, AuthInputError, type AuthResultContext, type AuthUserGuideStatus, type AuthUserRole, type AuthValidationError, type AuthenticatedUser, BACKEND_AUTH_ERROR_CODE_MAP, type ForgotPasswordRequest, type ForgotPasswordResult, type RequestEmailVerificationRequest, type RequestEmailVerificationResult, type ResetPasswordRequest, type ResetPasswordResult, type SignInRequest, type SignInSuccess, type SignUpRequest, type SignUpVerificationRequiredResult, type UsernameAvailabilityResult, type ValidateResetTokenRequest, type ValidateResetTokenResult, type VerifyEmailRequest, type VerifyEmailResult, createAuthApiClient, isAuthError, isAuthInputError, mapBackendAuthError, throwAuthError, validationErrorToAuthValidationError };
