import * as React from 'react';
import React__default from 'react';
import * as zod from 'zod';
import { z } from 'zod';
import * as react_jsx_runtime from 'react/jsx-runtime';
import * as react_hook_form from 'react-hook-form';
import { Control } from 'react-hook-form';

type GuideApplicationContinuationIntent = "start_application" | "continue_local_draft" | "continue_server_draft" | "continue_required_changes" | "view_status" | "guide_home";
interface GuideApplicationContinuationInput {
    authenticated: boolean;
    hasGuideProfile?: boolean;
    hasApplication?: boolean;
    applicationStatus?: string | null;
    hasLocalDraft?: boolean;
}
/**
 * Resolves what the user is continuing from canonical Guide lifecycle state.
 *
 * Server application state always wins over browser-local draft metadata. An
 * unknown status for a known application fails closed to the status experience
 * so the client never reopens a potentially locked application as a draft.
 */
declare const resolveGuideApplicationContinuation: ({ authenticated, hasGuideProfile, hasApplication, applicationStatus, hasLocalDraft, }: GuideApplicationContinuationInput) => GuideApplicationContinuationIntent;
declare const isEditableGuideContinuation: (intent: GuideApplicationContinuationIntent) => boolean;

/**
 * Package-owned Zod 3 schema for @replit/guide-form internals.
 *
 * @deprecated Do not use this as a cross-package Zod interoperability API.
 * Prefer the exported GuideForm types and helpers when integrating with host
 * applications. Consumers should not rely on this schema sharing the host
 * application's Zod instance or major version.
 */
declare const formSchema: z.ZodEffects<z.ZodEffects<z.ZodObject<{
    id: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
    userId: z.ZodOptional<z.ZodNumber>;
    applicationStatus: z.ZodOptional<z.ZodEnum<["drafted", "pending", "under_review", "approved", "rejected", "needs_more_info"]>>;
    name: z.ZodString;
    age: z.ZodNumber;
    sex: z.ZodEffects<z.ZodEnum<["Male", "Female", "prefer_not_to_say"]>, "Male" | "Female" | "prefer_not_to_say", unknown>;
    mbti: z.ZodOptional<z.ZodEnum<[string, ...string[]]>>;
    socialProfile: z.ZodOptional<z.ZodString>;
    assessmentQ1: z.ZodDefault<z.ZodArray<z.ZodString, "many">>;
    assessmentQ1Slider: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    assessmentQ2: z.ZodDefault<z.ZodString>;
    assessmentQ3: z.ZodDefault<z.ZodString>;
    assessmentQ3Slider: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    assessmentQ4: z.ZodDefault<z.ZodArray<z.ZodString, "many">>;
    assessmentQ4Slider: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    serviceAreaDestinationIds: z.ZodDefault<z.ZodArray<z.ZodNumber, "many">>;
    customServiceAreaProposals: z.ZodDefault<z.ZodArray<z.ZodString, "many">>;
    serviceAreas: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodOptional<z.ZodNumber>;
        destinationId: z.ZodOptional<z.ZodNumber>;
        slug: z.ZodOptional<z.ZodString>;
        countryCode: z.ZodOptional<z.ZodString>;
        nameEn: z.ZodOptional<z.ZodString>;
        nameJa: z.ZodOptional<z.ZodString>;
        nameZhCn: z.ZodOptional<z.ZodString>;
        timezone: z.ZodOptional<z.ZodString>;
        prefectureName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        placeType: z.ZodOptional<z.ZodString>;
    }, "passthrough", z.ZodTypeAny, z.objectOutputType<{
        id: z.ZodOptional<z.ZodNumber>;
        destinationId: z.ZodOptional<z.ZodNumber>;
        slug: z.ZodOptional<z.ZodString>;
        countryCode: z.ZodOptional<z.ZodString>;
        nameEn: z.ZodOptional<z.ZodString>;
        nameJa: z.ZodOptional<z.ZodString>;
        nameZhCn: z.ZodOptional<z.ZodString>;
        timezone: z.ZodOptional<z.ZodString>;
        prefectureName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        placeType: z.ZodOptional<z.ZodString>;
    }, z.ZodTypeAny, "passthrough">, z.objectInputType<{
        id: z.ZodOptional<z.ZodNumber>;
        destinationId: z.ZodOptional<z.ZodNumber>;
        slug: z.ZodOptional<z.ZodString>;
        countryCode: z.ZodOptional<z.ZodString>;
        nameEn: z.ZodOptional<z.ZodString>;
        nameJa: z.ZodOptional<z.ZodString>;
        nameZhCn: z.ZodOptional<z.ZodString>;
        timezone: z.ZodOptional<z.ZodString>;
        prefectureName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        placeType: z.ZodOptional<z.ZodString>;
    }, z.ZodTypeAny, "passthrough">>, "many">>;
    serviceAreaProposals: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        rawName: z.ZodOptional<z.ZodString>;
        normalizedName: z.ZodOptional<z.ZodString>;
        status: z.ZodOptional<z.ZodString>;
        resolvedDestinationId: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    }, "passthrough", z.ZodTypeAny, z.objectOutputType<{
        id: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        rawName: z.ZodOptional<z.ZodString>;
        normalizedName: z.ZodOptional<z.ZodString>;
        status: z.ZodOptional<z.ZodString>;
        resolvedDestinationId: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    }, z.ZodTypeAny, "passthrough">, z.objectInputType<{
        id: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        rawName: z.ZodOptional<z.ZodString>;
        normalizedName: z.ZodOptional<z.ZodString>;
        status: z.ZodOptional<z.ZodString>;
        resolvedDestinationId: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    }, z.ZodTypeAny, "passthrough">>, "many">>;
    residenceInfo: z.ZodOptional<z.ZodString>;
    residenceZipcode: z.ZodUnion<[z.ZodOptional<z.ZodString>, z.ZodLiteral<"">]>;
    residenceStartDate: z.ZodOptional<z.ZodString>;
    occupation: z.ZodOptional<z.ZodString>;
    bio: z.ZodOptional<z.ZodString>;
    qualifications: z.ZodOptional<z.ZodObject<{
        certifications: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
            description: z.ZodOptional<z.ZodString>;
            proof: z.ZodOptional<z.ZodString>;
            visible: z.ZodOptional<z.ZodDefault<z.ZodBoolean>>;
            uploaded: z.ZodOptional<z.ZodBoolean>;
            publicUrl: z.ZodOptional<z.ZodString>;
            data: z.ZodOptional<z.ZodString>;
            name: z.ZodOptional<z.ZodString>;
            type: z.ZodOptional<z.ZodString>;
            size: z.ZodOptional<z.ZodNumber>;
            fileId: z.ZodOptional<z.ZodString>;
            stagedFileId: z.ZodOptional<z.ZodString>;
        }, "passthrough", z.ZodTypeAny, z.objectOutputType<{
            description: z.ZodOptional<z.ZodString>;
            proof: z.ZodOptional<z.ZodString>;
            visible: z.ZodOptional<z.ZodDefault<z.ZodBoolean>>;
            uploaded: z.ZodOptional<z.ZodBoolean>;
            publicUrl: z.ZodOptional<z.ZodString>;
            data: z.ZodOptional<z.ZodString>;
            name: z.ZodOptional<z.ZodString>;
            type: z.ZodOptional<z.ZodString>;
            size: z.ZodOptional<z.ZodNumber>;
            fileId: z.ZodOptional<z.ZodString>;
            stagedFileId: z.ZodOptional<z.ZodString>;
        }, z.ZodTypeAny, "passthrough">, z.objectInputType<{
            description: z.ZodOptional<z.ZodString>;
            proof: z.ZodOptional<z.ZodString>;
            visible: z.ZodOptional<z.ZodDefault<z.ZodBoolean>>;
            uploaded: z.ZodOptional<z.ZodBoolean>;
            publicUrl: z.ZodOptional<z.ZodString>;
            data: z.ZodOptional<z.ZodString>;
            name: z.ZodOptional<z.ZodString>;
            type: z.ZodOptional<z.ZodString>;
            size: z.ZodOptional<z.ZodNumber>;
            fileId: z.ZodOptional<z.ZodString>;
            stagedFileId: z.ZodOptional<z.ZodString>;
        }, z.ZodTypeAny, "passthrough">>>>;
    }, "strip", z.ZodTypeAny, {
        certifications?: Record<string, z.objectOutputType<{
            description: z.ZodOptional<z.ZodString>;
            proof: z.ZodOptional<z.ZodString>;
            visible: z.ZodOptional<z.ZodDefault<z.ZodBoolean>>;
            uploaded: z.ZodOptional<z.ZodBoolean>;
            publicUrl: z.ZodOptional<z.ZodString>;
            data: z.ZodOptional<z.ZodString>;
            name: z.ZodOptional<z.ZodString>;
            type: z.ZodOptional<z.ZodString>;
            size: z.ZodOptional<z.ZodNumber>;
            fileId: z.ZodOptional<z.ZodString>;
            stagedFileId: z.ZodOptional<z.ZodString>;
        }, z.ZodTypeAny, "passthrough">> | undefined;
    }, {
        certifications?: Record<string, z.objectInputType<{
            description: z.ZodOptional<z.ZodString>;
            proof: z.ZodOptional<z.ZodString>;
            visible: z.ZodOptional<z.ZodDefault<z.ZodBoolean>>;
            uploaded: z.ZodOptional<z.ZodBoolean>;
            publicUrl: z.ZodOptional<z.ZodString>;
            data: z.ZodOptional<z.ZodString>;
            name: z.ZodOptional<z.ZodString>;
            type: z.ZodOptional<z.ZodString>;
            size: z.ZodOptional<z.ZodNumber>;
            fileId: z.ZodOptional<z.ZodString>;
            stagedFileId: z.ZodOptional<z.ZodString>;
        }, z.ZodTypeAny, "passthrough">> | undefined;
    }>>;
    languages: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
    experienceDuration: z.ZodOptional<z.ZodString>;
    experienceSession: z.ZodOptional<z.ZodString>;
    personalizedQ5: z.ZodDefault<z.ZodArray<z.ZodString, "many">>;
    personalizedQ5Slider: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    personalizedQ6: z.ZodDefault<z.ZodArray<z.ZodString, "many">>;
    personalizedQ6Slider: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    personalizedQ7: z.ZodDefault<z.ZodString>;
    personalizedQ7Slider: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    personalizedQ8Strengths: z.ZodDefault<z.ZodArray<z.ZodString, "many">>;
    personalizedQ8Slider: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    personalizedQ8Example: z.ZodDefault<z.ZodString>;
    personalizedQ9: z.ZodDefault<z.ZodString>;
    serviceSelections: z.ZodDefault<z.ZodArray<z.ZodNumber, "many">>;
    targetGroup: z.ZodDefault<z.ZodArray<z.ZodEnum<["individual", "couple", "family", "group", "child", "elderly", "business"]>, "many">>;
    minPeople: z.ZodOptional<z.ZodNumber>;
    maxPeople: z.ZodOptional<z.ZodNumber>;
    minDuration: z.ZodOptional<z.ZodNumber>;
    maxDuration: z.ZodOptional<z.ZodNumber>;
    basicPricePerHour: z.ZodOptional<z.ZodNumber>;
    additionalPricePerPerson: z.ZodOptional<z.ZodNumber>;
    basicPricePerHourCents: z.ZodOptional<z.ZodNumber>;
    additionalPricePerPersonCents: z.ZodOptional<z.ZodNumber>;
    currency: z.ZodDefault<z.ZodLiteral<"USD">>;
    draftMetadata: z.ZodOptional<z.ZodObject<{
        clientDraftId: z.ZodOptional<z.ZodString>;
        handedOffAt: z.ZodOptional<z.ZodString>;
        anonymousDraftVersion: z.ZodOptional<z.ZodNumber>;
    }, "strip", z.ZodTypeAny, {
        clientDraftId?: string | undefined;
        handedOffAt?: string | undefined;
        anonymousDraftVersion?: number | undefined;
    }, {
        clientDraftId?: string | undefined;
        handedOffAt?: string | undefined;
        anonymousDraftVersion?: number | undefined;
    }>>;
}, "strip", z.ZodTypeAny, {
    name: string;
    age: number;
    sex: "Male" | "Female" | "prefer_not_to_say";
    assessmentQ1: string[];
    assessmentQ2: string;
    assessmentQ3: string;
    assessmentQ4: string[];
    serviceAreaDestinationIds: number[];
    customServiceAreaProposals: string[];
    personalizedQ5: string[];
    personalizedQ6: string[];
    personalizedQ7: string;
    personalizedQ8Strengths: string[];
    personalizedQ8Example: string;
    personalizedQ9: string;
    serviceSelections: number[];
    targetGroup: ("individual" | "couple" | "family" | "group" | "child" | "elderly" | "business")[];
    currency: "USD";
    applicationStatus?: "drafted" | "needs_more_info" | "pending" | "under_review" | "approved" | "rejected" | undefined;
    id?: string | number | undefined;
    userId?: number | undefined;
    mbti?: string | undefined;
    socialProfile?: string | undefined;
    assessmentQ1Slider?: number | null | undefined;
    assessmentQ3Slider?: number | null | undefined;
    assessmentQ4Slider?: number | null | undefined;
    serviceAreas?: z.objectOutputType<{
        id: z.ZodOptional<z.ZodNumber>;
        destinationId: z.ZodOptional<z.ZodNumber>;
        slug: z.ZodOptional<z.ZodString>;
        countryCode: z.ZodOptional<z.ZodString>;
        nameEn: z.ZodOptional<z.ZodString>;
        nameJa: z.ZodOptional<z.ZodString>;
        nameZhCn: z.ZodOptional<z.ZodString>;
        timezone: z.ZodOptional<z.ZodString>;
        prefectureName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        placeType: z.ZodOptional<z.ZodString>;
    }, z.ZodTypeAny, "passthrough">[] | undefined;
    serviceAreaProposals?: z.objectOutputType<{
        id: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        rawName: z.ZodOptional<z.ZodString>;
        normalizedName: z.ZodOptional<z.ZodString>;
        status: z.ZodOptional<z.ZodString>;
        resolvedDestinationId: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    }, z.ZodTypeAny, "passthrough">[] | undefined;
    residenceInfo?: string | undefined;
    residenceZipcode?: string | undefined;
    residenceStartDate?: string | undefined;
    occupation?: string | undefined;
    bio?: string | undefined;
    qualifications?: {
        certifications?: Record<string, z.objectOutputType<{
            description: z.ZodOptional<z.ZodString>;
            proof: z.ZodOptional<z.ZodString>;
            visible: z.ZodOptional<z.ZodDefault<z.ZodBoolean>>;
            uploaded: z.ZodOptional<z.ZodBoolean>;
            publicUrl: z.ZodOptional<z.ZodString>;
            data: z.ZodOptional<z.ZodString>;
            name: z.ZodOptional<z.ZodString>;
            type: z.ZodOptional<z.ZodString>;
            size: z.ZodOptional<z.ZodNumber>;
            fileId: z.ZodOptional<z.ZodString>;
            stagedFileId: z.ZodOptional<z.ZodString>;
        }, z.ZodTypeAny, "passthrough">> | undefined;
    } | undefined;
    languages?: string[] | undefined;
    experienceDuration?: string | undefined;
    experienceSession?: string | undefined;
    personalizedQ5Slider?: number | null | undefined;
    personalizedQ6Slider?: number | null | undefined;
    personalizedQ7Slider?: number | null | undefined;
    personalizedQ8Slider?: number | null | undefined;
    minPeople?: number | undefined;
    maxPeople?: number | undefined;
    minDuration?: number | undefined;
    maxDuration?: number | undefined;
    basicPricePerHour?: number | undefined;
    additionalPricePerPerson?: number | undefined;
    basicPricePerHourCents?: number | undefined;
    additionalPricePerPersonCents?: number | undefined;
    draftMetadata?: {
        clientDraftId?: string | undefined;
        handedOffAt?: string | undefined;
        anonymousDraftVersion?: number | undefined;
    } | undefined;
}, {
    name: string;
    age: number;
    applicationStatus?: "drafted" | "needs_more_info" | "pending" | "under_review" | "approved" | "rejected" | undefined;
    id?: string | number | undefined;
    userId?: number | undefined;
    sex?: unknown;
    mbti?: string | undefined;
    socialProfile?: string | undefined;
    assessmentQ1?: string[] | undefined;
    assessmentQ1Slider?: number | null | undefined;
    assessmentQ2?: string | undefined;
    assessmentQ3?: string | undefined;
    assessmentQ3Slider?: number | null | undefined;
    assessmentQ4?: string[] | undefined;
    assessmentQ4Slider?: number | null | undefined;
    serviceAreaDestinationIds?: number[] | undefined;
    customServiceAreaProposals?: string[] | undefined;
    serviceAreas?: z.objectInputType<{
        id: z.ZodOptional<z.ZodNumber>;
        destinationId: z.ZodOptional<z.ZodNumber>;
        slug: z.ZodOptional<z.ZodString>;
        countryCode: z.ZodOptional<z.ZodString>;
        nameEn: z.ZodOptional<z.ZodString>;
        nameJa: z.ZodOptional<z.ZodString>;
        nameZhCn: z.ZodOptional<z.ZodString>;
        timezone: z.ZodOptional<z.ZodString>;
        prefectureName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        placeType: z.ZodOptional<z.ZodString>;
    }, z.ZodTypeAny, "passthrough">[] | undefined;
    serviceAreaProposals?: z.objectInputType<{
        id: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        rawName: z.ZodOptional<z.ZodString>;
        normalizedName: z.ZodOptional<z.ZodString>;
        status: z.ZodOptional<z.ZodString>;
        resolvedDestinationId: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    }, z.ZodTypeAny, "passthrough">[] | undefined;
    residenceInfo?: string | undefined;
    residenceZipcode?: string | undefined;
    residenceStartDate?: string | undefined;
    occupation?: string | undefined;
    bio?: string | undefined;
    qualifications?: {
        certifications?: Record<string, z.objectInputType<{
            description: z.ZodOptional<z.ZodString>;
            proof: z.ZodOptional<z.ZodString>;
            visible: z.ZodOptional<z.ZodDefault<z.ZodBoolean>>;
            uploaded: z.ZodOptional<z.ZodBoolean>;
            publicUrl: z.ZodOptional<z.ZodString>;
            data: z.ZodOptional<z.ZodString>;
            name: z.ZodOptional<z.ZodString>;
            type: z.ZodOptional<z.ZodString>;
            size: z.ZodOptional<z.ZodNumber>;
            fileId: z.ZodOptional<z.ZodString>;
            stagedFileId: z.ZodOptional<z.ZodString>;
        }, z.ZodTypeAny, "passthrough">> | undefined;
    } | undefined;
    languages?: string[] | undefined;
    experienceDuration?: string | undefined;
    experienceSession?: string | undefined;
    personalizedQ5?: string[] | undefined;
    personalizedQ5Slider?: number | null | undefined;
    personalizedQ6?: string[] | undefined;
    personalizedQ6Slider?: number | null | undefined;
    personalizedQ7?: string | undefined;
    personalizedQ7Slider?: number | null | undefined;
    personalizedQ8Strengths?: string[] | undefined;
    personalizedQ8Slider?: number | null | undefined;
    personalizedQ8Example?: string | undefined;
    personalizedQ9?: string | undefined;
    serviceSelections?: number[] | undefined;
    targetGroup?: ("individual" | "couple" | "family" | "group" | "child" | "elderly" | "business")[] | undefined;
    minPeople?: number | undefined;
    maxPeople?: number | undefined;
    minDuration?: number | undefined;
    maxDuration?: number | undefined;
    basicPricePerHour?: number | undefined;
    additionalPricePerPerson?: number | undefined;
    basicPricePerHourCents?: number | undefined;
    additionalPricePerPersonCents?: number | undefined;
    currency?: "USD" | undefined;
    draftMetadata?: {
        clientDraftId?: string | undefined;
        handedOffAt?: string | undefined;
        anonymousDraftVersion?: number | undefined;
    } | undefined;
}>, {
    name: string;
    age: number;
    sex: "Male" | "Female" | "prefer_not_to_say";
    assessmentQ1: string[];
    assessmentQ2: string;
    assessmentQ3: string;
    assessmentQ4: string[];
    serviceAreaDestinationIds: number[];
    customServiceAreaProposals: string[];
    personalizedQ5: string[];
    personalizedQ6: string[];
    personalizedQ7: string;
    personalizedQ8Strengths: string[];
    personalizedQ8Example: string;
    personalizedQ9: string;
    serviceSelections: number[];
    targetGroup: ("individual" | "couple" | "family" | "group" | "child" | "elderly" | "business")[];
    currency: "USD";
    applicationStatus?: "drafted" | "needs_more_info" | "pending" | "under_review" | "approved" | "rejected" | undefined;
    id?: string | number | undefined;
    userId?: number | undefined;
    mbti?: string | undefined;
    socialProfile?: string | undefined;
    assessmentQ1Slider?: number | null | undefined;
    assessmentQ3Slider?: number | null | undefined;
    assessmentQ4Slider?: number | null | undefined;
    serviceAreas?: z.objectOutputType<{
        id: z.ZodOptional<z.ZodNumber>;
        destinationId: z.ZodOptional<z.ZodNumber>;
        slug: z.ZodOptional<z.ZodString>;
        countryCode: z.ZodOptional<z.ZodString>;
        nameEn: z.ZodOptional<z.ZodString>;
        nameJa: z.ZodOptional<z.ZodString>;
        nameZhCn: z.ZodOptional<z.ZodString>;
        timezone: z.ZodOptional<z.ZodString>;
        prefectureName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        placeType: z.ZodOptional<z.ZodString>;
    }, z.ZodTypeAny, "passthrough">[] | undefined;
    serviceAreaProposals?: z.objectOutputType<{
        id: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        rawName: z.ZodOptional<z.ZodString>;
        normalizedName: z.ZodOptional<z.ZodString>;
        status: z.ZodOptional<z.ZodString>;
        resolvedDestinationId: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    }, z.ZodTypeAny, "passthrough">[] | undefined;
    residenceInfo?: string | undefined;
    residenceZipcode?: string | undefined;
    residenceStartDate?: string | undefined;
    occupation?: string | undefined;
    bio?: string | undefined;
    qualifications?: {
        certifications?: Record<string, z.objectOutputType<{
            description: z.ZodOptional<z.ZodString>;
            proof: z.ZodOptional<z.ZodString>;
            visible: z.ZodOptional<z.ZodDefault<z.ZodBoolean>>;
            uploaded: z.ZodOptional<z.ZodBoolean>;
            publicUrl: z.ZodOptional<z.ZodString>;
            data: z.ZodOptional<z.ZodString>;
            name: z.ZodOptional<z.ZodString>;
            type: z.ZodOptional<z.ZodString>;
            size: z.ZodOptional<z.ZodNumber>;
            fileId: z.ZodOptional<z.ZodString>;
            stagedFileId: z.ZodOptional<z.ZodString>;
        }, z.ZodTypeAny, "passthrough">> | undefined;
    } | undefined;
    languages?: string[] | undefined;
    experienceDuration?: string | undefined;
    experienceSession?: string | undefined;
    personalizedQ5Slider?: number | null | undefined;
    personalizedQ6Slider?: number | null | undefined;
    personalizedQ7Slider?: number | null | undefined;
    personalizedQ8Slider?: number | null | undefined;
    minPeople?: number | undefined;
    maxPeople?: number | undefined;
    minDuration?: number | undefined;
    maxDuration?: number | undefined;
    basicPricePerHour?: number | undefined;
    additionalPricePerPerson?: number | undefined;
    basicPricePerHourCents?: number | undefined;
    additionalPricePerPersonCents?: number | undefined;
    draftMetadata?: {
        clientDraftId?: string | undefined;
        handedOffAt?: string | undefined;
        anonymousDraftVersion?: number | undefined;
    } | undefined;
}, {
    name: string;
    age: number;
    applicationStatus?: "drafted" | "needs_more_info" | "pending" | "under_review" | "approved" | "rejected" | undefined;
    id?: string | number | undefined;
    userId?: number | undefined;
    sex?: unknown;
    mbti?: string | undefined;
    socialProfile?: string | undefined;
    assessmentQ1?: string[] | undefined;
    assessmentQ1Slider?: number | null | undefined;
    assessmentQ2?: string | undefined;
    assessmentQ3?: string | undefined;
    assessmentQ3Slider?: number | null | undefined;
    assessmentQ4?: string[] | undefined;
    assessmentQ4Slider?: number | null | undefined;
    serviceAreaDestinationIds?: number[] | undefined;
    customServiceAreaProposals?: string[] | undefined;
    serviceAreas?: z.objectInputType<{
        id: z.ZodOptional<z.ZodNumber>;
        destinationId: z.ZodOptional<z.ZodNumber>;
        slug: z.ZodOptional<z.ZodString>;
        countryCode: z.ZodOptional<z.ZodString>;
        nameEn: z.ZodOptional<z.ZodString>;
        nameJa: z.ZodOptional<z.ZodString>;
        nameZhCn: z.ZodOptional<z.ZodString>;
        timezone: z.ZodOptional<z.ZodString>;
        prefectureName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        placeType: z.ZodOptional<z.ZodString>;
    }, z.ZodTypeAny, "passthrough">[] | undefined;
    serviceAreaProposals?: z.objectInputType<{
        id: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        rawName: z.ZodOptional<z.ZodString>;
        normalizedName: z.ZodOptional<z.ZodString>;
        status: z.ZodOptional<z.ZodString>;
        resolvedDestinationId: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    }, z.ZodTypeAny, "passthrough">[] | undefined;
    residenceInfo?: string | undefined;
    residenceZipcode?: string | undefined;
    residenceStartDate?: string | undefined;
    occupation?: string | undefined;
    bio?: string | undefined;
    qualifications?: {
        certifications?: Record<string, z.objectInputType<{
            description: z.ZodOptional<z.ZodString>;
            proof: z.ZodOptional<z.ZodString>;
            visible: z.ZodOptional<z.ZodDefault<z.ZodBoolean>>;
            uploaded: z.ZodOptional<z.ZodBoolean>;
            publicUrl: z.ZodOptional<z.ZodString>;
            data: z.ZodOptional<z.ZodString>;
            name: z.ZodOptional<z.ZodString>;
            type: z.ZodOptional<z.ZodString>;
            size: z.ZodOptional<z.ZodNumber>;
            fileId: z.ZodOptional<z.ZodString>;
            stagedFileId: z.ZodOptional<z.ZodString>;
        }, z.ZodTypeAny, "passthrough">> | undefined;
    } | undefined;
    languages?: string[] | undefined;
    experienceDuration?: string | undefined;
    experienceSession?: string | undefined;
    personalizedQ5?: string[] | undefined;
    personalizedQ5Slider?: number | null | undefined;
    personalizedQ6?: string[] | undefined;
    personalizedQ6Slider?: number | null | undefined;
    personalizedQ7?: string | undefined;
    personalizedQ7Slider?: number | null | undefined;
    personalizedQ8Strengths?: string[] | undefined;
    personalizedQ8Slider?: number | null | undefined;
    personalizedQ8Example?: string | undefined;
    personalizedQ9?: string | undefined;
    serviceSelections?: number[] | undefined;
    targetGroup?: ("individual" | "couple" | "family" | "group" | "child" | "elderly" | "business")[] | undefined;
    minPeople?: number | undefined;
    maxPeople?: number | undefined;
    minDuration?: number | undefined;
    maxDuration?: number | undefined;
    basicPricePerHour?: number | undefined;
    additionalPricePerPerson?: number | undefined;
    basicPricePerHourCents?: number | undefined;
    additionalPricePerPersonCents?: number | undefined;
    currency?: "USD" | undefined;
    draftMetadata?: {
        clientDraftId?: string | undefined;
        handedOffAt?: string | undefined;
        anonymousDraftVersion?: number | undefined;
    } | undefined;
}>, {
    name: string;
    age: number;
    sex: "Male" | "Female" | "prefer_not_to_say";
    assessmentQ1: string[];
    assessmentQ2: string;
    assessmentQ3: string;
    assessmentQ4: string[];
    serviceAreaDestinationIds: number[];
    customServiceAreaProposals: string[];
    personalizedQ5: string[];
    personalizedQ6: string[];
    personalizedQ7: string;
    personalizedQ8Strengths: string[];
    personalizedQ8Example: string;
    personalizedQ9: string;
    serviceSelections: number[];
    targetGroup: ("individual" | "couple" | "family" | "group" | "child" | "elderly" | "business")[];
    currency: "USD";
    applicationStatus?: "drafted" | "needs_more_info" | "pending" | "under_review" | "approved" | "rejected" | undefined;
    id?: string | number | undefined;
    userId?: number | undefined;
    mbti?: string | undefined;
    socialProfile?: string | undefined;
    assessmentQ1Slider?: number | null | undefined;
    assessmentQ3Slider?: number | null | undefined;
    assessmentQ4Slider?: number | null | undefined;
    serviceAreas?: z.objectOutputType<{
        id: z.ZodOptional<z.ZodNumber>;
        destinationId: z.ZodOptional<z.ZodNumber>;
        slug: z.ZodOptional<z.ZodString>;
        countryCode: z.ZodOptional<z.ZodString>;
        nameEn: z.ZodOptional<z.ZodString>;
        nameJa: z.ZodOptional<z.ZodString>;
        nameZhCn: z.ZodOptional<z.ZodString>;
        timezone: z.ZodOptional<z.ZodString>;
        prefectureName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        placeType: z.ZodOptional<z.ZodString>;
    }, z.ZodTypeAny, "passthrough">[] | undefined;
    serviceAreaProposals?: z.objectOutputType<{
        id: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        rawName: z.ZodOptional<z.ZodString>;
        normalizedName: z.ZodOptional<z.ZodString>;
        status: z.ZodOptional<z.ZodString>;
        resolvedDestinationId: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    }, z.ZodTypeAny, "passthrough">[] | undefined;
    residenceInfo?: string | undefined;
    residenceZipcode?: string | undefined;
    residenceStartDate?: string | undefined;
    occupation?: string | undefined;
    bio?: string | undefined;
    qualifications?: {
        certifications?: Record<string, z.objectOutputType<{
            description: z.ZodOptional<z.ZodString>;
            proof: z.ZodOptional<z.ZodString>;
            visible: z.ZodOptional<z.ZodDefault<z.ZodBoolean>>;
            uploaded: z.ZodOptional<z.ZodBoolean>;
            publicUrl: z.ZodOptional<z.ZodString>;
            data: z.ZodOptional<z.ZodString>;
            name: z.ZodOptional<z.ZodString>;
            type: z.ZodOptional<z.ZodString>;
            size: z.ZodOptional<z.ZodNumber>;
            fileId: z.ZodOptional<z.ZodString>;
            stagedFileId: z.ZodOptional<z.ZodString>;
        }, z.ZodTypeAny, "passthrough">> | undefined;
    } | undefined;
    languages?: string[] | undefined;
    experienceDuration?: string | undefined;
    experienceSession?: string | undefined;
    personalizedQ5Slider?: number | null | undefined;
    personalizedQ6Slider?: number | null | undefined;
    personalizedQ7Slider?: number | null | undefined;
    personalizedQ8Slider?: number | null | undefined;
    minPeople?: number | undefined;
    maxPeople?: number | undefined;
    minDuration?: number | undefined;
    maxDuration?: number | undefined;
    basicPricePerHour?: number | undefined;
    additionalPricePerPerson?: number | undefined;
    basicPricePerHourCents?: number | undefined;
    additionalPricePerPersonCents?: number | undefined;
    draftMetadata?: {
        clientDraftId?: string | undefined;
        handedOffAt?: string | undefined;
        anonymousDraftVersion?: number | undefined;
    } | undefined;
}, {
    name: string;
    age: number;
    applicationStatus?: "drafted" | "needs_more_info" | "pending" | "under_review" | "approved" | "rejected" | undefined;
    id?: string | number | undefined;
    userId?: number | undefined;
    sex?: unknown;
    mbti?: string | undefined;
    socialProfile?: string | undefined;
    assessmentQ1?: string[] | undefined;
    assessmentQ1Slider?: number | null | undefined;
    assessmentQ2?: string | undefined;
    assessmentQ3?: string | undefined;
    assessmentQ3Slider?: number | null | undefined;
    assessmentQ4?: string[] | undefined;
    assessmentQ4Slider?: number | null | undefined;
    serviceAreaDestinationIds?: number[] | undefined;
    customServiceAreaProposals?: string[] | undefined;
    serviceAreas?: z.objectInputType<{
        id: z.ZodOptional<z.ZodNumber>;
        destinationId: z.ZodOptional<z.ZodNumber>;
        slug: z.ZodOptional<z.ZodString>;
        countryCode: z.ZodOptional<z.ZodString>;
        nameEn: z.ZodOptional<z.ZodString>;
        nameJa: z.ZodOptional<z.ZodString>;
        nameZhCn: z.ZodOptional<z.ZodString>;
        timezone: z.ZodOptional<z.ZodString>;
        prefectureName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        placeType: z.ZodOptional<z.ZodString>;
    }, z.ZodTypeAny, "passthrough">[] | undefined;
    serviceAreaProposals?: z.objectInputType<{
        id: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        rawName: z.ZodOptional<z.ZodString>;
        normalizedName: z.ZodOptional<z.ZodString>;
        status: z.ZodOptional<z.ZodString>;
        resolvedDestinationId: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    }, z.ZodTypeAny, "passthrough">[] | undefined;
    residenceInfo?: string | undefined;
    residenceZipcode?: string | undefined;
    residenceStartDate?: string | undefined;
    occupation?: string | undefined;
    bio?: string | undefined;
    qualifications?: {
        certifications?: Record<string, z.objectInputType<{
            description: z.ZodOptional<z.ZodString>;
            proof: z.ZodOptional<z.ZodString>;
            visible: z.ZodOptional<z.ZodDefault<z.ZodBoolean>>;
            uploaded: z.ZodOptional<z.ZodBoolean>;
            publicUrl: z.ZodOptional<z.ZodString>;
            data: z.ZodOptional<z.ZodString>;
            name: z.ZodOptional<z.ZodString>;
            type: z.ZodOptional<z.ZodString>;
            size: z.ZodOptional<z.ZodNumber>;
            fileId: z.ZodOptional<z.ZodString>;
            stagedFileId: z.ZodOptional<z.ZodString>;
        }, z.ZodTypeAny, "passthrough">> | undefined;
    } | undefined;
    languages?: string[] | undefined;
    experienceDuration?: string | undefined;
    experienceSession?: string | undefined;
    personalizedQ5?: string[] | undefined;
    personalizedQ5Slider?: number | null | undefined;
    personalizedQ6?: string[] | undefined;
    personalizedQ6Slider?: number | null | undefined;
    personalizedQ7?: string | undefined;
    personalizedQ7Slider?: number | null | undefined;
    personalizedQ8Strengths?: string[] | undefined;
    personalizedQ8Slider?: number | null | undefined;
    personalizedQ8Example?: string | undefined;
    personalizedQ9?: string | undefined;
    serviceSelections?: number[] | undefined;
    targetGroup?: ("individual" | "couple" | "family" | "group" | "child" | "elderly" | "business")[] | undefined;
    minPeople?: number | undefined;
    maxPeople?: number | undefined;
    minDuration?: number | undefined;
    maxDuration?: number | undefined;
    basicPricePerHour?: number | undefined;
    additionalPricePerPerson?: number | undefined;
    basicPricePerHourCents?: number | undefined;
    additionalPricePerPersonCents?: number | undefined;
    currency?: "USD" | undefined;
    draftMetadata?: {
        clientDraftId?: string | undefined;
        handedOffAt?: string | undefined;
        anonymousDraftVersion?: number | undefined;
    } | undefined;
}>;
type FormData = z.infer<typeof formSchema>;
interface GuideFormDestination {
    id: number;
    countryCode?: string;
    slug: string;
    nameEn?: string | null;
    nameJa?: string | null;
    nameZhCn?: string | null;
    timezone?: string | null;
    prefectureName?: string | null;
    placeType?: string | null;
    status?: string | null;
    sortOrder?: number | null;
}
type GuideFunnelState = "anonymous_editing" | "auth_required" | "verification_required" | "resume_after_auth" | "authenticated_editing" | "preview" | "submitted";
type GuideResumeState = "idle" | "loading" | "draft_hydrated" | "auth_resolved" | "handoff_eligible" | "handoff_in_flight" | "handoff_complete" | "handoff_failed";
type GuideDraftConflictReason = "existing_server_draft" | "submitted_application" | "guide_profile_exists" | "anonymous_draft_claimed" | "idempotent_handoff" | "stale_local_draft" | "local_newer";
interface GuideDraftConflict {
    code: string;
    reason: GuideDraftConflictReason;
    serverDraft?: {
        id?: string | number;
        updatedAt?: string;
        applicationStatus?: string;
        lastMeaningfulState?: string;
    };
    clientDraft?: {
        clientDraftId?: string;
        updatedAt?: string;
        anonymousDraftVersion?: number;
    };
}
interface GuideFormConfig {
    /** First-touch attribution only. It must not alter identity or ownership behavior. */
    applicationSource?: string;
    /** Canonical host-resolved lifecycle intent; omitted for backward-compatible discovery. */
    applicationContinuation?: GuideApplicationContinuationIntent;
    apiEndpoints: {
        saveDraft?: string;
        submitApplication: string;
        loadDraft?: string;
        handoffDraft?: string;
        createSignupIntent?: string;
        serviceCategories?: string;
        qualificationUpload?: string;
        archivePdf?: (applicationId: string | number) => string;
        updateApplication?: (applicationId: string | number) => string;
    };
    resolveApiUrl?: (path: string) => string;
    auth: {
        getToken: () => string | null;
        getUserId: () => number | null;
        getUser?: () => {
            emailVerified?: boolean;
            emailverified?: boolean;
            [key: string]: unknown;
        } | null;
        isEmailVerified?: () => boolean;
        /** True while the host is still hydrating its authenticated session. */
        isLoading?: () => boolean;
    };
    callbacks: {
        onSuccess?: (data: unknown) => void;
        onError?: (error: unknown) => void;
        onSaveDraft?: (data: unknown) => void;
        onAuthRequired?: (redirectTo: string, context?: {
            signupIntentToken?: string | null;
            anonymousDraftId?: string | null;
        }) => void;
        onVerificationRequired?: (redirectTo: string) => void;
        onHandoffSuccess?: (data: unknown) => void;
        onHandoffConflict?: (conflict: GuideDraftConflict) => void;
        onDraftLoaded?: (data: unknown) => void;
        onNavigateToStatus?: () => void;
        onNavigateToGuideHome?: () => void;
    };
    routes?: {
        signup?: string;
        login?: string;
        verifyEmail?: string;
        resumePath?: string;
    };
    ui?: {
        showProgressBar?: boolean;
        showPreview?: boolean;
        customTitle?: string;
        customDescription?: string;
    };
}

interface UIComponents$1 {
    Form: any;
    FormField: any;
    FormItem: any;
    FormLabel: any;
    FormControl: any;
    FormMessage: any;
    Input: any;
    Select: any;
    SelectContent: any;
    SelectItem: any;
    SelectTrigger: any;
    SelectValue: any;
    Textarea: any;
    Checkbox: any;
    RadioGroup: any;
    RadioGroupItem: any;
    Button: any;
    Progress: any;
    Slider: any;
    Card: any;
    CardContent: any;
    CardHeader: any;
    CardTitle: any;
    Badge: any;
    Separator: any;
    YearMonthPicker: any;
    QualificationUploader?: any;
    Tooltip?: any;
    TooltipContent?: any;
    TooltipProvider?: any;
    TooltipTrigger?: any;
    Info?: any;
    ChevronLeft?: any;
    ChevronRight?: any;
    Save?: any;
}
interface GuideFormProps {
    config: GuideFormConfig;
    ui: UIComponents$1;
    destinations?: GuideFormDestination[];
    destinationsLoading?: boolean;
    destinationsLoadError?: boolean;
    allowCustomDestination?: boolean;
    targetGroups?: Array<{
        value: string;
        label?: string;
    }>;
    serviceCategories?: Array<{
        id: number;
        nameCn: string;
        nameEn: string;
        subcategories: Array<{
            id: number;
            categoryId: number;
            nameCn: string;
            nameEn: string;
            isCustom: boolean;
        }>;
    }>;
    onLoadServiceCategories?: () => Promise<Array<{
        id: number;
        nameCn: string;
        nameEn: string;
        subcategories: Array<{
            id: number;
            categoryId: number;
            nameCn: string;
            nameEn: string;
            isCustom: boolean;
        }>;
    }>>;
    customTitle?: string;
    customDescription?: string;
    showProgressBar?: boolean;
    onLoadLocalStorage?: () => any;
    onSaveLocalStorage?: (data: any) => void;
    onClearLocalStorage?: () => void;
    initialStep?: 'preview' | 'resume';
}
declare const GuideForm: React__default.FC<GuideFormProps>;

declare const FOUNDER_NOTE_READ_STORAGE_KEY = "yaotu_founder_note_read";
declare const FounderNoteMail: () => react_jsx_runtime.JSX.Element;

type GuideFormLocale = 'en' | 'zh-CN' | 'zh';
type TranslationFunction = (key: string) => string;
type GuideFormMessages = Record<string, unknown>;
declare const guideFormEnglishMessages: GuideFormMessages;
declare const guideFormChineseMessages: GuideFormMessages;
declare const createGuideFormTranslator: (locale?: GuideFormLocale) => TranslationFunction;

interface EvaluationSliderUI {
    Slider: any;
    Tooltip?: any;
    TooltipContent?: any;
    TooltipProvider?: any;
    TooltipTrigger?: any;
    Info?: any;
}

interface EvaluationQuestionUI extends EvaluationSliderUI {
    Checkbox: any;
    FormControl: any;
    FormField: any;
    FormItem: any;
    FormLabel: any;
    FormMessage: any;
    RadioGroup: any;
    RadioGroupItem: any;
    Textarea: any;
}
interface Step2SelfAssessmentProps {
    control: Control<FormData> | Control<any>;
    ui: EvaluationQuestionUI;
    t?: TranslationFunction;
    locale?: GuideFormLocale;
}
declare const Step2SelfAssessment: ({ control, ui, t, locale, }: Step2SelfAssessmentProps) => react_jsx_runtime.JSX.Element;

interface Step3PersonalizedQuestionsProps {
    control: Control<FormData> | Control<any>;
    ui: EvaluationQuestionUI;
    t?: TranslationFunction;
    locale?: GuideFormLocale;
}
declare const Step3PersonalizedQuestions: ({ control, ui, t, locale, }: Step3PersonalizedQuestionsProps) => react_jsx_runtime.JSX.Element;

type InitialStep = "preview" | "resume";
type DraftSource = "anonymous" | "server";
declare const useGuideForm: (config: GuideFormConfig, onLoadLocalStorage?: () => any, onSaveLocalStorage?: (data: any) => void, onClearLocalStorage?: () => void, initialStep?: InitialStep) => {
    currentPage: number;
    setCurrentPage: React.Dispatch<React.SetStateAction<number>>;
    showPreview: boolean;
    setShowPreview: React.Dispatch<React.SetStateAction<boolean>>;
    confirmationChecked: boolean;
    setConfirmationChecked: React.Dispatch<React.SetStateAction<boolean>>;
    missingFields: string[];
    setMissingFields: React.Dispatch<React.SetStateAction<string[]>>;
    savedData: Partial<{
        name: string;
        age: number;
        sex: "Male" | "Female" | "prefer_not_to_say";
        assessmentQ1: string[];
        assessmentQ2: string;
        assessmentQ3: string;
        assessmentQ4: string[];
        serviceAreaDestinationIds: number[];
        customServiceAreaProposals: string[];
        personalizedQ5: string[];
        personalizedQ6: string[];
        personalizedQ7: string;
        personalizedQ8Strengths: string[];
        personalizedQ8Example: string;
        personalizedQ9: string;
        serviceSelections: number[];
        targetGroup: ("individual" | "couple" | "family" | "group" | "child" | "elderly" | "business")[];
        currency: "USD";
        applicationStatus?: "drafted" | "needs_more_info" | "pending" | "under_review" | "approved" | "rejected" | undefined;
        id?: string | number | undefined;
        userId?: number | undefined;
        mbti?: string | undefined;
        socialProfile?: string | undefined;
        assessmentQ1Slider?: number | null | undefined;
        assessmentQ3Slider?: number | null | undefined;
        assessmentQ4Slider?: number | null | undefined;
        serviceAreas?: zod.objectOutputType<{
            id: zod.ZodOptional<zod.ZodNumber>;
            destinationId: zod.ZodOptional<zod.ZodNumber>;
            slug: zod.ZodOptional<zod.ZodString>;
            countryCode: zod.ZodOptional<zod.ZodString>;
            nameEn: zod.ZodOptional<zod.ZodString>;
            nameJa: zod.ZodOptional<zod.ZodString>;
            nameZhCn: zod.ZodOptional<zod.ZodString>;
            timezone: zod.ZodOptional<zod.ZodString>;
            prefectureName: zod.ZodOptional<zod.ZodNullable<zod.ZodString>>;
            placeType: zod.ZodOptional<zod.ZodString>;
        }, zod.ZodTypeAny, "passthrough">[] | undefined;
        serviceAreaProposals?: zod.objectOutputType<{
            id: zod.ZodOptional<zod.ZodUnion<[zod.ZodString, zod.ZodNumber]>>;
            rawName: zod.ZodOptional<zod.ZodString>;
            normalizedName: zod.ZodOptional<zod.ZodString>;
            status: zod.ZodOptional<zod.ZodString>;
            resolvedDestinationId: zod.ZodOptional<zod.ZodNullable<zod.ZodNumber>>;
        }, zod.ZodTypeAny, "passthrough">[] | undefined;
        residenceInfo?: string | undefined;
        residenceZipcode?: string | undefined;
        residenceStartDate?: string | undefined;
        occupation?: string | undefined;
        bio?: string | undefined;
        qualifications?: {
            certifications?: Record<string, zod.objectOutputType<{
                description: zod.ZodOptional<zod.ZodString>;
                proof: zod.ZodOptional<zod.ZodString>;
                visible: zod.ZodOptional<zod.ZodDefault<zod.ZodBoolean>>;
                uploaded: zod.ZodOptional<zod.ZodBoolean>;
                publicUrl: zod.ZodOptional<zod.ZodString>;
                data: zod.ZodOptional<zod.ZodString>;
                name: zod.ZodOptional<zod.ZodString>;
                type: zod.ZodOptional<zod.ZodString>;
                size: zod.ZodOptional<zod.ZodNumber>;
                fileId: zod.ZodOptional<zod.ZodString>;
                stagedFileId: zod.ZodOptional<zod.ZodString>;
            }, zod.ZodTypeAny, "passthrough">> | undefined;
        } | undefined;
        languages?: string[] | undefined;
        experienceDuration?: string | undefined;
        experienceSession?: string | undefined;
        personalizedQ5Slider?: number | null | undefined;
        personalizedQ6Slider?: number | null | undefined;
        personalizedQ7Slider?: number | null | undefined;
        personalizedQ8Slider?: number | null | undefined;
        minPeople?: number | undefined;
        maxPeople?: number | undefined;
        minDuration?: number | undefined;
        maxDuration?: number | undefined;
        basicPricePerHour?: number | undefined;
        additionalPricePerPerson?: number | undefined;
        basicPricePerHourCents?: number | undefined;
        additionalPricePerPersonCents?: number | undefined;
        draftMetadata?: {
            clientDraftId?: string | undefined;
            handedOffAt?: string | undefined;
            anonymousDraftVersion?: number | undefined;
        } | undefined;
    }>;
    setSavedData: React.Dispatch<React.SetStateAction<Partial<{
        name: string;
        age: number;
        sex: "Male" | "Female" | "prefer_not_to_say";
        assessmentQ1: string[];
        assessmentQ2: string;
        assessmentQ3: string;
        assessmentQ4: string[];
        serviceAreaDestinationIds: number[];
        customServiceAreaProposals: string[];
        personalizedQ5: string[];
        personalizedQ6: string[];
        personalizedQ7: string;
        personalizedQ8Strengths: string[];
        personalizedQ8Example: string;
        personalizedQ9: string;
        serviceSelections: number[];
        targetGroup: ("individual" | "couple" | "family" | "group" | "child" | "elderly" | "business")[];
        currency: "USD";
        applicationStatus?: "drafted" | "needs_more_info" | "pending" | "under_review" | "approved" | "rejected" | undefined;
        id?: string | number | undefined;
        userId?: number | undefined;
        mbti?: string | undefined;
        socialProfile?: string | undefined;
        assessmentQ1Slider?: number | null | undefined;
        assessmentQ3Slider?: number | null | undefined;
        assessmentQ4Slider?: number | null | undefined;
        serviceAreas?: zod.objectOutputType<{
            id: zod.ZodOptional<zod.ZodNumber>;
            destinationId: zod.ZodOptional<zod.ZodNumber>;
            slug: zod.ZodOptional<zod.ZodString>;
            countryCode: zod.ZodOptional<zod.ZodString>;
            nameEn: zod.ZodOptional<zod.ZodString>;
            nameJa: zod.ZodOptional<zod.ZodString>;
            nameZhCn: zod.ZodOptional<zod.ZodString>;
            timezone: zod.ZodOptional<zod.ZodString>;
            prefectureName: zod.ZodOptional<zod.ZodNullable<zod.ZodString>>;
            placeType: zod.ZodOptional<zod.ZodString>;
        }, zod.ZodTypeAny, "passthrough">[] | undefined;
        serviceAreaProposals?: zod.objectOutputType<{
            id: zod.ZodOptional<zod.ZodUnion<[zod.ZodString, zod.ZodNumber]>>;
            rawName: zod.ZodOptional<zod.ZodString>;
            normalizedName: zod.ZodOptional<zod.ZodString>;
            status: zod.ZodOptional<zod.ZodString>;
            resolvedDestinationId: zod.ZodOptional<zod.ZodNullable<zod.ZodNumber>>;
        }, zod.ZodTypeAny, "passthrough">[] | undefined;
        residenceInfo?: string | undefined;
        residenceZipcode?: string | undefined;
        residenceStartDate?: string | undefined;
        occupation?: string | undefined;
        bio?: string | undefined;
        qualifications?: {
            certifications?: Record<string, zod.objectOutputType<{
                description: zod.ZodOptional<zod.ZodString>;
                proof: zod.ZodOptional<zod.ZodString>;
                visible: zod.ZodOptional<zod.ZodDefault<zod.ZodBoolean>>;
                uploaded: zod.ZodOptional<zod.ZodBoolean>;
                publicUrl: zod.ZodOptional<zod.ZodString>;
                data: zod.ZodOptional<zod.ZodString>;
                name: zod.ZodOptional<zod.ZodString>;
                type: zod.ZodOptional<zod.ZodString>;
                size: zod.ZodOptional<zod.ZodNumber>;
                fileId: zod.ZodOptional<zod.ZodString>;
                stagedFileId: zod.ZodOptional<zod.ZodString>;
            }, zod.ZodTypeAny, "passthrough">> | undefined;
        } | undefined;
        languages?: string[] | undefined;
        experienceDuration?: string | undefined;
        experienceSession?: string | undefined;
        personalizedQ5Slider?: number | null | undefined;
        personalizedQ6Slider?: number | null | undefined;
        personalizedQ7Slider?: number | null | undefined;
        personalizedQ8Slider?: number | null | undefined;
        minPeople?: number | undefined;
        maxPeople?: number | undefined;
        minDuration?: number | undefined;
        maxDuration?: number | undefined;
        basicPricePerHour?: number | undefined;
        additionalPricePerPerson?: number | undefined;
        basicPricePerHourCents?: number | undefined;
        additionalPricePerPersonCents?: number | undefined;
        draftMetadata?: {
            clientDraftId?: string | undefined;
            handedOffAt?: string | undefined;
            anonymousDraftVersion?: number | undefined;
        } | undefined;
    }>>>;
    isLoading: boolean;
    isSaving: boolean;
    isSubmitting: boolean;
    isCreatingSignupIntent: boolean;
    draftSource: DraftSource;
    dbDraftId: string | number | null;
    funnelState: GuideFunnelState;
    resumeState: GuideResumeState;
    isDraftHydrated: boolean;
    draftConflict: GuideDraftConflict | null;
    resumePath: string;
    form: react_hook_form.UseFormReturn<{
        name: string;
        age: number;
        sex: "Male" | "Female" | "prefer_not_to_say";
        assessmentQ1: string[];
        assessmentQ2: string;
        assessmentQ3: string;
        assessmentQ4: string[];
        serviceAreaDestinationIds: number[];
        customServiceAreaProposals: string[];
        personalizedQ5: string[];
        personalizedQ6: string[];
        personalizedQ7: string;
        personalizedQ8Strengths: string[];
        personalizedQ8Example: string;
        personalizedQ9: string;
        serviceSelections: number[];
        targetGroup: ("individual" | "couple" | "family" | "group" | "child" | "elderly" | "business")[];
        currency: "USD";
        applicationStatus?: "drafted" | "needs_more_info" | "pending" | "under_review" | "approved" | "rejected" | undefined;
        id?: string | number | undefined;
        userId?: number | undefined;
        mbti?: string | undefined;
        socialProfile?: string | undefined;
        assessmentQ1Slider?: number | null | undefined;
        assessmentQ3Slider?: number | null | undefined;
        assessmentQ4Slider?: number | null | undefined;
        serviceAreas?: zod.objectOutputType<{
            id: zod.ZodOptional<zod.ZodNumber>;
            destinationId: zod.ZodOptional<zod.ZodNumber>;
            slug: zod.ZodOptional<zod.ZodString>;
            countryCode: zod.ZodOptional<zod.ZodString>;
            nameEn: zod.ZodOptional<zod.ZodString>;
            nameJa: zod.ZodOptional<zod.ZodString>;
            nameZhCn: zod.ZodOptional<zod.ZodString>;
            timezone: zod.ZodOptional<zod.ZodString>;
            prefectureName: zod.ZodOptional<zod.ZodNullable<zod.ZodString>>;
            placeType: zod.ZodOptional<zod.ZodString>;
        }, zod.ZodTypeAny, "passthrough">[] | undefined;
        serviceAreaProposals?: zod.objectOutputType<{
            id: zod.ZodOptional<zod.ZodUnion<[zod.ZodString, zod.ZodNumber]>>;
            rawName: zod.ZodOptional<zod.ZodString>;
            normalizedName: zod.ZodOptional<zod.ZodString>;
            status: zod.ZodOptional<zod.ZodString>;
            resolvedDestinationId: zod.ZodOptional<zod.ZodNullable<zod.ZodNumber>>;
        }, zod.ZodTypeAny, "passthrough">[] | undefined;
        residenceInfo?: string | undefined;
        residenceZipcode?: string | undefined;
        residenceStartDate?: string | undefined;
        occupation?: string | undefined;
        bio?: string | undefined;
        qualifications?: {
            certifications?: Record<string, zod.objectOutputType<{
                description: zod.ZodOptional<zod.ZodString>;
                proof: zod.ZodOptional<zod.ZodString>;
                visible: zod.ZodOptional<zod.ZodDefault<zod.ZodBoolean>>;
                uploaded: zod.ZodOptional<zod.ZodBoolean>;
                publicUrl: zod.ZodOptional<zod.ZodString>;
                data: zod.ZodOptional<zod.ZodString>;
                name: zod.ZodOptional<zod.ZodString>;
                type: zod.ZodOptional<zod.ZodString>;
                size: zod.ZodOptional<zod.ZodNumber>;
                fileId: zod.ZodOptional<zod.ZodString>;
                stagedFileId: zod.ZodOptional<zod.ZodString>;
            }, zod.ZodTypeAny, "passthrough">> | undefined;
        } | undefined;
        languages?: string[] | undefined;
        experienceDuration?: string | undefined;
        experienceSession?: string | undefined;
        personalizedQ5Slider?: number | null | undefined;
        personalizedQ6Slider?: number | null | undefined;
        personalizedQ7Slider?: number | null | undefined;
        personalizedQ8Slider?: number | null | undefined;
        minPeople?: number | undefined;
        maxPeople?: number | undefined;
        minDuration?: number | undefined;
        maxDuration?: number | undefined;
        basicPricePerHour?: number | undefined;
        additionalPricePerPerson?: number | undefined;
        basicPricePerHourCents?: number | undefined;
        additionalPricePerPersonCents?: number | undefined;
        draftMetadata?: {
            clientDraftId?: string | undefined;
            handedOffAt?: string | undefined;
            anonymousDraftVersion?: number | undefined;
        } | undefined;
    }, any, {
        name: string;
        age: number;
        sex: "Male" | "Female" | "prefer_not_to_say";
        assessmentQ1: string[];
        assessmentQ2: string;
        assessmentQ3: string;
        assessmentQ4: string[];
        serviceAreaDestinationIds: number[];
        customServiceAreaProposals: string[];
        personalizedQ5: string[];
        personalizedQ6: string[];
        personalizedQ7: string;
        personalizedQ8Strengths: string[];
        personalizedQ8Example: string;
        personalizedQ9: string;
        serviceSelections: number[];
        targetGroup: ("individual" | "couple" | "family" | "group" | "child" | "elderly" | "business")[];
        currency: "USD";
        applicationStatus?: "drafted" | "needs_more_info" | "pending" | "under_review" | "approved" | "rejected" | undefined;
        id?: string | number | undefined;
        userId?: number | undefined;
        mbti?: string | undefined;
        socialProfile?: string | undefined;
        assessmentQ1Slider?: number | null | undefined;
        assessmentQ3Slider?: number | null | undefined;
        assessmentQ4Slider?: number | null | undefined;
        serviceAreas?: zod.objectOutputType<{
            id: zod.ZodOptional<zod.ZodNumber>;
            destinationId: zod.ZodOptional<zod.ZodNumber>;
            slug: zod.ZodOptional<zod.ZodString>;
            countryCode: zod.ZodOptional<zod.ZodString>;
            nameEn: zod.ZodOptional<zod.ZodString>;
            nameJa: zod.ZodOptional<zod.ZodString>;
            nameZhCn: zod.ZodOptional<zod.ZodString>;
            timezone: zod.ZodOptional<zod.ZodString>;
            prefectureName: zod.ZodOptional<zod.ZodNullable<zod.ZodString>>;
            placeType: zod.ZodOptional<zod.ZodString>;
        }, zod.ZodTypeAny, "passthrough">[] | undefined;
        serviceAreaProposals?: zod.objectOutputType<{
            id: zod.ZodOptional<zod.ZodUnion<[zod.ZodString, zod.ZodNumber]>>;
            rawName: zod.ZodOptional<zod.ZodString>;
            normalizedName: zod.ZodOptional<zod.ZodString>;
            status: zod.ZodOptional<zod.ZodString>;
            resolvedDestinationId: zod.ZodOptional<zod.ZodNullable<zod.ZodNumber>>;
        }, zod.ZodTypeAny, "passthrough">[] | undefined;
        residenceInfo?: string | undefined;
        residenceZipcode?: string | undefined;
        residenceStartDate?: string | undefined;
        occupation?: string | undefined;
        bio?: string | undefined;
        qualifications?: {
            certifications?: Record<string, zod.objectOutputType<{
                description: zod.ZodOptional<zod.ZodString>;
                proof: zod.ZodOptional<zod.ZodString>;
                visible: zod.ZodOptional<zod.ZodDefault<zod.ZodBoolean>>;
                uploaded: zod.ZodOptional<zod.ZodBoolean>;
                publicUrl: zod.ZodOptional<zod.ZodString>;
                data: zod.ZodOptional<zod.ZodString>;
                name: zod.ZodOptional<zod.ZodString>;
                type: zod.ZodOptional<zod.ZodString>;
                size: zod.ZodOptional<zod.ZodNumber>;
                fileId: zod.ZodOptional<zod.ZodString>;
                stagedFileId: zod.ZodOptional<zod.ZodString>;
            }, zod.ZodTypeAny, "passthrough">> | undefined;
        } | undefined;
        languages?: string[] | undefined;
        experienceDuration?: string | undefined;
        experienceSession?: string | undefined;
        personalizedQ5Slider?: number | null | undefined;
        personalizedQ6Slider?: number | null | undefined;
        personalizedQ7Slider?: number | null | undefined;
        personalizedQ8Slider?: number | null | undefined;
        minPeople?: number | undefined;
        maxPeople?: number | undefined;
        minDuration?: number | undefined;
        maxDuration?: number | undefined;
        basicPricePerHour?: number | undefined;
        additionalPricePerPerson?: number | undefined;
        basicPricePerHourCents?: number | undefined;
        additionalPricePerPersonCents?: number | undefined;
        draftMetadata?: {
            clientDraftId?: string | undefined;
            handedOffAt?: string | undefined;
            anonymousDraftVersion?: number | undefined;
        } | undefined;
    }>;
    saveCurrentPageData: () => void;
    handleQualificationFilesChange: (files: any) => void;
    saveDraft: (data: FormData) => Promise<any>;
    submitApplication: (data: FormData) => Promise<any>;
    continueToAuth: () => Promise<void>;
    nextPage: () => Promise<void>;
    prevPage: () => void;
    goToPreview: () => Promise<void>;
    backToForm: () => void;
    onSubmit: () => Promise<void>;
    validateFormCompleteness: (formData: Partial<FormData>) => string[];
    handoffAnonymousDraft: () => Promise<any>;
    acceptServerDraft: () => Promise<void>;
};

interface UIComponents {
    Card: any;
    CardContent: any;
    Button: any;
    Checkbox: any;
}
interface ApplicationPreviewProps {
    formData: Partial<FormData>;
    missingFields: string[];
    confirmationChecked: boolean;
    setConfirmationChecked: (checked: boolean) => void;
    onBackToForm: () => void;
    onSubmit: () => void;
    isSubmitting: boolean;
    requiresAccountBeforeSubmit?: boolean;
    validateFormCompleteness: (formData: Partial<FormData>) => string[];
    setMissingFields: (fields: string[]) => void;
    destinations?: GuideFormDestination[];
    ui: UIComponents;
    intl?: any;
}
declare const ApplicationPreview: ({ formData, missingFields, confirmationChecked, setConfirmationChecked, onBackToForm, onSubmit, isSubmitting, requiresAccountBeforeSubmit, validateFormCompleteness, setMissingFields, destinations, ui, intl, }: ApplicationPreviewProps) => react_jsx_runtime.JSX.Element;

interface PDFOptions {
    margin?: number | [number, number] | [number, number, number, number];
    filename?: string;
    image?: {
        type?: "jpeg" | "png" | "webp";
        quality?: number;
    };
    html2canvas?: {
        scale?: number;
        useCORS?: boolean;
        allowTaint?: boolean;
        backgroundColor?: string;
    };
    jsPDF?: {
        unit?: string;
        format?: string;
        orientation?: string;
        compress?: boolean;
    };
    pagebreak?: {
        mode?: string[];
    };
}
interface PDFUploadOptions {
    applicationId: string;
    token: string;
    uploadUrl: string;
}
declare const defaultPDFOptions: PDFOptions;
/**
 * 生成PDF Blob
 * @param elementId - 要转换为PDF的DOM元素ID
 * @param options - PDF生成选项
 * @returns Promise<Blob> - PDF文件的Blob对象
 */
declare function generatePDFBlob(elementId: string, options?: PDFOptions): Promise<Blob>;
/**
 * 下载PDF文件
 * @param pdfBlob - PDF文件的Blob对象
 * @param filename - 下载的文件名
 */
declare function downloadPDF(pdfBlob: Blob, filename: string): void;
/**
 * 上传PDF到服务器
 * @param pdfBlob - PDF文件的Blob对象
 * @param options - 上传选项
 * @returns Promise<string> - 上传成功后的文件key
 */
declare function uploadPDF(pdfBlob: Blob, options: PDFUploadOptions): Promise<string>;
/**
 * 生成PDF并下载
 * @param elementId - 要转换为PDF的DOM元素ID
 * @param options - PDF生成选项
 */
declare function generateAndDownloadPDF(elementId: string, options?: PDFOptions): Promise<void>;
/**
 * 生成PDF并上传到服务器
 * @param elementId - 要转换为PDF的DOM元素ID
 * @param uploadOptions - 上传选项
 * @param pdfOptions - PDF生成选项
 * @returns Promise<string> - 上传成功后的文件key
 */
declare function generateAndUploadPDF(elementId: string, uploadOptions: PDFUploadOptions, pdfOptions?: PDFOptions): Promise<string>;
/**
 * 生成PDF、下载并上传到服务器
 * @param elementId - 要转换为PDF的DOM元素ID
 * @param uploadOptions - 上传选项
 * @param pdfOptions - PDF生成选项
 * @returns Promise<string> - 上传成功后的文件key
 */
declare function generateDownloadAndUploadPDF(elementId: string, uploadOptions: PDFUploadOptions, pdfOptions?: PDFOptions): Promise<string>;

interface PrintAndSaveProps {
    applicationId: string;
    token: string;
    uploadUrl: string;
    elementId?: string;
    pdfOptions?: PDFOptions;
    onSuccess?: (fileKey: string) => void;
    onError?: (error: Error) => void;
    className?: string;
    children?: React__default.ReactNode;
    disabled?: boolean;
}
declare function PrintAndSave({ applicationId, token, uploadUrl, elementId, pdfOptions, onSuccess, onError, className, children, disabled, }: PrintAndSaveProps): react_jsx_runtime.JSX.Element;

interface UsePDFGenerationOptions {
    onSuccess?: (fileKey?: string) => void;
    onError?: (error: Error) => void;
}
declare function usePDFGeneration(options?: UsePDFGenerationOptions): {
    isProcessing: boolean;
    generatePDF: (elementId: string, pdfOptions?: PDFOptions) => Promise<Blob>;
    downloadPDF: (elementId: string, pdfOptions?: PDFOptions) => Promise<void>;
    uploadPDF: (elementId: string, uploadOptions: PDFUploadOptions, pdfOptions?: PDFOptions) => Promise<string>;
    downloadAndUploadPDF: (elementId: string, uploadOptions: PDFUploadOptions, pdfOptions?: PDFOptions) => Promise<string>;
};

interface ApplicationDetails {
    id: string;
    applicationStatus: "drafted" | "pending" | "needs_more_info" | "approved" | "rejected";
    createdAt: string;
    updatedAt: string;
    internalTags: string[];
    notes?: string;
}
interface ApprovalTimelineEntry$2 {
    id: string | number;
    type: 'application_submitted' | 'admin_action' | 'user_response';
    timestamp: string;
    adminAction?: 'review' | 'approve' | 'reject' | 'require_more_info' | null;
    note?: string | null;
    userResponse?: any | null;
    adminName?: string;
}
interface ApplicationStatusProps {
    application?: ApplicationDetails | null;
    fullApplication?: any;
    timelineData?: {
        timeline: ApprovalTimelineEntry$2[];
    };
    isLoading?: boolean;
    error?: any;
    timelineLoading?: boolean;
    isJustSubmitted?: boolean;
    onRefetchTimeline?: () => void;
    onDownloadPDF?: () => void;
    onNavigateToGuide?: () => void;
    onNavigateToBecomeGuide?: () => void;
    onFileUpload?: (file: File) => Promise<{
        fileId: string;
        publicUrl: string;
    }>;
    onSubmitSupplemental?: (data: any) => Promise<void>;
    onToast?: (options: {
        title: string;
        description?: string;
        variant?: string;
    }) => void;
    Card: any;
    CardContent: any;
    CardHeader: any;
    CardTitle: any;
    Button: any;
    Badge: any;
    Textarea: any;
    Input: any;
    Label: any;
    CheckCircle: any;
    Clock: any;
    AlertCircle: any;
    XCircle: any;
    Download: any;
    Upload: any;
    FileText: any;
    History: any;
}
declare function ApplicationStatus({ application, fullApplication, timelineData, isLoading, error, timelineLoading, isJustSubmitted, onRefetchTimeline, onDownloadPDF, onNavigateToGuide, onNavigateToBecomeGuide, onFileUpload, onSubmitSupplemental, onToast, Card, CardContent, CardHeader, CardTitle, Button, Badge, Textarea, Input, Label, CheckCircle, Clock, AlertCircle, XCircle, Download, Upload, FileText, History, }: ApplicationStatusProps): react_jsx_runtime.JSX.Element;

interface ApprovalTimelineEntry$1 {
    id: string | number;
    type: 'application_submitted' | 'admin_action' | 'user_response';
    timestamp: string;
    adminAction?: 'review' | 'approve' | 'reject' | 'require_more_info' | null;
    note?: string | null;
    userResponse?: any | null;
    adminName?: string;
}
interface ApprovalTimelineProps {
    timeline: ApprovalTimelineEntry$1[];
    CheckCircle: any;
    Clock: any;
    AlertCircle: any;
    XCircle: any;
    FileCheck: any;
    Upload: any;
}
declare function ApprovalTimeline({ timeline, CheckCircle, Clock, AlertCircle, XCircle, FileCheck, Upload }: ApprovalTimelineProps): react_jsx_runtime.JSX.Element;

interface SupplementalMaterialsUploadProps {
    applicationId: string;
    onSubmitSuccess?: () => void;
    Card: any;
    CardContent: any;
    CardHeader: any;
    CardTitle: any;
    Button: any;
    Textarea: any;
    Input: any;
    Label: any;
    Upload: any;
    FileText: any;
    X: any;
    CheckCircle: any;
    onFileUpload?: (file: File) => Promise<{
        fileId: string;
        publicUrl: string;
    }>;
    onSubmit?: (data: any) => Promise<void>;
    onToast?: (options: {
        title: string;
        description?: string;
        variant?: string;
    }) => void;
}
declare function SupplementalMaterialsUpload({ applicationId, onSubmitSuccess, Card, CardContent, CardHeader, CardTitle, Button, Textarea, Input, Label, Upload, FileText, X, CheckCircle, onFileUpload, onSubmit, onToast }: SupplementalMaterialsUploadProps): react_jsx_runtime.JSX.Element;

interface ApprovalTimelineEntry {
    id: string | number;
    type: 'application_submitted' | 'admin_action' | 'user_response';
    timestamp: string;
    adminAction?: 'review' | 'approve' | 'reject' | 'require_more_info' | null;
    note?: string | null;
    userResponse?: any | null;
    adminName?: string;
}
declare function useApprovalTimeline(applicationId: string | undefined): {
    data: undefined;
    isLoading: boolean;
    error: null;
    refetch: () => void;
};

declare function useApplicationStatus(): {
    data: undefined;
    isLoading: boolean;
    error: null;
    refetch: () => void;
};

interface MissingFieldMessageDescriptor {
    id: string;
    defaultMessage: string;
}
declare const getMissingFieldMessageDescriptor: (field: string) => MissingFieldMessageDescriptor;
declare const validateEvaluationQuestions: (formData: Partial<FormData>) => string[];
declare const validateFormCompleteness: (formData: Partial<FormData>) => string[];

type EvaluationFormValues = Pick<FormData, 'assessmentQ1' | 'assessmentQ1Slider' | 'assessmentQ3' | 'assessmentQ3Slider' | 'assessmentQ4' | 'assessmentQ4Slider' | 'personalizedQ6' | 'personalizedQ6Slider' | 'personalizedQ7' | 'personalizedQ8Strengths' | 'personalizedQ8Slider' | 'personalizedQ8Example' | 'personalizedQ9'>;
interface StoredEvaluationAnswersV2 extends EvaluationFormValues {
    version: 2;
}
interface StoredEvaluationFields {
    evaluationAnswersV2?: unknown;
    ethicsDescription?: unknown;
    supportiveDescription?: unknown;
    q1Interaction?: unknown;
    q2FavSpot?: unknown;
    q3BoundaryResponse?: unknown;
    q4EmotionalHandling?: unknown;
    q5SelfSymbol?: unknown;
}
declare const hasVersionTwoEvaluationAnswers: (data: StoredEvaluationFields) => boolean;
declare const evaluationFormValuesFromStorage: (data: StoredEvaluationFields) => EvaluationFormValues;
declare const evaluationStorageFieldsFromForm: (data: EvaluationFormValues) => {
    evaluationAnswersV2: {
        assessmentQ1: string[];
        assessmentQ1Slider?: number | null | undefined;
        assessmentQ3: string;
        assessmentQ3Slider?: number | null | undefined;
        assessmentQ4: string[];
        assessmentQ4Slider?: number | null | undefined;
        personalizedQ6: string[];
        personalizedQ6Slider?: number | null | undefined;
        personalizedQ7: string;
        personalizedQ8Strengths: string[];
        personalizedQ8Slider?: number | null | undefined;
        personalizedQ8Example: string;
        personalizedQ9: string;
        version: 2;
    };
};
type RetiredEvaluationFormValues = Pick<FormData, 'assessmentQ2' | 'personalizedQ5' | 'personalizedQ5Slider' | 'personalizedQ7Slider'>;
declare const prepareEvaluationPayload: <T extends EvaluationFormValues & Partial<RetiredEvaluationFormValues>>(data: T) => {
    evaluationAnswersV2: {
        assessmentQ1: string[];
        assessmentQ1Slider?: number | null | undefined;
        assessmentQ3: string;
        assessmentQ3Slider?: number | null | undefined;
        assessmentQ4: string[];
        assessmentQ4Slider?: number | null | undefined;
        personalizedQ6: string[];
        personalizedQ6Slider?: number | null | undefined;
        personalizedQ7: string;
        personalizedQ8Strengths: string[];
        personalizedQ8Slider?: number | null | undefined;
        personalizedQ8Example: string;
        personalizedQ9: string;
        version: 2;
    };
};

/**
 * 邮编格式化和校验工具函数
 * 日本邮编是 7 位数字，通常写成 XXX-XXXX 形式
 */
declare const POSTAL_CODE_REGEX: RegExp;
/**
 * 清理邮编字符串，只保留数字
 * @param value 用户输入的邮编字符串
 * @returns 清理后的纯数字字符串，最多 7 位
 */
declare const sanitizePostalCode: (value: string) => string;
/**
 * 格式化邮编为 XXX-XXXX 形式
 * @param value 邮编字符串（可能包含或不包含连字符）
 * @returns 格式化后的邮编字符串（XXX-XXXX）或原始输入（如果长度不足7位）
 */
declare const formatPostalCode: (value: string) => string;
/**
 * 校验邮编是否有效（7 位数字）
 * @param value 邮编字符串
 * @returns 是否有效
 */
declare const isValidPostalCode: (value: string) => boolean;

declare const ANONYMOUS_DRAFT_VERSION = 1;
declare const ANONYMOUS_DRAFT_STORAGE_KEY = "yaotu_guide_application_anonymous_draft_v1";
declare const LEGACY_GUIDE_FORM_DRAFT_KEY = "yaotu_guide_form_draft";
declare const LEGACY_QUALIFICATION_FILES_KEY = "yaotu_qualification_files";
type AnonymousDraftMigrationStatus = "local" | "migrating" | "migrated" | "conflict" | "superseded";
interface AnonymousGuideDraft {
    draftVersion: typeof ANONYMOUS_DRAFT_VERSION;
    clientDraftId: string;
    applicationSource?: string;
    formData: Partial<FormData>;
    lastCompletedStep: 0 | 1 | 2 | 3 | 4;
    authCheckpointReached: boolean;
    updatedAt: string;
    migrationStatus: AnonymousDraftMigrationStatus;
    migratedAt?: string;
    dbDraftId?: string | number;
    conflictReason?: string;
}
declare const createAnonymousDraft: (formData?: Partial<FormData>, options?: {
    clientDraftId?: string;
    applicationSource?: string;
    lastCompletedStep?: 0 | 1 | 2 | 3 | 4;
    authCheckpointReached?: boolean;
    migrationStatus?: AnonymousDraftMigrationStatus;
    updatedAt?: string;
}) => AnonymousGuideDraft;
declare const loadAnonymousDraft: () => AnonymousGuideDraft | null;
declare const saveAnonymousDraft: (draft: AnonymousGuideDraft) => AnonymousGuideDraft;
declare const loadOrCreateAnonymousDraft: (initialData?: Partial<FormData>) => AnonymousGuideDraft;
declare const upsertAnonymousDraft: (formData: Partial<FormData>, options?: {
    applicationSource?: string;
    lastCompletedStep?: 0 | 1 | 2 | 3 | 4;
    authCheckpointReached?: boolean;
    migrationStatus?: AnonymousDraftMigrationStatus;
}) => AnonymousGuideDraft;
declare const markAnonymousDraftMigrating: () => AnonymousGuideDraft | null;
declare const markAnonymousDraftMigrated: (dbDraftId?: string | number) => AnonymousGuideDraft | null;
declare const markAnonymousDraftConflict: (reason: string) => AnonymousGuideDraft | null;
declare const clearAnonymousDraft: () => void;

type GuideSignupIntentRequest = {
    anonymousDraftId: AnonymousGuideDraft["clientDraftId"];
    anonymousDraftVersion: AnonymousGuideDraft["draftVersion"];
};
/**
 * Signup intent is only a capability for a specific anonymous draft.
 * Application and UI state remain owned by that draft and are handed off separately.
 */
declare const serializeGuideSignupIntentRequest: (draft: Pick<AnonymousGuideDraft, "clientDraftId" | "draftVersion">) => GuideSignupIntentRequest;

interface StagedQualificationFile {
    fileId: string;
    clientDraftId: string;
    name: string;
    type: string;
    size: number;
    description: string;
    visible: boolean;
    createdAt: string;
    uploaded?: boolean;
    publicUrl?: string;
    serverFileId?: string;
    uploadedMetadata?: StagedQualificationUploadedMetadata;
}
interface StagedQualificationUploadedMetadata {
    fileId?: string;
    r2Key?: string;
    publicUrl?: string;
    originalName?: string;
    size?: number;
    mimetype?: string;
}
declare const stageQualificationFile: (file: File, description: string, options?: {
    clientDraftId?: string;
    visible?: boolean;
}) => Promise<StagedQualificationFile>;
declare const listStagedQualificationFiles: (clientDraftId: string) => Promise<StagedQualificationFile[]>;
declare const getStagedQualificationFile: (fileId: string) => Promise<(StagedQualificationFile & {
    blob: Blob;
}) | null>;
declare const removeStagedQualificationFile: (fileId: string) => Promise<void>;
declare const clearStagedQualificationFiles: (clientDraftId: string) => Promise<void>;
declare const markStagedQualificationFileUploaded: (fileId: string, data: StagedQualificationUploadedMetadata) => Promise<StagedQualificationFile | null>;
declare const indexedDbQualificationStorageAvailable: () => boolean;

declare const DEFAULT_RESUME_PATH = "/become-guide?resume=1";
declare const GUIDE_APPLICATION_IDENTITY_INTENT_STORAGE_KEY = "guideApplicationIdentityIntent";
declare const getResumePath: (config: GuideFormConfig) => string;
declare const getAuthRedirectUrl: (config: GuideFormConfig) => string;
declare const getVerificationRedirectUrl: (config: GuideFormConfig) => string;
declare const isAuthenticated: (config: GuideFormConfig) => boolean;
declare const isEmailVerified: (config: GuideFormConfig) => boolean;

declare const convertYuanToCents: (amount: number) => number;
declare const convertCentsToYuan: (cents: number) => number;
declare const formatCurrency: (amount: number, currency?: string) => string;
declare const processFormDataForDatabase: (formData: any) => any;
declare const processDatabaseDataForForm: (dbData: any) => any;

declare const MBTI_OPTIONS: string[];
declare const SEX_OPTIONS: {
    value: string;
    labelKey: string;
}[];
declare const PAGE_TITLES: {
    readonly 1: "becomeGuide.step1.step1PageTitle";
    readonly 2: "becomeGuide.step2.title";
    readonly 3: "becomeGuide.step3.title";
    readonly 4: "becomeGuide.step4.step4PageTitle";
};
declare const TOTAL_PAGES = 4;
declare const SCORE_MIN = 1;
declare const SCORE_MAX = 9;
declare const MIN_AGE = 18;
declare const MAX_AGE = 120;
declare const MIN_PEOPLE = 1;
declare const MAX_PEOPLE = 50;
declare const MIN_DURATION = 1;
declare const MAX_DURATION = 48;
declare const CURRENCY_OPTIONS: readonly [{
    readonly value: "USD";
    readonly label: "美元 (USD)";
}];
declare const SCORE_EXPLANATIONS: {
    ethics: {
        titleKey: string;
        descriptionKey: string;
        rangesKey: string;
    };
    boundary: {
        titleKey: string;
        descriptionKey: string;
        rangesKey: string;
    };
    supportive: {
        titleKey: string;
        descriptionKey: string;
        rangesKey: string;
    };
};

type ToastVariant = "default" | "destructive" | "success";
type ToastVariantProps = {
    variant?: ToastVariant;
};
declare const ToastProvider: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>>;
declare const ToastViewport: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>>;
declare const Toast$1: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & ToastVariantProps & {
    onOpenChange?: (open: boolean) => void;
} & React.RefAttributes<HTMLDivElement>>;
declare const ToastAction: React.ForwardRefExoticComponent<React.ButtonHTMLAttributes<HTMLButtonElement> & React.RefAttributes<HTMLButtonElement>>;
declare const ToastClose: React.ForwardRefExoticComponent<React.ButtonHTMLAttributes<HTMLButtonElement> & React.RefAttributes<HTMLButtonElement>>;
declare const ToastTitle: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>>;
declare const ToastDescription: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>>;

type ToastProps = React.ComponentPropsWithoutRef<"div"> & {
    variant?: "default" | "destructive" | "success";
    onOpenChange?: (open: boolean) => void;
};
type ToastActionElement = React.ReactElement<React.ButtonHTMLAttributes<HTMLButtonElement>>;
type ToasterToast = ToastProps & {
    id: string;
    title?: React.ReactNode;
    description?: React.ReactNode;
    action?: ToastActionElement;
    open?: boolean;
};
type Toast = Omit<ToasterToast, "id">;
declare function toast({ ...props }: Toast): {
    id: string;
    dismiss: () => void;
    update: (props: ToasterToast) => void;
};
declare function useToast(): {
    toast: typeof toast;
    dismiss: (toastId?: string) => void;
    toasts: ToasterToast[];
};

declare function Toaster(): react_jsx_runtime.JSX.Element;

export { ANONYMOUS_DRAFT_STORAGE_KEY, ANONYMOUS_DRAFT_VERSION, type AnonymousDraftMigrationStatus, type AnonymousGuideDraft, ApplicationPreview, type UIComponents as ApplicationPreviewUIComponents, ApplicationStatus, ApprovalTimeline, type ApprovalTimelineEntry, CURRENCY_OPTIONS, DEFAULT_RESUME_PATH, type EvaluationFormValues, type EvaluationQuestionUI, type EvaluationSliderUI, FOUNDER_NOTE_READ_STORAGE_KEY, type FormData, FounderNoteMail, GUIDE_APPLICATION_IDENTITY_INTENT_STORAGE_KEY, type GuideApplicationContinuationInput, type GuideApplicationContinuationIntent, type GuideDraftConflict, type GuideDraftConflictReason, GuideForm, type GuideFormConfig, type GuideFormDestination, type GuideFormLocale, type GuideFunnelState, type GuideResumeState, type GuideSignupIntentRequest, LEGACY_GUIDE_FORM_DRAFT_KEY, LEGACY_QUALIFICATION_FILES_KEY, MAX_AGE, MAX_DURATION, MAX_PEOPLE, MBTI_OPTIONS, MIN_AGE, MIN_DURATION, MIN_PEOPLE, type MissingFieldMessageDescriptor, PAGE_TITLES, type PDFOptions, type PDFUploadOptions, POSTAL_CODE_REGEX, PrintAndSave, type PrintAndSaveProps, SCORE_EXPLANATIONS, SCORE_MAX, SCORE_MIN, SEX_OPTIONS, type StagedQualificationFile, Step2SelfAssessment, type Step2SelfAssessmentProps, Step3PersonalizedQuestions, type Step3PersonalizedQuestionsProps, type StoredEvaluationAnswersV2, type StoredEvaluationFields, SupplementalMaterialsUpload, TOTAL_PAGES, Toast$1 as Toast, ToastAction, ToastClose, ToastDescription, ToastProvider, ToastTitle, ToastViewport, Toaster, type TranslationFunction, type UIComponents$1 as UIComponents, type UsePDFGenerationOptions, clearAnonymousDraft, clearStagedQualificationFiles, convertCentsToYuan, convertYuanToCents, createAnonymousDraft, createGuideFormTranslator, defaultPDFOptions, downloadPDF, evaluationFormValuesFromStorage, evaluationStorageFieldsFromForm, formSchema, formatCurrency, formatPostalCode, generateAndDownloadPDF, generateAndUploadPDF, generateDownloadAndUploadPDF, generatePDFBlob, getAuthRedirectUrl, getMissingFieldMessageDescriptor, getResumePath, getStagedQualificationFile, getVerificationRedirectUrl, guideFormChineseMessages, guideFormEnglishMessages, hasVersionTwoEvaluationAnswers, indexedDbQualificationStorageAvailable, isAuthenticated, isEditableGuideContinuation, isEmailVerified, isValidPostalCode, listStagedQualificationFiles, loadAnonymousDraft, loadOrCreateAnonymousDraft, markAnonymousDraftConflict, markAnonymousDraftMigrated, markAnonymousDraftMigrating, markStagedQualificationFileUploaded, prepareEvaluationPayload, processDatabaseDataForForm, processFormDataForDatabase, removeStagedQualificationFile, resolveGuideApplicationContinuation, sanitizePostalCode, saveAnonymousDraft, serializeGuideSignupIntentRequest, stageQualificationFile, toast, uploadPDF, upsertAnonymousDraft, useApplicationStatus, useApprovalTimeline, useGuideForm, usePDFGeneration, useToast, validateEvaluationQuestions, validateFormCompleteness };
