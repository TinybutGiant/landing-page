"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.ts
var index_exports = {};
__export(index_exports, {
  ANONYMOUS_DRAFT_STORAGE_KEY: () => ANONYMOUS_DRAFT_STORAGE_KEY,
  ANONYMOUS_DRAFT_VERSION: () => ANONYMOUS_DRAFT_VERSION,
  ApplicationPreview: () => ApplicationPreview,
  ApplicationStatus: () => ApplicationStatus,
  ApprovalTimeline: () => ApprovalTimeline,
  CURRENCY_OPTIONS: () => CURRENCY_OPTIONS,
  DEFAULT_RESUME_PATH: () => DEFAULT_RESUME_PATH,
  FOUNDER_NOTE_READ_STORAGE_KEY: () => FOUNDER_NOTE_READ_STORAGE_KEY,
  FounderNoteMail: () => FounderNoteMail,
  GUIDE_APPLICATION_IDENTITY_INTENT_STORAGE_KEY: () => GUIDE_APPLICATION_IDENTITY_INTENT_STORAGE_KEY,
  GuideForm: () => GuideForm,
  LEGACY_GUIDE_FORM_DRAFT_KEY: () => LEGACY_GUIDE_FORM_DRAFT_KEY,
  LEGACY_QUALIFICATION_FILES_KEY: () => LEGACY_QUALIFICATION_FILES_KEY,
  MAX_AGE: () => MAX_AGE,
  MAX_DURATION: () => MAX_DURATION,
  MAX_PEOPLE: () => MAX_PEOPLE,
  MBTI_OPTIONS: () => MBTI_OPTIONS,
  MIN_AGE: () => MIN_AGE,
  MIN_DURATION: () => MIN_DURATION,
  MIN_PEOPLE: () => MIN_PEOPLE,
  PAGE_TITLES: () => PAGE_TITLES,
  POSTAL_CODE_REGEX: () => POSTAL_CODE_REGEX,
  PrintAndSave: () => PrintAndSave,
  SCORE_EXPLANATIONS: () => SCORE_EXPLANATIONS,
  SCORE_MAX: () => SCORE_MAX,
  SCORE_MIN: () => SCORE_MIN,
  SEX_OPTIONS: () => SEX_OPTIONS,
  Step2SelfAssessment: () => Step2SelfAssessment,
  Step3PersonalizedQuestions: () => Step3PersonalizedQuestions,
  SupplementalMaterialsUpload: () => SupplementalMaterialsUpload,
  TOTAL_PAGES: () => TOTAL_PAGES,
  Toast: () => Toast,
  ToastAction: () => ToastAction,
  ToastClose: () => ToastClose,
  ToastDescription: () => ToastDescription,
  ToastProvider: () => ToastProvider,
  ToastTitle: () => ToastTitle,
  ToastViewport: () => ToastViewport,
  Toaster: () => Toaster,
  clearAnonymousDraft: () => clearAnonymousDraft,
  clearStagedQualificationFiles: () => clearStagedQualificationFiles,
  convertCentsToYuan: () => convertCentsToYuan,
  convertYuanToCents: () => convertYuanToCents,
  createAnonymousDraft: () => createAnonymousDraft,
  createGuideFormTranslator: () => createGuideFormTranslator,
  defaultPDFOptions: () => defaultPDFOptions,
  downloadPDF: () => downloadPDF,
  evaluationFormValuesFromStorage: () => evaluationFormValuesFromStorage,
  evaluationStorageFieldsFromForm: () => evaluationStorageFieldsFromForm,
  formSchema: () => formSchema,
  formatCurrency: () => formatCurrency,
  formatPostalCode: () => formatPostalCode,
  generateAndDownloadPDF: () => generateAndDownloadPDF,
  generateAndUploadPDF: () => generateAndUploadPDF,
  generateDownloadAndUploadPDF: () => generateDownloadAndUploadPDF,
  generatePDFBlob: () => generatePDFBlob,
  getAuthRedirectUrl: () => getAuthRedirectUrl,
  getMissingFieldMessageDescriptor: () => getMissingFieldMessageDescriptor,
  getResumePath: () => getResumePath,
  getStagedQualificationFile: () => getStagedQualificationFile,
  getVerificationRedirectUrl: () => getVerificationRedirectUrl,
  guideFormChineseMessages: () => guideFormChineseMessages,
  guideFormEnglishMessages: () => guideFormEnglishMessages,
  hasVersionTwoEvaluationAnswers: () => hasVersionTwoEvaluationAnswers,
  indexedDbQualificationStorageAvailable: () => indexedDbQualificationStorageAvailable,
  isAuthenticated: () => isAuthenticated,
  isEditableGuideContinuation: () => isEditableGuideContinuation,
  isEmailVerified: () => isEmailVerified,
  isValidPostalCode: () => isValidPostalCode,
  listStagedQualificationFiles: () => listStagedQualificationFiles,
  loadAnonymousDraft: () => loadAnonymousDraft,
  loadOrCreateAnonymousDraft: () => loadOrCreateAnonymousDraft,
  markAnonymousDraftConflict: () => markAnonymousDraftConflict,
  markAnonymousDraftMigrated: () => markAnonymousDraftMigrated,
  markAnonymousDraftMigrating: () => markAnonymousDraftMigrating,
  markStagedQualificationFileUploaded: () => markStagedQualificationFileUploaded,
  prepareEvaluationPayload: () => prepareEvaluationPayload,
  processDatabaseDataForForm: () => processDatabaseDataForForm,
  processFormDataForDatabase: () => processFormDataForDatabase,
  removeStagedQualificationFile: () => removeStagedQualificationFile,
  resolveGuideApplicationContinuation: () => resolveGuideApplicationContinuation,
  sanitizePostalCode: () => sanitizePostalCode,
  saveAnonymousDraft: () => saveAnonymousDraft,
  serializeGuideSignupIntentRequest: () => serializeGuideSignupIntentRequest,
  stageQualificationFile: () => stageQualificationFile,
  toast: () => toast,
  uploadPDF: () => uploadPDF,
  upsertAnonymousDraft: () => upsertAnonymousDraft,
  useApplicationStatus: () => useApplicationStatus,
  useApprovalTimeline: () => useApprovalTimeline,
  useGuideForm: () => useGuideForm,
  usePDFGeneration: () => usePDFGeneration,
  useToast: () => useToast,
  validateEvaluationQuestions: () => validateEvaluationQuestions,
  validateFormCompleteness: () => validateFormCompleteness
});
module.exports = __toCommonJS(index_exports);

// src/hooks/useGuideForm.ts
var import_react = require("react");
var import_react_hook_form = require("react-hook-form");
var import_zod2 = require("@hookform/resolvers/zod");

// src/types/schema.ts
var import_zod = require("zod");

// src/constants/index.ts
var MBTI_OPTIONS = [
  "ENFJ",
  "ENFP",
  "ENTJ",
  "ENTP",
  "ESFJ",
  "ESFP",
  "ESTJ",
  "ESTP",
  "INFJ",
  "INFP",
  "INTJ",
  "INTP",
  "ISFJ",
  "ISFP",
  "ISTJ",
  "ISTP"
];
var SEX_OPTIONS = [
  { value: "Male", labelKey: "becomeGuide.step1.genderOptions.male" },
  { value: "Female", labelKey: "becomeGuide.step1.genderOptions.female" },
  { value: "prefer_not_to_say", labelKey: "becomeGuide.step1.genderOptions.preferNotToSay" }
];
var PAGE_TITLES = {
  1: "becomeGuide.step1.step1PageTitle",
  2: "becomeGuide.step2.title",
  3: "becomeGuide.step3.title",
  4: "becomeGuide.step4.step4PageTitle"
};
var TOTAL_PAGES = 4;
var SCORE_MIN = 1;
var SCORE_MAX = 9;
var MIN_AGE = 18;
var MAX_AGE = 120;
var MIN_PEOPLE = 1;
var MAX_PEOPLE = 50;
var MIN_DURATION = 1;
var MAX_DURATION = 48;
var CURRENCY_OPTIONS = [
  { value: "USD", label: "\u7F8E\u5143 (USD)" }
];
var SCORE_EXPLANATIONS = {
  ethics: {
    titleKey: "becomeGuide.scoreExplanations.ethics.title",
    descriptionKey: "becomeGuide.scoreExplanations.ethics.description",
    rangesKey: "becomeGuide.scoreExplanations.ethics.ranges"
  },
  boundary: {
    titleKey: "becomeGuide.scoreExplanations.boundary.title",
    descriptionKey: "becomeGuide.scoreExplanations.boundary.description",
    rangesKey: "becomeGuide.scoreExplanations.boundary.ranges"
  },
  supportive: {
    titleKey: "becomeGuide.scoreExplanations.supportive.title",
    descriptionKey: "becomeGuide.scoreExplanations.supportive.description",
    rangesKey: "becomeGuide.scoreExplanations.supportive.ranges"
  }
};
var ASSESSMENT_Q1_OPTIONS = [
  "understandRequest",
  "refuseUnsafe",
  "offerAlternative",
  "contactPlatform",
  "satisfyFirst",
  "doNotEngage"
];
var ASSESSMENT_Q3_OPTIONS = [
  "askAndSupport",
  "observeThenCheck",
  "activelyHelp",
  "waitForRequest",
  "doNotIntervene"
];
var ASSESSMENT_Q4_OPTIONS = [
  "shareStories",
  "localConnections",
  "takePhotos",
  "adjustPace",
  "quietCompany",
  "giveSpace",
  "stayInTouch",
  "professionalRelationship"
];
var PERSONALIZED_Q6_OPTIONS = [
  "stateBoundary",
  "adjustInteraction",
  "contactPlatform",
  "stopService",
  "endureSilently",
  "argue"
];
var PERSONALIZED_Q7_OPTIONS = [
  "notifyGuestAndYaotu",
  "arrangeDirectly",
  "waitAndSee",
  "substituteWithoutPlatform",
  "cancelIfAsked"
];
var PERSONALIZED_Q8_OPTIONS = [
  "hiddenSpots",
  "conversation",
  "planning",
  "adaptability",
  "photography",
  "food",
  "shopping",
  "transportation",
  "firstTimeVisitors",
  "observeNeeds",
  "respectPace",
  "multilingual",
  "unexpectedSituations"
];

// src/types/schema.ts
var normalizeSexInput = (sex) => sex === "Prefer not to say" || sex === "preferNotToSay" ? "prefer_not_to_say" : sex;
var certificationSchema = import_zod.z.object({
  description: import_zod.z.string().optional(),
  proof: import_zod.z.string().optional(),
  visible: import_zod.z.boolean().default(true).optional(),
  uploaded: import_zod.z.boolean().optional(),
  publicUrl: import_zod.z.string().optional(),
  data: import_zod.z.string().optional(),
  name: import_zod.z.string().optional(),
  type: import_zod.z.string().optional(),
  size: import_zod.z.number().optional(),
  fileId: import_zod.z.string().optional(),
  stagedFileId: import_zod.z.string().optional()
}).passthrough();
var serviceAreaSchema = import_zod.z.object({
  id: import_zod.z.coerce.number().int().positive().optional(),
  destinationId: import_zod.z.coerce.number().int().positive().optional(),
  slug: import_zod.z.string().optional(),
  countryCode: import_zod.z.string().optional(),
  nameEn: import_zod.z.string().optional(),
  nameJa: import_zod.z.string().optional(),
  nameZhCn: import_zod.z.string().optional(),
  timezone: import_zod.z.string().optional(),
  prefectureName: import_zod.z.string().nullable().optional(),
  placeType: import_zod.z.string().optional()
}).passthrough();
var serviceAreaProposalSchema = import_zod.z.object({
  id: import_zod.z.union([import_zod.z.string(), import_zod.z.number()]).optional(),
  rawName: import_zod.z.string().optional(),
  normalizedName: import_zod.z.string().optional(),
  status: import_zod.z.string().optional(),
  resolvedDestinationId: import_zod.z.coerce.number().int().positive().nullable().optional()
}).passthrough();
var formSchema = import_zod.z.object({
  id: import_zod.z.union([import_zod.z.string(), import_zod.z.number()]).optional(),
  userId: import_zod.z.number().optional(),
  applicationStatus: import_zod.z.enum(["drafted", "pending", "under_review", "approved", "rejected", "needs_more_info"]).optional(),
  name: import_zod.z.string().min(1, "Please enter your name"),
  age: import_zod.z.number().min(MIN_AGE, `Age must be at least ${MIN_AGE}`).max(MAX_AGE, `Age must not exceed ${MAX_AGE}`),
  sex: import_zod.z.preprocess(normalizeSexInput, import_zod.z.enum(["Male", "Female", "prefer_not_to_say"])),
  mbti: import_zod.z.enum(MBTI_OPTIONS).optional(),
  socialProfile: import_zod.z.string().optional(),
  assessmentQ1: import_zod.z.array(import_zod.z.string()).default([]),
  assessmentQ1Slider: import_zod.z.number().min(SCORE_MIN).max(SCORE_MAX).nullable().optional(),
  assessmentQ2: import_zod.z.string().default(""),
  assessmentQ3: import_zod.z.string().default(""),
  assessmentQ3Slider: import_zod.z.number().min(SCORE_MIN).max(SCORE_MAX).nullable().optional(),
  assessmentQ4: import_zod.z.array(import_zod.z.string()).default([]),
  assessmentQ4Slider: import_zod.z.number().min(SCORE_MIN).max(SCORE_MAX).nullable().optional(),
  serviceAreaDestinationIds: import_zod.z.array(import_zod.z.coerce.number().int().positive()).default([]),
  customServiceAreaProposals: import_zod.z.array(import_zod.z.string().trim().min(1).max(120)).default([]),
  serviceAreas: import_zod.z.array(serviceAreaSchema).optional(),
  serviceAreaProposals: import_zod.z.array(serviceAreaProposalSchema).optional(),
  residenceInfo: import_zod.z.string().optional(),
  residenceZipcode: import_zod.z.string().regex(/^\d{7}$/, "Postal code must be 7 digits").optional().or(import_zod.z.literal("")),
  residenceStartDate: import_zod.z.string().optional(),
  occupation: import_zod.z.string().optional(),
  bio: import_zod.z.string().optional(),
  qualifications: import_zod.z.object({
    certifications: import_zod.z.record(import_zod.z.string(), certificationSchema).optional()
  }).optional(),
  languages: import_zod.z.array(import_zod.z.string()).optional(),
  experienceDuration: import_zod.z.string().optional(),
  experienceSession: import_zod.z.string().optional(),
  personalizedQ5: import_zod.z.array(import_zod.z.string()).default([]),
  personalizedQ5Slider: import_zod.z.number().min(SCORE_MIN).max(SCORE_MAX).nullable().optional(),
  personalizedQ6: import_zod.z.array(import_zod.z.string()).default([]),
  personalizedQ6Slider: import_zod.z.number().min(SCORE_MIN).max(SCORE_MAX).nullable().optional(),
  personalizedQ7: import_zod.z.string().default(""),
  personalizedQ7Slider: import_zod.z.number().min(SCORE_MIN).max(SCORE_MAX).nullable().optional(),
  personalizedQ8Strengths: import_zod.z.array(import_zod.z.string()).max(3).default([]),
  personalizedQ8Slider: import_zod.z.number().min(SCORE_MIN).max(SCORE_MAX).nullable().optional(),
  personalizedQ8Example: import_zod.z.string().max(100).default(""),
  personalizedQ9: import_zod.z.string().max(600).default(""),
  serviceSelections: import_zod.z.array(import_zod.z.coerce.number().int()).default([]),
  targetGroup: import_zod.z.array(
    import_zod.z.enum(["individual", "couple", "family", "group", "child", "elderly", "business"])
  ).default([]),
  minPeople: import_zod.z.coerce.number().int().min(MIN_PEOPLE, `Minimum group size must be at least ${MIN_PEOPLE}`).max(MAX_PEOPLE, `Minimum group size must not exceed ${MAX_PEOPLE}`).optional(),
  maxPeople: import_zod.z.coerce.number().int().min(MIN_PEOPLE, `Maximum group size must be at least ${MIN_PEOPLE}`).max(MAX_PEOPLE, `Maximum group size must not exceed ${MAX_PEOPLE}`).optional(),
  minDuration: import_zod.z.coerce.number().int().min(MIN_DURATION, `Minimum duration must be at least ${MIN_DURATION} hours`).max(24, "Minimum duration must not exceed 24 hours").optional(),
  maxDuration: import_zod.z.coerce.number().int().min(MIN_DURATION, `Maximum duration must be at least ${MIN_DURATION} hours`).max(24, "Maximum duration must not exceed 24 hours").optional(),
  basicPricePerHour: import_zod.z.coerce.number().min(0, "Base hourly rate cannot be negative").optional(),
  additionalPricePerPerson: import_zod.z.coerce.number().min(0, "Additional per-person hourly rate cannot be negative").optional(),
  basicPricePerHourCents: import_zod.z.coerce.number().int().min(0, "Base hourly rate cannot be negative").optional(),
  additionalPricePerPersonCents: import_zod.z.coerce.number().int().min(0, "Additional per-person hourly rate cannot be negative").optional(),
  currency: import_zod.z.literal("USD").default("USD"),
  draftMetadata: import_zod.z.object({
    clientDraftId: import_zod.z.string().optional(),
    handedOffAt: import_zod.z.string().optional(),
    anonymousDraftVersion: import_zod.z.number().optional()
  }).optional()
}).refine((data) => !data.maxPeople || !data.minPeople || data.maxPeople >= data.minPeople, {
  message: "Maximum group size must be greater than or equal to minimum group size",
  path: ["maxPeople"]
}).refine(
  (data) => !data.maxDuration || !data.minDuration || data.maxDuration >= data.minDuration,
  {
    message: "Maximum duration must be greater than or equal to minimum duration",
    path: ["maxDuration"]
  }
);

// src/utils/validation.ts
var MISSING_FIELD_MESSAGE_DESCRIPTORS = {
  "becomeGuide.preview.name": {
    id: "becomeGuide.preview.name",
    defaultMessage: "Name"
  },
  "becomeGuide.preview.age": {
    id: "becomeGuide.preview.age",
    defaultMessage: "Age"
  },
  "becomeGuide.preview.gender": {
    id: "becomeGuide.preview.gender",
    defaultMessage: "Gender"
  },
  "becomeGuide.preview.mbti": {
    id: "becomeGuide.preview.mbti",
    defaultMessage: "MBTI"
  },
  "becomeGuide.preview.serviceAreas": {
    id: "becomeGuide.preview.missingFieldLabels.serviceAreas",
    defaultMessage: "Service areas"
  },
  "becomeGuide.preview.residenceStartDate": {
    id: "becomeGuide.preview.residenceStartDate",
    defaultMessage: "Residence in Japan since"
  },
  "becomeGuide.preview.residenceInfo": {
    id: "becomeGuide.preview.residenceInfo",
    defaultMessage: "Address / area"
  },
  "becomeGuide.preview.residenceZipcode": {
    id: "becomeGuide.preview.residenceZipcode",
    defaultMessage: "Postal code"
  },
  "becomeGuide.preview.occupation": {
    id: "becomeGuide.preview.occupation",
    defaultMessage: "Occupation"
  },
  "becomeGuide.preview.languages": {
    id: "becomeGuide.preview.languages",
    defaultMessage: "Languages"
  },
  "becomeGuide.preview.guideExperience": {
    id: "becomeGuide.preview.guideExperience",
    defaultMessage: "Guide experience"
  },
  "becomeGuide.preview.guideSessions": {
    id: "becomeGuide.preview.guideSessions",
    defaultMessage: "Guide sessions"
  },
  "becomeGuide.step2.q1Question": {
    id: "becomeGuide.preview.missingFieldLabels.step2Q1Answer",
    defaultMessage: "Step 2 Q1 answer"
  },
  "becomeGuide.step2.q1SliderTitle": {
    id: "becomeGuide.preview.missingFieldLabels.step2Q1Score",
    defaultMessage: "Step 2 Q1 score"
  },
  "becomeGuide.step2.q3Question": {
    id: "becomeGuide.preview.missingFieldLabels.step2Q3Answer",
    defaultMessage: "Step 2 Q2 answer"
  },
  "becomeGuide.step2.q3SliderTitle": {
    id: "becomeGuide.preview.missingFieldLabels.step2Q3Score",
    defaultMessage: "Step 2 Q2 score"
  },
  "becomeGuide.step2.q4Question": {
    id: "becomeGuide.preview.missingFieldLabels.step2Q4Answer",
    defaultMessage: "Step 2 Q3 answer"
  },
  "becomeGuide.step2.q4SliderTitle": {
    id: "becomeGuide.preview.missingFieldLabels.step2Q4Score",
    defaultMessage: "Step 2 Q3 score"
  },
  "becomeGuide.step3.q6Question": {
    id: "becomeGuide.preview.missingFieldLabels.step3Q6Answer",
    defaultMessage: "Step 3 Q4 answer"
  },
  "becomeGuide.step3.q6SliderTitle": {
    id: "becomeGuide.preview.missingFieldLabels.step3Q6Score",
    defaultMessage: "Step 3 Q4 score"
  },
  "becomeGuide.step3.q7Question": {
    id: "becomeGuide.preview.missingFieldLabels.step3Q7Answer",
    defaultMessage: "Step 3 Q5 answer"
  },
  "becomeGuide.step3.q8Question": {
    id: "becomeGuide.preview.missingFieldLabels.step3Q8Strengths",
    defaultMessage: "Step 3 Q6 strengths"
  },
  "becomeGuide.step3.q8SliderTitle": {
    id: "becomeGuide.preview.missingFieldLabels.step3Q8Score",
    defaultMessage: "Step 3 Q6 score"
  },
  "becomeGuide.step3.q8ExampleQuestion": {
    id: "becomeGuide.preview.missingFieldLabels.step3Q8Example",
    defaultMessage: "Step 3 Q6 example"
  },
  "becomeGuide.step3.q9Question": {
    id: "becomeGuide.preview.missingFieldLabels.step3Q9Description",
    defaultMessage: "Step 3 Q7 motivation"
  },
  "becomeGuide.preview.serviceItems": {
    id: "becomeGuide.preview.serviceItems",
    defaultMessage: "Services provided"
  },
  "becomeGuide.preview.targetGroup": {
    id: "becomeGuide.preview.targetGroup",
    defaultMessage: "Target group"
  },
  "becomeGuide.preview.serviceRange": {
    id: "becomeGuide.preview.serviceRange",
    defaultMessage: "Service group size range"
  },
  "becomeGuide.preview.serviceDuration": {
    id: "becomeGuide.preview.serviceDuration",
    defaultMessage: "Service duration range"
  },
  "becomeGuide.preview.basicPrice": {
    id: "becomeGuide.preview.basicPrice",
    defaultMessage: "Basic hourly rate"
  },
  "becomeGuide.preview.additionalPrice": {
    id: "becomeGuide.preview.additionalPrice",
    defaultMessage: "Additional price per person"
  }
};
var UNKNOWN_MISSING_FIELD_MESSAGE = {
  id: "becomeGuide.preview.missingFieldLabels.requiredInformation",
  defaultMessage: "Required information"
};
var getMissingFieldMessageDescriptor = (field) => MISSING_FIELD_MESSAGE_DESCRIPTORS[field] ?? UNKNOWN_MISSING_FIELD_MESSAGE;
var validateEvaluationQuestions = (formData) => {
  const missingFields = [];
  if (!formData.assessmentQ1?.length) missingFields.push("becomeGuide.step2.q1Question");
  if (formData.assessmentQ1Slider == null)
    missingFields.push("becomeGuide.step2.q1SliderTitle");
  if (!formData.assessmentQ3) missingFields.push("becomeGuide.step2.q3Question");
  if (formData.assessmentQ3Slider == null)
    missingFields.push("becomeGuide.step2.q3SliderTitle");
  if (!formData.assessmentQ4?.length) missingFields.push("becomeGuide.step2.q4Question");
  if (formData.assessmentQ4Slider == null)
    missingFields.push("becomeGuide.step2.q4SliderTitle");
  if (!formData.personalizedQ6?.length) missingFields.push("becomeGuide.step3.q6Question");
  if (formData.personalizedQ6Slider == null)
    missingFields.push("becomeGuide.step3.q6SliderTitle");
  if (!formData.personalizedQ7) missingFields.push("becomeGuide.step3.q7Question");
  if (!formData.personalizedQ8Strengths?.length)
    missingFields.push("becomeGuide.step3.q8Question");
  if (formData.personalizedQ8Slider == null)
    missingFields.push("becomeGuide.step3.q8SliderTitle");
  if (!formData.personalizedQ8Example?.trim())
    missingFields.push("becomeGuide.step3.q8ExampleQuestion");
  if (!formData.personalizedQ9?.trim()) missingFields.push("becomeGuide.step3.q9Question");
  return missingFields;
};
var validateIdentityCheckpointCompleteness = (formData) => {
  const missingFields = [];
  if (!formData.name?.trim()) missingFields.push("becomeGuide.preview.name");
  if (!formData.age || formData.age < 18 || formData.age > 120)
    missingFields.push("becomeGuide.preview.age");
  if (!formData.sex) missingFields.push("becomeGuide.preview.gender");
  if (!formData.mbti) missingFields.push("becomeGuide.preview.mbti");
  if (!formData.serviceAreaDestinationIds?.length && !formData.customServiceAreaProposals?.length && !formData.serviceAreas?.length) {
    missingFields.push("becomeGuide.preview.serviceAreas");
  }
  if (!formData.residenceStartDate)
    missingFields.push("becomeGuide.preview.residenceStartDate");
  if (!formData.residenceInfo?.trim()) missingFields.push("becomeGuide.preview.residenceInfo");
  if (!/^\d{7}$/.test(formData.residenceZipcode ?? ""))
    missingFields.push("becomeGuide.preview.residenceZipcode");
  if (!formData.occupation?.trim()) missingFields.push("becomeGuide.preview.occupation");
  if (!formData.languages?.length) missingFields.push("becomeGuide.preview.languages");
  if (!formData.experienceDuration) missingFields.push("becomeGuide.preview.guideExperience");
  if (!formData.experienceSession) missingFields.push("becomeGuide.preview.guideSessions");
  missingFields.push(...validateEvaluationQuestions(formData));
  return Array.from(new Set(missingFields));
};
var validateFormCompleteness = (formData) => {
  const missingFields = validateIdentityCheckpointCompleteness(formData);
  if (!formData.serviceSelections?.length) missingFields.push("becomeGuide.preview.serviceItems");
  if (!formData.targetGroup?.length) missingFields.push("becomeGuide.preview.targetGroup");
  if (!formData.minPeople || !formData.maxPeople) missingFields.push("becomeGuide.preview.serviceRange");
  if (!formData.minDuration || !formData.maxDuration)
    missingFields.push("becomeGuide.preview.serviceDuration");
  if (formData.basicPricePerHour === void 0 || formData.basicPricePerHour === null || formData.basicPricePerHour < 0) {
    missingFields.push("becomeGuide.preview.basicPrice");
  }
  if (formData.additionalPricePerPerson === void 0 || formData.additionalPricePerPerson === null || formData.additionalPricePerPerson < 0) {
    missingFields.push("becomeGuide.preview.additionalPrice");
  }
  return Array.from(new Set(missingFields));
};

// src/utils/evaluationPayload.ts
var parseSlider = (value) => typeof value === "number" && value >= 1 && value <= 9 ? value : void 0;
var parseBoundedText = (value, maximumLength) => typeof value === "string" && value.trim() !== "" && value.length <= maximumLength ? value : "";
var q1AnswerKeys = new Set(ASSESSMENT_Q1_OPTIONS);
var q3AnswerKeys = new Set(ASSESSMENT_Q3_OPTIONS);
var q4AnswerKeys = new Set(ASSESSMENT_Q4_OPTIONS);
var q6AnswerKeys = new Set(PERSONALIZED_Q6_OPTIONS);
var q7AnswerKeys = new Set(PERSONALIZED_Q7_OPTIONS);
var q8AnswerKeys = new Set(PERSONALIZED_Q8_OPTIONS);
var parseAllowedStringArray = (value, allowedAnswers, maximumLength, allowJsonString = false) => {
  let parsed = value;
  if (typeof value === "string") {
    if (!allowJsonString) return [];
    try {
      parsed = JSON.parse(value);
    } catch {
      return [];
    }
  }
  if (!Array.isArray(parsed) || parsed.length === 0) return [];
  if (maximumLength !== void 0 && parsed.length > maximumLength) return [];
  if (parsed.some(
    (answer) => typeof answer !== "string" || answer.trim() === "" || !allowedAnswers.has(answer)
  )) {
    return [];
  }
  if (new Set(parsed).size !== parsed.length) return [];
  return parsed;
};
var emptyEvaluationFormValues = () => ({
  assessmentQ1: [],
  assessmentQ1Slider: void 0,
  assessmentQ3: "",
  assessmentQ3Slider: void 0,
  assessmentQ4: [],
  assessmentQ4Slider: void 0,
  personalizedQ6: [],
  personalizedQ6Slider: void 0,
  personalizedQ7: "",
  personalizedQ8Strengths: [],
  personalizedQ8Slider: void 0,
  personalizedQ8Example: "",
  personalizedQ9: ""
});
var parseStoredQuestionEightAndNine = (value) => {
  if (typeof value !== "string" || value.trim() === "") {
    return { version: 2, strengths: [], example: "", guestDescription: "" };
  }
  try {
    const parsed = JSON.parse(value);
    return {
      version: parsed.version === 1 ? 1 : 2,
      strengths: parseAllowedStringArray(parsed.strengths, q8AnswerKeys, 3, true),
      strengthSlider: parseSlider(parsed.strengthSlider),
      example: parseBoundedText(parsed.example, 100),
      guestDescription: parseBoundedText(parsed.guestDescription, 600)
    };
  } catch {
    return { version: 2, strengths: [], example: "", guestDescription: "" };
  }
};
var parseMultiChoiceAnswer = (value, allowedAnswers) => {
  if (typeof value === "string") {
    try {
      const parsed = JSON.parse(value);
      if (Array.isArray(parsed)) {
        return {
          answers: parseAllowedStringArray(parsed, allowedAnswers, void 0, true),
          slider: void 0
        };
      }
      if (!parsed || typeof parsed !== "object") {
        return { answers: [], slider: void 0 };
      }
      return {
        answers: parseAllowedStringArray(parsed.answers, allowedAnswers, void 0, true),
        slider: parseSlider(parsed.slider)
      };
    } catch {
      return { answers: [], slider: void 0 };
    }
  }
  return {
    answers: parseAllowedStringArray(value, allowedAnswers, void 0, true),
    slider: void 0
  };
};
var parseSingleChoiceAnswer = (value, allowedAnswers) => {
  if (typeof value !== "string" || value.trim() === "") {
    return { answer: "", slider: void 0 };
  }
  try {
    const parsed = JSON.parse(value);
    if (!parsed || typeof parsed !== "object") {
      return { answer: "", slider: void 0 };
    }
    const answer = typeof parsed.answer === "string" ? parsed.answer : "";
    return {
      answer: allowedAnswers.has(answer) ? answer : "",
      slider: parseSlider(parsed.slider)
    };
  } catch {
    return { answer: allowedAnswers.has(value) ? value : "", slider: void 0 };
  }
};
var parseVersionTwoAnswers = (value) => {
  let parsed = value;
  if (typeof value === "string") {
    try {
      parsed = JSON.parse(value);
    } catch {
      return null;
    }
  }
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return null;
  const answers = parsed;
  if (answers.version !== 2) return null;
  return {
    assessmentQ1: parseAllowedStringArray(answers.assessmentQ1, q1AnswerKeys),
    assessmentQ1Slider: parseSlider(answers.assessmentQ1Slider),
    assessmentQ3: typeof answers.assessmentQ3 === "string" && q3AnswerKeys.has(answers.assessmentQ3) ? answers.assessmentQ3 : "",
    assessmentQ3Slider: parseSlider(answers.assessmentQ3Slider),
    assessmentQ4: parseAllowedStringArray(answers.assessmentQ4, q4AnswerKeys),
    assessmentQ4Slider: parseSlider(answers.assessmentQ4Slider),
    personalizedQ6: parseAllowedStringArray(answers.personalizedQ6, q6AnswerKeys),
    personalizedQ6Slider: parseSlider(answers.personalizedQ6Slider),
    personalizedQ7: typeof answers.personalizedQ7 === "string" && q7AnswerKeys.has(answers.personalizedQ7) ? answers.personalizedQ7 : "",
    personalizedQ8Strengths: parseAllowedStringArray(
      answers.personalizedQ8Strengths,
      q8AnswerKeys,
      3
    ),
    personalizedQ8Slider: parseSlider(answers.personalizedQ8Slider),
    personalizedQ8Example: parseBoundedText(answers.personalizedQ8Example, 100),
    personalizedQ9: parseBoundedText(answers.personalizedQ9, 600)
  };
};
var isVersionTwoStoredObject = (value) => {
  if (typeof value !== "string" || value.trim() === "") return false;
  try {
    const parsed = JSON.parse(value);
    return !!parsed && typeof parsed === "object" && !Array.isArray(parsed) && parsed.version === 2;
  } catch {
    return false;
  }
};
var hasVersionTwoEvaluationAnswers = (data) => {
  if (data.evaluationAnswersV2 !== void 0 && data.evaluationAnswersV2 !== null) {
    return parseVersionTwoAnswers(data.evaluationAnswersV2) !== null;
  }
  return [
    data.ethicsDescription,
    data.supportiveDescription,
    data.q1Interaction,
    data.q2FavSpot,
    data.q3BoundaryResponse,
    data.q4EmotionalHandling,
    data.q5SelfSymbol
  ].some(isVersionTwoStoredObject);
};
var evaluationFormValuesFromStorage = (data) => {
  const versionTwoAnswers = parseVersionTwoAnswers(data.evaluationAnswersV2);
  if (versionTwoAnswers) return versionTwoAnswers;
  if (data.evaluationAnswersV2 !== void 0 && data.evaluationAnswersV2 !== null) {
    return emptyEvaluationFormValues();
  }
  const finalAnswers = parseStoredQuestionEightAndNine(data.q5SelfSymbol);
  const q1 = parseMultiChoiceAnswer(data.ethicsDescription, q1AnswerKeys);
  const q3 = parseSingleChoiceAnswer(data.supportiveDescription, q3AnswerKeys);
  const q4 = parseMultiChoiceAnswer(data.q1Interaction, q4AnswerKeys);
  const q6 = parseMultiChoiceAnswer(data.q3BoundaryResponse, q6AnswerKeys);
  return {
    assessmentQ1: q1.answers,
    assessmentQ1Slider: q1.slider,
    assessmentQ3: q3.answer,
    assessmentQ3Slider: q3.slider,
    assessmentQ4: q4.answers,
    assessmentQ4Slider: q4.slider,
    personalizedQ6: q6.answers,
    personalizedQ6Slider: q6.slider,
    personalizedQ7: "",
    personalizedQ8Strengths: finalAnswers.strengths,
    personalizedQ8Slider: parseSlider(finalAnswers.strengthSlider),
    personalizedQ8Example: finalAnswers.example,
    personalizedQ9: finalAnswers.guestDescription
  };
};
var evaluationStorageFieldsFromForm = (data) => ({
  evaluationAnswersV2: {
    version: 2,
    ...data
  }
});
var prepareEvaluationPayload = (data) => {
  const {
    assessmentQ1,
    assessmentQ1Slider,
    assessmentQ2: _assessmentQ2,
    assessmentQ3,
    assessmentQ3Slider,
    assessmentQ4,
    assessmentQ4Slider,
    personalizedQ5: _personalizedQ5,
    personalizedQ5Slider: _personalizedQ5Slider,
    personalizedQ6,
    personalizedQ6Slider,
    personalizedQ7,
    personalizedQ7Slider: _personalizedQ7Slider,
    personalizedQ8Strengths,
    personalizedQ8Slider,
    personalizedQ8Example,
    personalizedQ9,
    ...rest
  } = data;
  void _assessmentQ2;
  void _personalizedQ5;
  void _personalizedQ5Slider;
  void _personalizedQ7Slider;
  return {
    ...rest,
    ...evaluationStorageFieldsFromForm({
      assessmentQ1,
      assessmentQ1Slider,
      assessmentQ3,
      assessmentQ3Slider,
      assessmentQ4,
      assessmentQ4Slider,
      personalizedQ6,
      personalizedQ6Slider,
      personalizedQ7,
      personalizedQ8Strengths,
      personalizedQ8Slider,
      personalizedQ8Example,
      personalizedQ9
    })
  };
};

// src/utils/currencyUtils.ts
var evaluationFormKeys = [
  "assessmentQ1",
  "assessmentQ1Slider",
  "assessmentQ3",
  "assessmentQ3Slider",
  "assessmentQ4",
  "assessmentQ4Slider",
  "personalizedQ6",
  "personalizedQ6Slider",
  "personalizedQ7",
  "personalizedQ8Strengths",
  "personalizedQ8Slider",
  "personalizedQ8Example",
  "personalizedQ9"
];
var convertYuanToCents = (amount) => Math.round(amount * 100);
var convertCentsToYuan = (cents) => cents / 100;
var formatCurrency = (amount, currency = "USD") => {
  const currencySymbols = {
    CNY: "CNY ",
    JPY: "JPY ",
    USD: "$",
    EUR: "EUR ",
    GBP: "GBP ",
    KRW: "KRW ",
    THB: "THB ",
    SGD: "S$",
    HKD: "HK$",
    TWD: "NT$",
    AUD: "A$",
    CAD: "C$",
    NZD: "NZ$"
  };
  const symbol = currencySymbols[currency] || currency;
  return `${symbol}${amount.toFixed(2)}`;
};
var processFormDataForDatabase = (formData) => ({
  ...formData,
  currency: "USD",
  basicPricePerHourCents: formData.basicPricePerHour !== void 0 ? convertYuanToCents(formData.basicPricePerHour) : void 0,
  additionalPricePerPersonCents: formData.additionalPricePerPerson !== void 0 ? convertYuanToCents(formData.additionalPricePerPerson) : void 0
});
var processDatabaseDataForForm = (dbData) => {
  const evaluationValues = hasVersionTwoEvaluationAnswers(dbData) ? evaluationFormValuesFromStorage(dbData) : {};
  const explicitEvaluationValues = Object.fromEntries(
    evaluationFormKeys.filter((key) => Object.prototype.hasOwnProperty.call(dbData, key)).map((key) => [key, dbData[key]])
  );
  const { evaluationAnswersV2: _evaluationAnswersV2, ...formData } = dbData;
  void _evaluationAnswersV2;
  return {
    ...formData,
    ...evaluationValues,
    // A newer browser edit wins when an idempotent response contains both shapes.
    ...explicitEvaluationValues,
    currency: "USD",
    basicPricePerHour: dbData.basicPricePerHourCents !== void 0 && dbData.basicPricePerHourCents !== null ? convertCentsToYuan(dbData.basicPricePerHourCents) : dbData.basicPricePerHour,
    additionalPricePerPerson: dbData.additionalPricePerPersonCents !== void 0 && dbData.additionalPricePerPersonCents !== null ? convertCentsToYuan(dbData.additionalPricePerPersonCents) : dbData.additionalPricePerPerson
  };
};

// src/storage/anonymousDraftStorage.ts
var ANONYMOUS_DRAFT_VERSION = 1;
var ANONYMOUS_DRAFT_STORAGE_KEY = "yaotu_guide_application_anonymous_draft_v1";
var LEGACY_GUIDE_FORM_DRAFT_KEY = "yaotu_guide_form_draft";
var LEGACY_QUALIFICATION_FILES_KEY = "yaotu_qualification_files";
var canUseLocalStorage = () => typeof window !== "undefined" && typeof window.localStorage !== "undefined";
var nowIso = () => (/* @__PURE__ */ new Date()).toISOString();
var makeClientDraftId = () => {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }
  return `draft_${Date.now()}_${Math.random().toString(36).slice(2)}`;
};
var parseJson = (raw) => {
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
};
var isObject = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
var normalizeStep = (value) => {
  const numeric = typeof value === "number" ? value : Number(value);
  if (numeric >= 4) return 4;
  if (numeric >= 3) return 3;
  if (numeric >= 2) return 2;
  if (numeric >= 1) return 1;
  return 0;
};
var createAnonymousDraft = (formData = {}, options = {}) => ({
  draftVersion: ANONYMOUS_DRAFT_VERSION,
  clientDraftId: options.clientDraftId ?? makeClientDraftId(),
  applicationSource: options.applicationSource,
  formData,
  lastCompletedStep: options.lastCompletedStep ?? 0,
  authCheckpointReached: options.authCheckpointReached ?? false,
  updatedAt: options.updatedAt ?? nowIso(),
  migrationStatus: options.migrationStatus ?? "local"
});
var normalizeDraft = (raw) => {
  if (!isObject(raw)) return null;
  const formData = isObject(raw.formData) ? raw.formData : raw;
  return createAnonymousDraft(formData, {
    clientDraftId: typeof raw.clientDraftId === "string" && raw.clientDraftId.trim() ? raw.clientDraftId : void 0,
    applicationSource: typeof raw.applicationSource === "string" && raw.applicationSource.trim() ? raw.applicationSource.trim() : void 0,
    lastCompletedStep: normalizeStep(raw.lastCompletedStep),
    authCheckpointReached: raw.authCheckpointReached === true,
    migrationStatus: raw.migrationStatus === "migrated" || raw.migrationStatus === "migrating" || raw.migrationStatus === "conflict" || raw.migrationStatus === "superseded" ? raw.migrationStatus : "local",
    updatedAt: typeof raw.updatedAt === "string" ? raw.updatedAt : void 0
  });
};
var loadAnonymousDraft = () => {
  if (!canUseLocalStorage()) return null;
  const current = normalizeDraft(
    parseJson(window.localStorage.getItem(ANONYMOUS_DRAFT_STORAGE_KEY))
  );
  if (current) return current;
  const legacy = normalizeDraft(
    parseJson(window.localStorage.getItem(LEGACY_GUIDE_FORM_DRAFT_KEY))
  );
  if (!legacy) return null;
  saveAnonymousDraft(legacy);
  return legacy;
};
var saveAnonymousDraft = (draft) => {
  if (!canUseLocalStorage()) return draft;
  window.localStorage.setItem(ANONYMOUS_DRAFT_STORAGE_KEY, JSON.stringify(draft));
  return draft;
};
var loadOrCreateAnonymousDraft = (initialData = {}) => {
  const existing = loadAnonymousDraft();
  if (existing) return existing;
  return saveAnonymousDraft(createAnonymousDraft(initialData));
};
var upsertAnonymousDraft = (formData, options = {}) => {
  const existing = loadAnonymousDraft();
  const reusableExisting = existing && existing.migrationStatus !== "migrated" && existing.migrationStatus !== "superseded" ? existing : null;
  const draft = createAnonymousDraft(formData, {
    clientDraftId: reusableExisting?.clientDraftId,
    applicationSource: options.applicationSource ?? reusableExisting?.applicationSource,
    lastCompletedStep: options.lastCompletedStep ?? reusableExisting?.lastCompletedStep ?? 0,
    authCheckpointReached: options.authCheckpointReached ?? reusableExisting?.authCheckpointReached ?? false,
    migrationStatus: options.migrationStatus ?? reusableExisting?.migrationStatus ?? "local"
  });
  draft.migratedAt = reusableExisting?.migratedAt;
  draft.dbDraftId = reusableExisting?.dbDraftId;
  draft.conflictReason = reusableExisting?.conflictReason;
  return saveAnonymousDraft(draft);
};
var markAnonymousDraftMigrating = () => {
  const existing = loadAnonymousDraft();
  if (!existing) return null;
  return saveAnonymousDraft({
    ...existing,
    migrationStatus: "migrating",
    updatedAt: nowIso()
  });
};
var markAnonymousDraftMigrated = (dbDraftId) => {
  const existing = loadAnonymousDraft();
  if (!existing) return null;
  return saveAnonymousDraft({
    ...existing,
    formData: {},
    migrationStatus: "migrated",
    migratedAt: nowIso(),
    dbDraftId,
    updatedAt: nowIso()
  });
};
var markAnonymousDraftConflict = (reason) => {
  const existing = loadAnonymousDraft();
  if (!existing) return null;
  return saveAnonymousDraft({
    ...existing,
    migrationStatus: reason === "stale_local_draft" || reason === "anonymous_draft_claimed" || reason === "submitted_application" || reason === "guide_profile_exists" ? "superseded" : "conflict",
    conflictReason: reason,
    updatedAt: nowIso()
  });
};
var clearAnonymousDraft = () => {
  if (!canUseLocalStorage()) return;
  window.localStorage.removeItem(ANONYMOUS_DRAFT_STORAGE_KEY);
  window.localStorage.removeItem(LEGACY_GUIDE_FORM_DRAFT_KEY);
  window.localStorage.removeItem(LEGACY_QUALIFICATION_FILES_KEY);
};

// src/storage/qualificationFileStore.ts
var DB_NAME = "yaotu-guide-application";
var DB_VERSION = 1;
var STORE_NAME = "qualificationFiles";
var canUseIndexedDb = () => typeof window !== "undefined" && typeof window.indexedDB !== "undefined";
var makeFileId = () => {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }
  return `file_${Date.now()}_${Math.random().toString(36).slice(2)}`;
};
var openDb = () => new Promise((resolve, reject) => {
  if (!canUseIndexedDb()) {
    reject(new Error("IndexedDB is not available in this browser"));
    return;
  }
  const request = window.indexedDB.open(DB_NAME, DB_VERSION);
  request.onupgradeneeded = () => {
    const db = request.result;
    if (!db.objectStoreNames.contains(STORE_NAME)) {
      const store = db.createObjectStore(STORE_NAME, { keyPath: "fileId" });
      store.createIndex("clientDraftId", "clientDraftId", { unique: false });
    }
  };
  request.onerror = () => reject(request.error ?? new Error("Failed to open IndexedDB"));
  request.onsuccess = () => resolve(request.result);
});
var withStore = async (mode, operation) => {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, mode);
    const store = transaction.objectStore(STORE_NAME);
    const request = operation(store);
    transaction.oncomplete = () => {
      db.close();
      resolve(request ? request.result : void 0);
    };
    transaction.onerror = () => {
      db.close();
      reject(transaction.error ?? new Error("IndexedDB transaction failed"));
    };
    transaction.onabort = () => {
      db.close();
      reject(transaction.error ?? new Error("IndexedDB transaction aborted"));
    };
  });
};
var toMetadata = (record) => {
  const { blob: _blob, ...metadata } = record;
  return metadata;
};
var stageQualificationFile = async (file, description, options = {}) => {
  const clientDraftId = options.clientDraftId ?? loadOrCreateAnonymousDraft().clientDraftId;
  const record = {
    fileId: makeFileId(),
    clientDraftId,
    name: file.name,
    type: file.type,
    size: file.size,
    description,
    visible: options.visible ?? true,
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    blob: file
  };
  await withStore("readwrite", (store) => store.put(record));
  return toMetadata(record);
};
var listStagedQualificationFiles = async (clientDraftId) => {
  const records = await withStore("readonly", (store) => {
    const index = store.index("clientDraftId");
    return index.getAll(clientDraftId);
  });
  return (records ?? []).map(toMetadata);
};
var getStagedQualificationFile = async (fileId) => {
  const record = await withStore(
    "readonly",
    (store) => store.get(fileId)
  );
  return record ?? null;
};
var removeStagedQualificationFile = async (fileId) => {
  await withStore("readwrite", (store) => {
    store.delete(fileId);
  });
};
var clearStagedQualificationFiles = async (clientDraftId) => {
  const files = await listStagedQualificationFiles(clientDraftId);
  await Promise.all(files.map((file) => removeStagedQualificationFile(file.fileId)));
};
var markStagedQualificationFileUploaded = async (fileId, data) => {
  const record = await getStagedQualificationFile(fileId);
  if (!record) return null;
  const next = {
    ...record,
    uploaded: true,
    publicUrl: data.publicUrl,
    serverFileId: data.fileId,
    uploadedMetadata: data
  };
  await withStore("readwrite", (store) => store.put(next));
  return toMetadata(next);
};
var indexedDbQualificationStorageAvailable = canUseIndexedDb;

// src/utils/guideFunnel.ts
var DEFAULT_RESUME_PATH = "/become-guide?resume=1";
var GUIDE_APPLICATION_IDENTITY_INTENT_STORAGE_KEY = "guideApplicationIdentityIntent";
var getResumePath = (config) => config.routes?.resumePath ?? DEFAULT_RESUME_PATH;
var appendRedirectParam = (path, redirectTo) => {
  const base = typeof window !== "undefined" ? window.location.origin : "https://guide.ahhh-yaotu.com";
  const url = new URL(path, base);
  url.searchParams.set("redirect", redirectTo);
  if (/^https?:\/\//i.test(path)) {
    return url.toString();
  }
  return `${url.pathname}${url.search}${url.hash}`;
};
var getAuthRedirectUrl = (config) => {
  const resumePath = getResumePath(config);
  const signupPath = config.routes?.signup ?? "/signup";
  return appendRedirectParam(signupPath, resumePath);
};
var getVerificationRedirectUrl = (config) => {
  const resumePath = getResumePath(config);
  const verifyPath = config.routes?.verifyEmail ?? "/verify-email";
  return appendRedirectParam(verifyPath, resumePath);
};
var isAuthenticated = (config) => Boolean(config.auth.getToken() && config.auth.getUserId());
var isAuthLoading = (config) => config.auth.isLoading?.() === true;
var isEmailVerified = (config) => {
  if (config.auth.isEmailVerified) return config.auth.isEmailVerified();
  const user = config.auth.getUser?.();
  if (!config.auth.getUser) return true;
  if (!user) return false;
  return user.emailVerified === true || user.emailverified === true;
};
var navigateToAuth = (config, context) => {
  const redirectTo = getResumePath(config);
  if (config.callbacks.onAuthRequired) {
    config.callbacks.onAuthRequired(redirectTo, context);
    return;
  }
  if (typeof window !== "undefined") {
    const signupIntentToken = context?.signupIntentToken?.trim();
    if (signupIntentToken) {
      window.sessionStorage.setItem(
        GUIDE_APPLICATION_IDENTITY_INTENT_STORAGE_KEY,
        signupIntentToken
      );
    }
    window.location.href = getAuthRedirectUrl(config);
  }
};
var navigateToVerification = (config) => {
  const redirectTo = getResumePath(config);
  if (config.callbacks.onVerificationRequired) {
    config.callbacks.onVerificationRequired(redirectTo);
    return;
  }
  if (typeof window !== "undefined") {
    window.location.href = getVerificationRedirectUrl(config);
  }
};

// src/lib/guideSignupIntent.ts
var serializeGuideSignupIntentRequest = (draft) => ({
  anonymousDraftId: draft.clientDraftId,
  anonymousDraftVersion: draft.draftVersion
});

// src/hooks/useGuideForm.ts
var defaultValues = {
  name: "",
  age: 18,
  sex: "Male",
  mbti: "ENFJ",
  socialProfile: "",
  assessmentQ1: [],
  assessmentQ1Slider: void 0,
  assessmentQ2: "",
  assessmentQ3: "",
  assessmentQ3Slider: void 0,
  assessmentQ4: [],
  assessmentQ4Slider: void 0,
  serviceAreaDestinationIds: [],
  customServiceAreaProposals: [],
  serviceAreas: [],
  serviceAreaProposals: [],
  residenceInfo: "",
  residenceZipcode: "",
  residenceStartDate: "",
  occupation: "",
  bio: "",
  qualifications: {
    certifications: {}
  },
  languages: [],
  experienceDuration: "",
  experienceSession: "",
  personalizedQ5: [],
  personalizedQ5Slider: void 0,
  personalizedQ6: [],
  personalizedQ6Slider: void 0,
  personalizedQ7: "",
  personalizedQ7Slider: void 0,
  personalizedQ8Strengths: [],
  personalizedQ8Slider: void 0,
  personalizedQ8Example: "",
  personalizedQ9: "",
  serviceSelections: [],
  targetGroup: [],
  minPeople: 1,
  maxPeople: 10,
  minDuration: 2,
  maxDuration: 8,
  basicPricePerHour: 30,
  additionalPricePerPerson: 5,
  currency: "USD"
};
var toJsonHeaders = (token) => {
  const headers = { "Content-Type": "application/json" };
  if (token) headers.Authorization = `Bearer ${token}`;
  return headers;
};
var toAuthHeaders = (token) => {
  const headers = {};
  if (token) headers.Authorization = `Bearer ${token}`;
  return headers;
};
var hasMeaningfulLocalDraft = (data) => {
  if (!data) return false;
  return Boolean(
    data.name?.trim() || data.socialProfile?.trim() || data.assessmentQ1?.length || data.assessmentQ2 || data.assessmentQ3 || data.assessmentQ4?.length || data.personalizedQ5?.length || data.personalizedQ6?.length || data.personalizedQ7 || data.personalizedQ8Strengths?.length || data.personalizedQ9?.trim()
  );
};
var loadReusableAnonymousDraft = () => {
  const draft = loadAnonymousDraft();
  if (!draft) return null;
  return draft.migrationStatus === "migrated" || draft.migrationStatus === "superseded" ? null : draft;
};
var isIdentityCheckpointComplete = (data) => Boolean(data && validateIdentityCheckpointCompleteness(data).length === 0);
var getResumePage = (draft, data) => {
  if (isIdentityCheckpointComplete(data)) return 3;
  if (!draft) return 1;
  return Math.max(1, Math.min(3, draft.lastCompletedStep + 1));
};
var responseJsonOrText = async (response) => {
  if (typeof response.text !== "function") {
    return typeof response.json === "function" ? response.json() : {};
  }
  const text = await response.text();
  if (!text) return {};
  try {
    return JSON.parse(text);
  } catch {
    return { error: text };
  }
};
var extractApplication = (payload) => payload?.application ?? payload;
var extractApplicationId = (payload) => {
  const application = extractApplication(payload);
  return application?.id ?? payload?.applicationId ?? payload?.id;
};
var prepareDatabasePayload = (data) => processFormDataForDatabase(
  prepareEvaluationPayload({
    ...defaultValues,
    ...data
  })
);
var useGuideForm = (config, onLoadLocalStorage, onSaveLocalStorage, onClearLocalStorage, initialStep) => {
  const resolveApiUrl = config.resolveApiUrl ?? ((path) => path);
  const [currentPage, setCurrentPage] = (0, import_react.useState)(1);
  const [showPreview, setShowPreview] = (0, import_react.useState)(false);
  const [confirmationChecked, setConfirmationChecked] = (0, import_react.useState)(false);
  const [missingFields, setMissingFields] = (0, import_react.useState)([]);
  const [savedData, setSavedData] = (0, import_react.useState)({});
  const [isLoading, setIsLoading] = (0, import_react.useState)(false);
  const [isSaving, setIsSaving] = (0, import_react.useState)(false);
  const [isSubmitting, setIsSubmitting] = (0, import_react.useState)(false);
  const [isCreatingSignupIntent, setIsCreatingSignupIntent] = (0, import_react.useState)(false);
  const [draftSource, setDraftSource] = (0, import_react.useState)("anonymous");
  const [dbDraftId, setDbDraftId] = (0, import_react.useState)(null);
  const [funnelState, setFunnelState] = (0, import_react.useState)("anonymous_editing");
  const [resumeState, setResumeState] = (0, import_react.useState)(
    initialStep === "resume" ? "loading" : "idle"
  );
  const [isDraftHydrated, setIsDraftHydrated] = (0, import_react.useState)(false);
  const [draftConflict, setDraftConflict] = (0, import_react.useState)(null);
  const shouldAutomaticallyLoadServerDraft = config.applicationContinuation === void 0 || config.applicationContinuation === "continue_server_draft" || config.applicationContinuation === "continue_required_changes";
  const submitRequestIdRef = (0, import_react.useRef)(null);
  const handoffRequestRef = (0, import_react.useRef)(null);
  const signupIntentRequestRef = (0, import_react.useRef)(null);
  const signupIntentTokenRef = (0, import_react.useRef)(null);
  const continueToAuthRequestRef = (0, import_react.useRef)(null);
  const autoResumeAttemptedDraftRef = (0, import_react.useRef)(null);
  const serverDraftLoadedRef = (0, import_react.useRef)(false);
  const form = (0, import_react_hook_form.useForm)({
    resolver: (0, import_zod2.zodResolver)(formSchema),
    defaultValues
  });
  const setDerivedMissingFields = (0, import_react.useCallback)((nextFields) => {
    setMissingFields(
      (currentFields) => currentFields.length === nextFields.length && currentFields.every((field, index) => field === nextFields[index]) ? currentFields : nextFields
    );
  }, []);
  const resetForm = (0, import_react.useCallback)(
    (data) => {
      const next = {
        ...defaultValues,
        ...processDatabaseDataForForm(data),
        qualifications: data.qualifications ?? defaultValues.qualifications,
        currency: "USD"
      };
      setSavedData(next);
      form.reset(next);
    },
    [form]
  );
  (0, import_react.useEffect)(() => {
    if (initialStep === "resume") {
      setResumeState("loading");
      setFunnelState("resume_after_auth");
    }
    const anonymousDraft = loadReusableAnonymousDraft();
    const hostDraft = onLoadLocalStorage?.();
    const localData = anonymousDraft?.formData ?? hostDraft;
    if (localData && hasMeaningfulLocalDraft(localData)) {
      resetForm(localData);
      if (initialStep === "resume") {
        setCurrentPage(getResumePage(anonymousDraft, localData));
      }
    }
    setIsDraftHydrated(true);
    if (initialStep === "resume") setResumeState("draft_hydrated");
    if (initialStep === "preview") {
      setShowPreview(true);
      setFunnelState("preview");
    }
  }, [initialStep, onLoadLocalStorage, resetForm]);
  const loadServerDraft = (0, import_react.useCallback)(async () => {
    if (!config.apiEndpoints.loadDraft || !isAuthenticated(config) || !isEmailVerified(config)) {
      return null;
    }
    const token = config.auth.getToken();
    const response = await fetch(resolveApiUrl(config.apiEndpoints.loadDraft), {
      method: "GET",
      headers: toAuthHeaders(token),
      credentials: "include"
    });
    if (response.status === 404) return null;
    if (!response.ok) {
      throw await responseJsonOrText(response);
    }
    const payload = await response.json();
    const application = extractApplication(payload);
    if (!application?.id) return null;
    setDbDraftId(application.id);
    setDraftSource("server");
    setFunnelState("authenticated_editing");
    resetForm(application);
    config.callbacks.onDraftLoaded?.(application);
    return application;
  }, [config, resetForm, resolveApiUrl]);
  const saveAnonymousDraft2 = (0, import_react.useCallback)(
    (data, lastCompletedStep, checkpoint = false) => {
      const draft = upsertAnonymousDraft(data, {
        applicationSource: config.applicationSource,
        lastCompletedStep,
        authCheckpointReached: checkpoint,
        migrationStatus: "local"
      });
      onSaveLocalStorage?.(data);
      setSavedData(data);
      config.callbacks.onSaveDraft?.(data);
      return draft;
    },
    [config.callbacks, onSaveLocalStorage]
  );
  const createSignupIntentForDraft = (0, import_react.useCallback)(
    (draft) => {
      const endpoint = config.apiEndpoints.createSignupIntent;
      if (!endpoint) return Promise.resolve(null);
      const draftKey = `${draft.clientDraftId}:${draft.draftVersion}`;
      const cachedIntent = signupIntentTokenRef.current;
      if (cachedIntent?.draftKey === draftKey) {
        return Promise.resolve(cachedIntent.token);
      }
      const activeRequest = signupIntentRequestRef.current;
      if (activeRequest) {
        if (activeRequest.draftKey === draftKey) return activeRequest.promise;
        return Promise.reject(
          new Error("A signup intent is already being created for another Guide draft.")
        );
      }
      let request;
      request = (async () => {
        const response = await fetch(resolveApiUrl(endpoint), {
          method: "POST",
          headers: toJsonHeaders(null),
          body: JSON.stringify(serializeGuideSignupIntentRequest(draft)),
          credentials: "include"
        });
        if (!response.ok) {
          throw await responseJsonOrText(response);
        }
        const result = await response.json();
        if (typeof result.signupIntentToken !== "string" || !result.signupIntentToken.trim()) {
          throw new Error("Guide signup intent response did not include a token.");
        }
        const token = result.signupIntentToken.trim();
        signupIntentTokenRef.current = { draftKey, token };
        return token;
      })().finally(() => {
        if (signupIntentRequestRef.current?.promise === request) {
          signupIntentRequestRef.current = null;
          setIsCreatingSignupIntent(false);
        }
      });
      signupIntentRequestRef.current = { draftKey, promise: request };
      setIsCreatingSignupIntent(true);
      return request;
    },
    [config.apiEndpoints.createSignupIntent, resolveApiUrl]
  );
  const ensureSignupIntentForCurrentDraft = (0, import_react.useCallback)(async () => {
    const draft = loadReusableAnonymousDraft() ?? saveAnonymousDraft2(form.getValues(), 3, true);
    const draftKey = `${draft.clientDraftId}:${draft.draftVersion}`;
    const cachedIntent = signupIntentTokenRef.current;
    if (cachedIntent?.draftKey === draftKey) {
      return {
        signupIntentToken: cachedIntent.token,
        anonymousDraftId: draft.clientDraftId
      };
    }
    const token = await createSignupIntentForDraft(draft);
    return {
      signupIntentToken: token,
      anonymousDraftId: draft.clientDraftId
    };
  }, [createSignupIntentForDraft, form, saveAnonymousDraft2]);
  const saveServerDraft = (0, import_react.useCallback)(
    async (data) => {
      if (!config.apiEndpoints.saveDraft) return null;
      const token = config.auth.getToken();
      const payload = prepareDatabasePayload(data);
      const response = await fetch(resolveApiUrl(config.apiEndpoints.saveDraft), {
        method: "PUT",
        headers: toJsonHeaders(token),
        body: JSON.stringify(payload),
        credentials: "include"
      });
      if (!response.ok) {
        throw await responseJsonOrText(response);
      }
      const result = await response.json();
      const application = extractApplication(result);
      if (application?.id) {
        setDbDraftId(application.id);
      }
      setDraftSource("server");
      setFunnelState("authenticated_editing");
      setSavedData(data);
      config.callbacks.onSaveDraft?.(result);
      return result;
    },
    [config, resolveApiUrl]
  );
  const uploadPendingQualificationFiles = (0, import_react.useCallback)(
    async (clientDraftId, data) => {
      const token = config.auth.getToken();
      const uploadEndpoint = config.apiEndpoints.qualificationUpload ?? "/api/v2/guide-applications/qualification-upload";
      const certifications = { ...data.qualifications?.certifications ?? {} };
      const stagedFiles = await listStagedQualificationFiles(clientDraftId);
      for (const staged of stagedFiles) {
        let uploadedMetadata = staged.uploadedMetadata ?? (staged.uploaded && staged.publicUrl ? {
          fileId: staged.serverFileId,
          publicUrl: staged.publicUrl,
          originalName: staged.name,
          size: staged.size,
          mimetype: staged.type
        } : null);
        const stored = await getStagedQualificationFile(staged.fileId);
        uploadedMetadata = uploadedMetadata ?? stored?.uploadedMetadata ?? null;
        if (!uploadedMetadata) {
          if (!stored?.blob) {
            throw new Error(`Staged qualification file is missing local data: ${staged.name}`);
          }
          const body = new globalThis.FormData();
          body.append("file", stored.blob, stored.name);
          const response = await fetch(resolveApiUrl(uploadEndpoint), {
            method: "POST",
            headers: toAuthHeaders(token),
            body,
            credentials: "include"
          });
          if (!response.ok) {
            throw await responseJsonOrText(response);
          }
          const result = await response.json();
          uploadedMetadata = {
            fileId: result.fileId,
            r2Key: result.r2Key,
            publicUrl: result.publicUrl,
            originalName: result.originalName,
            size: result.size,
            mimetype: result.mimetype
          };
          await markStagedQualificationFileUploaded(staged.fileId, uploadedMetadata);
        }
        const persistedFileId = String(uploadedMetadata.fileId ?? staged.fileId);
        certifications[persistedFileId] = {
          description: staged.description,
          proof: uploadedMetadata.publicUrl,
          visible: staged.visible !== false,
          uploaded: true,
          publicUrl: uploadedMetadata.publicUrl,
          r2Key: uploadedMetadata.r2Key,
          originalName: uploadedMetadata.originalName,
          size: uploadedMetadata.size,
          mimetype: uploadedMetadata.mimetype
        };
      }
      return {
        ...data,
        qualifications: {
          ...data.qualifications ?? {},
          certifications
        }
      };
    },
    [config, resolveApiUrl]
  );
  const runAnonymousDraftHandoff = (0, import_react.useCallback)(async () => {
    if (!isAuthenticated(config)) {
      loadReusableAnonymousDraft() ?? saveAnonymousDraft2(form.getValues(), 3, true);
      setFunnelState("auth_required");
      return null;
    }
    if (!isEmailVerified(config)) {
      setFunnelState("verification_required");
      return null;
    }
    const draft = loadReusableAnonymousDraft() ?? saveAnonymousDraft2(form.getValues(), 3, true);
    const data = draft.formData && hasMeaningfulLocalDraft(draft.formData) ? draft.formData : form.getValues();
    const checkpointMissingFields = validateIdentityCheckpointCompleteness(data);
    if (checkpointMissingFields.length > 0) {
      setMissingFields(checkpointMissingFields);
      setFunnelState("authenticated_editing");
      return null;
    }
    const endpoint = config.apiEndpoints.handoffDraft;
    if (!endpoint) {
      setDraftSource("server");
      setFunnelState("authenticated_editing");
      return { application: data };
    }
    markAnonymousDraftMigrating();
    setFunnelState("resume_after_auth");
    const token = config.auth.getToken();
    const response = await fetch(resolveApiUrl(endpoint), {
      method: "POST",
      headers: toJsonHeaders(token),
      body: JSON.stringify({
        clientDraftId: draft.clientDraftId,
        clientUpdatedAt: draft.updatedAt,
        anonymousDraftVersion: draft.draftVersion,
        applicationSource: draft.applicationSource ?? config.applicationSource,
        data: prepareDatabasePayload(data)
      }),
      credentials: "include"
    });
    const result = await responseJsonOrText(response);
    if (response.status === 409) {
      const conflict = result;
      setDraftConflict(conflict);
      markAnonymousDraftConflict(conflict.reason ?? "existing_server_draft");
      config.callbacks.onHandoffConflict?.(conflict);
      if (conflict.reason === "guide_profile_exists") {
        (config.callbacks.onNavigateToGuideHome ?? config.callbacks.onNavigateToStatus)?.();
      } else if (conflict.reason === "submitted_application") {
        config.callbacks.onNavigateToStatus?.();
      }
      setFunnelState("resume_after_auth");
      return null;
    }
    if (!response.ok) {
      upsertAnonymousDraft(data, {
        applicationSource: draft.applicationSource ?? config.applicationSource,
        lastCompletedStep: 3,
        authCheckpointReached: true,
        migrationStatus: "local"
      });
      throw result;
    }
    const application = extractApplication(result);
    const applicationId = extractApplicationId(result);
    const shouldPreserveNewerLocalDraft = result?.code === "GUIDE_DRAFT_HANDOFF_IDEMPOTENT";
    let hydrated = processDatabaseDataForForm(
      shouldPreserveNewerLocalDraft ? data : application ?? data
    );
    try {
      if (!applicationId) {
        throw new Error("Guide draft handoff did not return an application id.");
      }
      hydrated = await uploadPendingQualificationFiles(draft.clientDraftId, hydrated);
      await saveServerDraft(hydrated);
      await clearStagedQualificationFiles(draft.clientDraftId);
    } catch (error) {
      upsertAnonymousDraft(hydrated, {
        applicationSource: draft.applicationSource ?? config.applicationSource,
        lastCompletedStep: 3,
        authCheckpointReached: true,
        migrationStatus: "local"
      });
      setDbDraftId(applicationId ?? null);
      setFunnelState("resume_after_auth");
      config.callbacks.onError?.(error);
      return null;
    }
    setDbDraftId(applicationId);
    serverDraftLoadedRef.current = true;
    setDraftSource("server");
    resetForm(hydrated);
    markAnonymousDraftMigrated(applicationId);
    onClearLocalStorage?.();
    setFunnelState("authenticated_editing");
    setCurrentPage(4);
    config.callbacks.onHandoffSuccess?.(result);
    return result;
  }, [
    config,
    form,
    onClearLocalStorage,
    resetForm,
    resolveApiUrl,
    saveAnonymousDraft2,
    saveServerDraft,
    uploadPendingQualificationFiles
  ]);
  const handoffAnonymousDraft = (0, import_react.useCallback)(async () => {
    if (handoffRequestRef.current) {
      return handoffRequestRef.current;
    }
    const isEligible = isAuthenticated(config) && isEmailVerified(config);
    if (isEligible) setResumeState("handoff_in_flight");
    const request = runAnonymousDraftHandoff();
    handoffRequestRef.current = request;
    try {
      const result = await request;
      if (isEligible) setResumeState(result ? "handoff_complete" : "handoff_failed");
      return result;
    } catch (error) {
      if (isEligible) setResumeState("handoff_failed");
      throw error;
    } finally {
      if (handoffRequestRef.current === request) {
        handoffRequestRef.current = null;
      }
    }
  }, [config, runAnonymousDraftHandoff]);
  (0, import_react.useEffect)(() => {
    if (initialStep !== "resume" || !isDraftHydrated || isAuthLoading(config)) return;
    setResumeState(
      (current) => current === "loading" || current === "draft_hydrated" ? "auth_resolved" : current
    );
    const localDraft = loadReusableAnonymousDraft();
    if (hasMeaningfulLocalDraft(localDraft?.formData)) {
      const checkpointMissingFields = validateIdentityCheckpointCompleteness(localDraft.formData);
      if (checkpointMissingFields.length > 0) {
        setDerivedMissingFields(checkpointMissingFields);
        setFunnelState(
          isAuthenticated(config) && isEmailVerified(config) ? "authenticated_editing" : "anonymous_editing"
        );
        return;
      }
      setDerivedMissingFields([]);
      if (!isAuthenticated(config)) {
        setFunnelState("auth_required");
        return;
      }
      if (!isEmailVerified(config)) {
        setFunnelState("verification_required");
        return;
      }
      const attemptKey = `${localDraft.clientDraftId}:${localDraft.draftVersion}:${config.auth.getUserId()}`;
      if (autoResumeAttemptedDraftRef.current === attemptKey) return;
      autoResumeAttemptedDraftRef.current = attemptKey;
      setResumeState("handoff_eligible");
      void handoffAnonymousDraft().catch((error) => {
        config.callbacks.onError?.(error);
      });
      return;
    }
    if (autoResumeAttemptedDraftRef.current) return;
    if (!shouldAutomaticallyLoadServerDraft) return;
    setFunnelState(
      isAuthenticated(config) && isEmailVerified(config) ? "authenticated_editing" : "anonymous_editing"
    );
    if (!isAuthenticated(config) || !isEmailVerified(config) || serverDraftLoadedRef.current) return;
    serverDraftLoadedRef.current = true;
    void loadServerDraft().then((serverDraft) => {
      if (serverDraft) setCurrentPage(4);
    }).catch((error) => {
      config.callbacks.onError?.(error);
    });
  }, [
    config,
    handoffAnonymousDraft,
    initialStep,
    isDraftHydrated,
    loadServerDraft,
    setDerivedMissingFields
  ]);
  (0, import_react.useEffect)(() => {
    if (serverDraftLoadedRef.current) return;
    if (initialStep === "resume" && (!isDraftHydrated || isAuthLoading(config))) return;
    if (initialStep === "resume" && autoResumeAttemptedDraftRef.current) return;
    if (!shouldAutomaticallyLoadServerDraft) return;
    if (!isAuthenticated(config) || !isEmailVerified(config)) return;
    if (hasMeaningfulLocalDraft(loadReusableAnonymousDraft()?.formData)) return;
    serverDraftLoadedRef.current = true;
    void loadServerDraft().catch((error) => {
      config.callbacks.onError?.(error);
    });
  }, [config, initialStep, isDraftHydrated, loadServerDraft]);
  const saveDraft = async (data) => {
    try {
      setIsSaving(true);
      if (draftSource === "server" && isAuthenticated(config) && isEmailVerified(config)) {
        return await saveServerDraft(data);
      }
      return saveAnonymousDraft2(data, currentPage > 0 ? currentPage - 1 : 0);
    } catch (error) {
      config.callbacks.onError?.(error);
      throw error;
    } finally {
      setIsSaving(false);
    }
  };
  const saveCurrentPageData = () => {
    const currentData = form.getValues();
    void saveDraft(currentData);
  };
  const nextPage = async () => {
    if (initialStep === "resume" && (!isDraftHydrated || isAuthLoading(config))) return;
    const data = form.getValues();
    if (currentPage < 3) {
      saveAnonymousDraft2(data, currentPage);
      setCurrentPage(currentPage + 1);
      return;
    }
    if (currentPage === 3) {
      if (handoffRequestRef.current) {
        try {
          const activeResult = await handoffRequestRef.current;
          if (activeResult) setCurrentPage(4);
        } catch (error) {
          config.callbacks.onError?.(error);
        }
        return;
      }
      const checkpointMissingFields = validateIdentityCheckpointCompleteness(data);
      if (checkpointMissingFields.length > 0) {
        setMissingFields(checkpointMissingFields);
        return;
      }
      setMissingFields([]);
      saveAnonymousDraft2(data, 3, true);
      try {
        const result = await handoffAnonymousDraft();
        if (result) {
          setCurrentPage(4);
        }
      } catch (error) {
        config.callbacks.onError?.(error);
      }
      return;
    }
    if (currentPage < 4) {
      await saveDraft(data);
      setCurrentPage(currentPage + 1);
    }
  };
  const prevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };
  const goToPreview = async () => {
    const data = form.getValues();
    if (draftSource !== "server") {
      const result = await handoffAnonymousDraft();
      if (!result) return;
    } else {
      await saveDraft(data);
    }
    setFunnelState("preview");
    setShowPreview(true);
  };
  const backToForm = () => {
    setMissingFields([]);
    setShowPreview(false);
    setFunnelState(draftSource === "server" ? "authenticated_editing" : "anonymous_editing");
  };
  const submitToDatabase = async (data) => {
    const token = config.auth.getToken();
    const userId = config.auth.getUserId();
    const processedData = processFormDataForDatabase(
      prepareEvaluationPayload({
        ...data,
        userId,
        applicationStatus: "pending"
      })
    );
    const applicationId = dbDraftId ?? data.id;
    const endpoint = applicationId && config.apiEndpoints.updateApplication ? config.apiEndpoints.updateApplication(applicationId) : applicationId ? `${config.apiEndpoints.submitApplication}/${applicationId}` : config.apiEndpoints.submitApplication;
    const method = applicationId ? "PUT" : "POST";
    const response = await fetch(resolveApiUrl(endpoint), {
      method,
      headers: toJsonHeaders(token),
      body: JSON.stringify(processedData),
      credentials: "include"
    });
    if (!response.ok) {
      throw await responseJsonOrText(response);
    }
    const result = await response.json();
    const nextApplicationId = extractApplicationId(result);
    if (nextApplicationId && typeof localStorage !== "undefined") {
      localStorage.setItem("yaotu_application_id", nextApplicationId.toString());
    }
    setFunnelState("submitted");
    return result;
  };
  const submitApplication = async (data) => {
    if (isSubmitting || submitRequestIdRef.current !== null) {
      return;
    }
    if (!isAuthenticated(config)) {
      saveAnonymousDraft2(data, 3, true);
      let authContext;
      try {
        authContext = await ensureSignupIntentForCurrentDraft();
      } catch (error) {
        config.callbacks.onError?.(error);
        return;
      }
      setFunnelState("auth_required");
      navigateToAuth(config, authContext);
      return;
    }
    if (!isEmailVerified(config)) {
      saveAnonymousDraft2(data, 3, true);
      setFunnelState("verification_required");
      navigateToVerification(config);
      return;
    }
    if (draftSource !== "server") {
      const result = await handoffAnonymousDraft();
      if (!result) return;
    }
    const requestId = `${Date.now()}${Math.random().toString(36).slice(2, 11)}`;
    try {
      setIsLoading(true);
      setIsSubmitting(true);
      submitRequestIdRef.current = requestId;
      const result = await submitToDatabase({ ...data, userId: config.auth.getUserId() ?? void 0 });
      config.callbacks.onSuccess?.(result);
      return result;
    } catch (error) {
      config.callbacks.onError?.(error);
      throw error;
    } finally {
      setIsLoading(false);
      setIsSubmitting(false);
      submitRequestIdRef.current = null;
    }
  };
  const onSubmit = async () => {
    if (isSubmitting) return;
    if (!confirmationChecked) return;
    const finalData = form.getValues();
    const missing = validateFormCompleteness(finalData);
    if (missing.length > 0) {
      setMissingFields(missing);
      return;
    }
    setMissingFields([]);
    await submitApplication(finalData);
  };
  const handleQualificationFilesChange = (files) => {
    form.setValue("qualifications.certifications", files);
  };
  const acceptServerDraft = async () => {
    const serverDraft = await loadServerDraft();
    if (serverDraft) {
      markAnonymousDraftConflict("stale_local_draft");
      setDraftConflict(null);
      setCurrentPage(4);
      setDraftSource("server");
      return;
    }
    markAnonymousDraftConflict("stale_local_draft");
    setDraftConflict(null);
    config.callbacks.onNavigateToStatus?.();
  };
  const runContinueToAuth = (0, import_react.useCallback)(async () => {
    if (initialStep === "resume" && (!isDraftHydrated || isAuthLoading(config))) return;
    const data = form.getValues();
    const checkpointMissingFields = validateIdentityCheckpointCompleteness(data);
    if (checkpointMissingFields.length > 0) {
      setMissingFields(checkpointMissingFields);
      return;
    }
    setMissingFields([]);
    saveAnonymousDraft2(data, 3, true);
    if (isAuthenticated(config)) {
      if (!isEmailVerified(config)) {
        setFunnelState("verification_required");
        navigateToVerification(config);
        return;
      }
      try {
        const result = await handoffAnonymousDraft();
        if (result) setCurrentPage(4);
      } catch (error) {
        config.callbacks.onError?.(error);
      }
      return;
    }
    let authContext;
    try {
      authContext = await ensureSignupIntentForCurrentDraft();
    } catch (error) {
      config.callbacks.onError?.(error);
      return;
    }
    navigateToAuth(config, authContext);
  }, [
    config,
    ensureSignupIntentForCurrentDraft,
    form,
    handoffAnonymousDraft,
    initialStep,
    isDraftHydrated,
    saveAnonymousDraft2
  ]);
  const continueToAuth = (0, import_react.useCallback)(() => {
    if (continueToAuthRequestRef.current) return continueToAuthRequestRef.current;
    let request;
    request = runContinueToAuth().finally(() => {
      if (continueToAuthRequestRef.current === request) {
        continueToAuthRequestRef.current = null;
      }
    });
    continueToAuthRequestRef.current = request;
    return request;
  }, [runContinueToAuth]);
  return {
    currentPage,
    setCurrentPage,
    showPreview,
    setShowPreview,
    confirmationChecked,
    setConfirmationChecked,
    missingFields,
    setMissingFields,
    savedData,
    setSavedData,
    isLoading,
    isSaving,
    isSubmitting,
    isCreatingSignupIntent,
    draftSource,
    dbDraftId,
    funnelState,
    resumeState,
    isDraftHydrated,
    draftConflict,
    resumePath: getResumePath(config),
    form,
    saveCurrentPageData,
    handleQualificationFilesChange,
    saveDraft,
    submitApplication,
    continueToAuth,
    nextPage,
    prevPage,
    goToPreview,
    backToForm,
    onSubmit,
    validateFormCompleteness,
    handoffAnonymousDraft,
    acceptServerDraft
  };
};

// src/components/Step1BasicInfo.tsx
var import_react2 = require("react");
var import_react_intl = require("react-intl");

// src/utils/postalCode.ts
var POSTAL_CODE_REGEX = /^\d{7}$/;
var sanitizePostalCode = (value) => {
  return value.replace(/\D/g, "").slice(0, 7);
};
var formatPostalCode = (value) => {
  const sanitized = sanitizePostalCode(value);
  if (sanitized.length === 7) {
    return `${sanitized.slice(0, 3)}-${sanitized.slice(3)}`;
  }
  return sanitized;
};
var isValidPostalCode = (value) => {
  return POSTAL_CODE_REGEX.test(value);
};

// src/components/Step1BasicInfo.tsx
var import_jsx_runtime = require("react/jsx-runtime");
var normalizeCustomLocation = (value) => value.normalize("NFKC").trim().replace(/\s+/g, " ");
var getDestinationLabel = (destination, locale) => {
  if (locale.startsWith("zh")) {
    return destination.nameZhCn || destination.nameEn || destination.nameJa || destination.slug;
  }
  if (locale.startsWith("ja")) {
    return destination.nameJa || destination.nameEn || destination.nameZhCn || destination.slug;
  }
  return destination.nameEn || destination.nameJa || destination.nameZhCn || destination.slug;
};
var Step1BasicInfo = ({
  control,
  handleQualificationFilesChange,
  ui,
  destinations = [],
  destinationsLoading = false,
  destinationsLoadError = false,
  allowCustomDestination = true
}) => {
  const intl = (0, import_react_intl.useIntl)();
  const [destinationSearch, setDestinationSearch] = (0, import_react2.useState)("");
  const [customDestination, setCustomDestination] = (0, import_react2.useState)("");
  const sortedDestinations = (0, import_react2.useMemo)(
    () => [...destinations].sort((a, b) => {
      const sortA = a.sortOrder ?? Number.MAX_SAFE_INTEGER;
      const sortB = b.sortOrder ?? Number.MAX_SAFE_INTEGER;
      if (sortA !== sortB) return sortA - sortB;
      return getDestinationLabel(a, intl.locale).localeCompare(getDestinationLabel(b, intl.locale));
    }),
    [destinations, intl.locale]
  );
  const {
    FormField,
    FormItem,
    FormLabel,
    FormControl,
    FormMessage,
    Input,
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
    Textarea,
    Checkbox,
    YearMonthPicker,
    QualificationUploader
  } = ui;
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "space-y-6", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { className: "text-lg font-semibold text-gray-900 mb-4", children: intl.formatMessage({ id: "becomeGuide.step1.basicInfo" }) }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          FormField,
          {
            control,
            name: "name",
            render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormItem, { children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormLabel, { children: [
                intl.formatMessage({ id: "becomeGuide.step1.name" }),
                " *"
              ] }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
                Input,
                {
                  autoComplete: "name",
                  placeholder: intl.formatMessage({ id: "becomeGuide.step1.namePlaceholder" }),
                  ...field
                }
              ) }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormMessage, {})
            ] })
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          FormField,
          {
            control,
            name: "age",
            render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormItem, { children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormLabel, { children: [
                intl.formatMessage({ id: "becomeGuide.step1.age" }),
                " *",
                /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { className: "text-sm text-gray-500 ml-2", children: [
                  "(",
                  intl.formatMessage({ id: "becomeGuide.step1.ageRequirement" }),
                  ")"
                ] })
              ] }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
                Input,
                {
                  type: "number",
                  name: field.name,
                  autoComplete: "off",
                  min: "18",
                  max: "120",
                  value: field.value?.toString() || "",
                  onChange: (event) => field.onChange(parseInt(event.target.value) || 18)
                }
              ) }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormMessage, {})
            ] })
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          FormField,
          {
            control,
            name: "sex",
            render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormItem, { children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormLabel, { children: [
                intl.formatMessage({ id: "becomeGuide.step1.gender" }),
                " *"
              ] }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, { name: field.name, onValueChange: field.onChange, defaultValue: field.value, children: [
                /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
                  SelectValue,
                  {
                    placeholder: intl.formatMessage({
                      id: "becomeGuide.step1.genderPlaceholder"
                    })
                  }
                ) }) }),
                /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: SEX_OPTIONS.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, { value: option.value, children: intl.formatMessage({ id: option.labelKey }) }, option.value)) })
              ] }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormMessage, {})
            ] })
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          FormField,
          {
            control,
            name: "mbti",
            render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormItem, { children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormLabel, { children: [
                intl.formatMessage({ id: "becomeGuide.step1.mbti" }),
                /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { className: "text-sm text-gray-500 ml-2", children: [
                  "(",
                  intl.formatMessage({ id: "becomeGuide.step1.mbtiDescription" }),
                  ")"
                ] })
              ] }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, { name: field.name, onValueChange: field.onChange, defaultValue: field.value || "ENFJ", children: [
                /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
                  SelectValue,
                  {
                    placeholder: intl.formatMessage({
                      id: "becomeGuide.step1.mbtiPlaceholder"
                    })
                  }
                ) }) }),
                /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: MBTI_OPTIONS.map((type) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, { value: type, children: type }, type)) })
              ] }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormMessage, {})
            ] })
          }
        )
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        FormField,
        {
          control,
          name: "socialProfile",
          render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormItem, { className: "mt-4", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormLabel, { children: intl.formatMessage({ id: "becomeGuide.step1.socialProfile" }) }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
              Input,
              {
                name: field.name,
                autoComplete: "url",
                placeholder: intl.formatMessage({
                  id: "becomeGuide.step1.socialProfilePlaceholder"
                }),
                value: field.value || "",
                onChange: field.onChange
              }
            ) }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormMessage, {})
          ] })
        }
      )
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { className: "text-lg font-semibold text-gray-900 mb-4", children: intl.formatMessage({ id: "becomeGuide.step1.serviceInfo" }) }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "space-y-4", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          FormField,
          {
            control,
            name: "serviceAreaDestinationIds",
            render: ({ field }) => {
              const selectedIds = new Set(
                Array.isArray(field.value) ? field.value.map((value) => Number(value)) : []
              );
              const search = destinationSearch.trim().toLowerCase();
              const selectedDestinations = sortedDestinations.filter(
                (destination) => selectedIds.has(destination.id)
              );
              const availableDestinations = sortedDestinations.filter((destination) => {
                if (selectedIds.has(destination.id)) return false;
                if (!search) return true;
                return [
                  destination.slug,
                  destination.nameEn,
                  destination.nameJa,
                  destination.nameZhCn,
                  destination.prefectureName
                ].filter(Boolean).some((value) => String(value).toLowerCase().includes(search));
              });
              const setSelectedIds = (next) => field.onChange(Array.from(new Set(next.filter((value) => Number.isFinite(value)))));
              return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormItem, { children: [
                /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormLabel, { children: [
                  intl.formatMessage({
                    id: "becomeGuide.step1.serviceAreas",
                    defaultMessage: "Where can you host experiences in Japan?"
                  }),
                  " ",
                  "*"
                ] }),
                /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "space-y-3", children: [
                  selectedDestinations.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "flex flex-wrap gap-2", children: selectedDestinations.map((destination) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(
                    "button",
                    {
                      type: "button",
                      className: "rounded-full border border-yellow-300 bg-yellow-50 px-3 py-1 text-sm font-medium text-gray-900 hover:bg-yellow-100",
                      onClick: () => setSelectedIds(
                        Array.from(selectedIds).filter((id) => id !== destination.id)
                      ),
                      children: [
                        getDestinationLabel(destination, intl.locale),
                        " x"
                      ]
                    },
                    destination.id
                  )) }),
                  /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
                    Input,
                    {
                      name: "serviceAreaDestinationSearch",
                      autoComplete: "off",
                      value: destinationSearch,
                      onChange: (event) => setDestinationSearch(event.target.value),
                      placeholder: intl.formatMessage({
                        id: "becomeGuide.step1.serviceAreasSearchPlaceholder",
                        defaultMessage: "Search Tokyo, Yokohama, Kyoto..."
                      })
                    }
                  ) }),
                  /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "max-h-48 overflow-y-auto rounded-md border border-gray-200 bg-white", children: availableDestinations.length ? availableDestinations.slice(0, 12).map((destination) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(
                    "button",
                    {
                      type: "button",
                      className: "flex w-full items-center justify-between px-3 py-2 text-left text-sm hover:bg-gray-50",
                      onClick: () => {
                        setSelectedIds([...Array.from(selectedIds), destination.id]);
                        setDestinationSearch("");
                      },
                      children: [
                        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "font-medium text-gray-900", children: getDestinationLabel(destination, intl.locale) }),
                        destination.prefectureName && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "text-xs text-gray-500", children: destination.prefectureName })
                      ]
                    },
                    destination.id
                  )) : destinationsLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "px-3 py-3 text-sm text-gray-500", children: intl.formatMessage({
                    id: "becomeGuide.step1.loadingServiceAreas",
                    defaultMessage: "Loading service areas..."
                  }) }) : destinationsLoadError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "px-3 py-3 text-sm text-gray-500", children: intl.formatMessage({
                    id: "becomeGuide.step1.serviceAreasLoadFailed",
                    defaultMessage: "Service areas could not be loaded. You can add another area below."
                  }) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "px-3 py-3 text-sm text-gray-500", children: intl.formatMessage({
                    id: "becomeGuide.step1.noMatchingServiceAreas",
                    defaultMessage: "No matching destination found."
                  }) }) })
                ] }),
                /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormMessage, {})
              ] });
            }
          }
        ),
        allowCustomDestination && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          FormField,
          {
            control,
            name: "customServiceAreaProposals",
            render: ({ field }) => {
              const proposals = Array.isArray(field.value) ? field.value : [];
              const addProposal = () => {
                const nextValue = normalizeCustomLocation(customDestination);
                if (!nextValue) return;
                const existing = new Set(
                  proposals.map((value) => normalizeCustomLocation(value).toLowerCase())
                );
                if (existing.has(nextValue.toLowerCase())) {
                  setCustomDestination("");
                  return;
                }
                field.onChange([...proposals, nextValue]);
                setCustomDestination("");
              };
              return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormItem, { children: [
                /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormLabel, { children: intl.formatMessage({
                  id: "becomeGuide.step1.customServiceAreas",
                  defaultMessage: "Can't find your area?"
                }) }),
                /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "flex flex-col gap-2 sm:flex-row", children: [
                  /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
                    Input,
                    {
                      name: "customServiceAreaProposal",
                      autoComplete: "off",
                      value: customDestination,
                      onChange: (event) => setCustomDestination(event.target.value),
                      onKeyDown: (event) => {
                        if (event.key === "Enter") {
                          event.preventDefault();
                          addProposal();
                        }
                      },
                      placeholder: intl.formatMessage({
                        id: "becomeGuide.step1.customServiceAreasPlaceholder",
                        defaultMessage: "Add another location in Japan"
                      })
                    }
                  ) }),
                  /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
                    "button",
                    {
                      type: "button",
                      className: "rounded-md border border-yellow-400 px-4 py-2 text-sm font-medium text-gray-900 hover:bg-yellow-50",
                      onClick: addProposal,
                      children: intl.formatMessage({
                        id: "becomeGuide.step1.addCustomServiceArea",
                        defaultMessage: "Add location"
                      })
                    }
                  )
                ] }),
                proposals.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-2 flex flex-wrap gap-2", children: proposals.map((proposal) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(
                  "button",
                  {
                    type: "button",
                    className: "rounded-full border border-blue-200 bg-blue-50 px-3 py-1 text-sm font-medium text-blue-900 hover:bg-blue-100",
                    onClick: () => field.onChange(proposals.filter((value) => value !== proposal)),
                    children: [
                      proposal,
                      " x"
                    ]
                  },
                  proposal
                )) }),
                /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "text-xs text-gray-500", children: intl.formatMessage({
                  id: "becomeGuide.step1.customServiceAreasHelper",
                  defaultMessage: "New areas are reviewed by YaoTu before they become searchable destinations."
                }) }),
                /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormMessage, {})
              ] });
            }
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          FormField,
          {
            control,
            name: "residenceInfo",
            render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormItem, { children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormLabel, { children: intl.formatMessage({ id: "becomeGuide.step1.residenceInfo" }) }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
                Textarea,
                {
                  name: field.name,
                  autoComplete: "street-address",
                  placeholder: intl.formatMessage({
                    id: "becomeGuide.step1.residenceInfoPlaceholder"
                  }),
                  value: field.value || "",
                  onChange: field.onChange
                }
              ) }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormMessage, {})
            ] })
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          FormField,
          {
            control,
            name: "residenceZipcode",
            render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormItem, { children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormLabel, { children: [
                /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mr-1", children: "\u3012" }),
                intl.formatMessage({
                  id: "becomeGuide.step1.residenceZipcode",
                  defaultMessage: "Postal Code"
                })
              ] }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
                Input,
                {
                  name: field.name,
                  autoComplete: "postal-code",
                  inputMode: "numeric",
                  maxLength: 8,
                  placeholder: intl.formatMessage({
                    id: "becomeGuide.step1.residenceZipcodePlaceholder",
                    defaultMessage: "123-4567 (or enter 1234567)"
                  }),
                  value: formatPostalCode(field.value || ""),
                  onChange: (event) => field.onChange(sanitizePostalCode(event.target.value))
                }
              ) }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "text-xs text-gray-500 mt-1", children: intl.formatMessage({
                id: "becomeGuide.step1.residenceZipcodeHelper",
                defaultMessage: "Enter a 7-digit Japanese postal code. You can type 1234567 or 123-4567."
              }) }),
              field.value && !isValidPostalCode(field.value) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "text-sm text-red-500 mt-1", children: intl.formatMessage({
                id: "becomeGuide.step1.residenceZipcodeError",
                defaultMessage: "Please enter a 7-digit Japanese postal code."
              }) }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormMessage, {})
            ] })
          }
        ),
        YearMonthPicker ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          FormField,
          {
            control,
            name: "residenceStartDate",
            render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormItem, { children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormLabel, { children: intl.formatMessage({ id: "becomeGuide.step1.residenceStartDate" }) }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
                YearMonthPicker,
                {
                  name: field.name,
                  value: field.value ? new Date(field.value) : void 0,
                  onChange: (date) => field.onChange(date ? date.toISOString().split("T")[0] : ""),
                  placeholder: intl.formatMessage({
                    id: "becomeGuide.step1.residenceStartDatePlaceholder"
                  })
                }
              ) }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormMessage, {})
            ] })
          }
        ) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          FormField,
          {
            control,
            name: "residenceStartDate",
            render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormItem, { children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormLabel, { children: intl.formatMessage({ id: "becomeGuide.step1.residenceStartDate" }) }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
                Input,
                {
                  type: "month",
                  name: field.name,
                  autoComplete: "off",
                  value: field.value ? String(field.value).slice(0, 7) : "",
                  onChange: (event) => field.onChange(event.target.value ? `${event.target.value}-01` : "")
                }
              ) }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormMessage, {})
            ] })
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          FormField,
          {
            control,
            name: "occupation",
            render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormItem, { children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormLabel, { children: intl.formatMessage({ id: "becomeGuide.step1.occupation" }) }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
                Input,
                {
                  name: field.name,
                  autoComplete: "organization-title",
                  placeholder: intl.formatMessage({
                    id: "becomeGuide.step1.occupationPlaceholder"
                  }),
                  value: field.value || "",
                  onChange: field.onChange
                }
              ) }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormMessage, {})
            ] })
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { className: "text-lg font-semibold text-gray-900 mb-4", children: intl.formatMessage({ id: "becomeGuide.step1.qualifications" }) }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "space-y-4", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          FormField,
          {
            control,
            name: "languages",
            render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormItem, { children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "text-sm font-medium leading-none", children: intl.formatMessage({ id: "becomeGuide.step1.languages" }) }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "flex space-x-4", children: ["chinese", "japanese", "english"].map((languageKey) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "flex items-center space-x-2", children: [
                /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
                  Checkbox,
                  {
                    id: `language-${languageKey}`,
                    checked: field.value?.includes(languageKey) || false,
                    onCheckedChange: (checked) => {
                      const currentLanguages = field.value || [];
                      if (checked) {
                        field.onChange([...currentLanguages, languageKey]);
                      } else {
                        field.onChange(
                          currentLanguages.filter((lang) => lang !== languageKey)
                        );
                      }
                    }
                  }
                ),
                /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
                  "label",
                  {
                    htmlFor: `language-${languageKey}`,
                    className: "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70",
                    children: intl.formatMessage({
                      id: `becomeGuide.step1.languageOptions.${languageKey}`
                    })
                  }
                )
              ] }, languageKey)) }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormMessage, {})
            ] })
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "space-y-4", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "text-base font-medium", children: intl.formatMessage({ id: "becomeGuide.step1.experience" }) }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
              FormField,
              {
                control,
                name: "experienceDuration",
                render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormItem, { children: [
                  /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormLabel, { children: intl.formatMessage({ id: "becomeGuide.step1.experienceDuration" }) }),
                  /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
                    Input,
                    {
                      name: field.name,
                      autoComplete: "off",
                      placeholder: intl.formatMessage({
                        id: "becomeGuide.step1.experienceDurationPlaceholder"
                      }),
                      value: field.value || "",
                      onChange: field.onChange
                    }
                  ) }),
                  /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormMessage, {})
                ] })
              }
            ),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
              FormField,
              {
                control,
                name: "experienceSession",
                render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormItem, { children: [
                  /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormLabel, { children: intl.formatMessage({ id: "becomeGuide.step1.experienceSession" }) }),
                  /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
                    Input,
                    {
                      name: field.name,
                      autoComplete: "off",
                      placeholder: intl.formatMessage({
                        id: "becomeGuide.step1.experienceSessionPlaceholder"
                      }),
                      value: field.value || "",
                      onChange: field.onChange
                    }
                  ) }),
                  /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormMessage, {})
                ] })
              }
            )
          ] })
        ] }),
        QualificationUploader && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          FormField,
          {
            control,
            name: "qualifications",
            render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormItem, { children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
                QualificationUploader,
                {
                  value: field.value || { certifications: {} },
                  onChange: (files) => {
                    field.onChange(files);
                    handleQualificationFilesChange(files.certifications);
                  },
                  maxFiles: 5
                }
              ) }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormMessage, {})
            ] })
          }
        )
      ] })
    ] })
  ] });
};

// src/i18n/en.json
var en_default = {
  becomeGuide: {
    step1: {
      step1PageTitle: "Basic Information & Service Info"
    },
    step2: {
      title: "Self-Assessment",
      subtitle: "For matching 'Chosen Guide' tags, please evaluate yourself honestly",
      sliderInstruction: "Choose the position that best reflects your natural approach. Neither end is automatically better.",
      sliderUnselected: "Not selected",
      q1Question: "Q1. If a guest makes a request during the experience that is outside the original plan and may violate local rules or create a safety risk, how would you respond? (Select all that apply.)",
      q1Options: {
        understandRequest: "Ask for more information about what the guest wants before deciding whether the request is feasible.",
        refuseUnsafe: "Decline any part of the request that is illegal, unsafe, or clearly outside the agreed scope of service, and explain why.",
        offerAlternative: "When possible, suggest a legal and safe alternative.",
        contactPlatform: "Contact the platform if the situation continues, becomes disputed, or requires additional support.",
        satisfyFirst: "Try to accommodate the request first to avoid disappointing the guest.",
        doNotEngage: "Treat it as the guest\u2019s personal decision and avoid getting involved, without offering an explanation or assistance."
      },
      q1SliderTitle: "Flexibility and Principles",
      q1SliderTooltip: "When a guest makes an unexpected request, which approach is closer to your natural first instinct?",
      q1Range1: "1 \u2014 I first explore whether the request can be accommodated",
      q1Range9: "9 \u2014 I first check whether the request is appropriate and within clear boundaries",
      q3Question: "Q2. When a guest appears to be having difficulty or does not seem well, what would you usually do first?",
      q3Options: {
        askAndSupport: "Ask whether they need help and provide support based on their response.",
        observeThenCheck: "Observe the situation first and briefly check in at an appropriate moment.",
        activelyHelp: "Proactively stay with them and help them resolve the problem.",
        waitForRequest: "Respect their space and wait until they clearly ask for assistance.",
        doNotIntervene: "Unless they directly ask for help, I would generally not intervene."
      },
      q3SliderTitle: "Helping and Giving Space",
      q3SliderTooltip: "When a guest appears to be having difficulty, which response feels more natural to you?",
      q3Range1: "1 \u2014 I tend to check in and offer help proactively",
      q3Range9: "9 \u2014 I tend to give them space and wait for clearer signals",
      q4Question: "Q3. What types of interaction would you like to have with guests during an experience? (Select all that apply.)",
      q4Options: {
        shareStories: "Start conversations and share appropriate personal experiences or local stories.",
        localConnections: "When everyone is comfortable and the arrangement is appropriate, introduce guests to local people or invite them to participate in local activities.",
        takePhotos: "Help guests take photos and document their trip when they would like you to.",
        adjustPace: "Adjust the interaction style or pace of the experience according to the guest\u2019s needs and condition.",
        quietCompany: "Travel quietly with guests without creating pressure to keep talking.",
        giveSpace: "Give guests enough freedom to explore at their own pace.",
        stayInTouch: "Remain in contact after the experience if both the guest and Guide would like to.",
        professionalRelationship: "Remain friendly and courteous while keeping the relationship primarily professional after the experience."
      },
      q4SliderTitle: "Guest Interaction Style",
      q4SliderTooltip: "What level of interaction feels most natural to you during an experience?",
      q4Range1: "1 \u2014 I prefer an active, social, and shared experience",
      q4Range9: "9 \u2014 I prefer a quieter experience with more independence and personal space"
    },
    step4: {
      step4PageTitle: "Service Types & Preferences"
    },
    step3: {
      title: "Personalized Questions",
      subtitle: "Help us understand your guiding preferences and strengths",
      sliderInstruction: "Choose the position that best reflects your natural approach. Neither end is automatically better.",
      sliderUnselected: "Not selected",
      q6Question: "Q4. If a guest behaves disrespectfully toward you during an experience, which actions might you take? (Select all that apply.)",
      q6Options: {
        stateBoundary: "Remain calm and politely explain how the behavior affects you or crosses a service boundary.",
        adjustInteraction: "Adjust the interaction according to the seriousness of the situation to prevent it from escalating.",
        contactPlatform: "Contact the platform for assistance if the behavior continues, interferes with the service, or creates a safety concern.",
        stopService: "Consider ending the service if safe and effective communication can no longer be maintained.",
        endureSilently: "Tolerate the behavior without expressing any concerns so that the experience can be completed.",
        argue: "Argue with the guest and insist that they admit they were wrong."
      },
      q6SliderTitle: "Response to Conflict and Disrespect",
      q6SliderTooltip: "When a guest behaves disrespectfully, which response is closer to your natural approach?",
      q6Range1: "1 \u2014 I first try to adjust the interaction and de-escalate the situation",
      q6Range9: "9 \u2014 I first state a clear boundary and take formal action if needed",
      q7Question: "Q5. If you become unavailable before a scheduled experience, what would you usually do?",
      q7Options: {
        notifyGuestAndYaotu: "Notify the guest and YaoTu as soon as possible, explain the situation, and follow the platform\u2019s cancellation or rescheduling process.",
        arrangeDirectly: "Contact the guest and try to arrange another time directly.",
        waitAndSee: "Wait until closer to the start time in case I become available again.",
        substituteWithoutPlatform: "Ask another person to take my place without involving the platform.",
        cancelIfAsked: "Cancel the experience without contacting the guest unless they reach out first."
      },
      q8Question: "Q6. What do you consider your greatest strengths as a Guide? (Select up to three.)",
      q8Options: {
        hiddenSpots: "Knowledge of lesser-known local places",
        conversation: "Conversation skills and the ability to create an engaging atmosphere",
        planning: "Strong itinerary-planning skills",
        adaptability: "Adaptability and problem-solving in unexpected situations",
        photography: "Photography skills",
        food: "Knowledge of local food",
        shopping: "Knowledge of shopping",
        transportation: "Knowledge of local transportation",
        firstTimeVisitors: "Ability to support guests visiting Japan for the first time",
        observeNeeds: "Ability to observe and respond to guests\u2019 needs",
        respectPace: "Respect for guests\u2019 pace and personal space",
        multilingual: "Multilingual communication",
        unexpectedSituations: "Clear communication and reliability"
      },
      q8ExampleQuestion: "Please share one specific moment or example that best demonstrates your ability as a Guide. (Maximum 100 words.)",
      q8ExamplePlaceholder: "Describe the situation, what you did, and what it shows about you as a Guide...",
      q8SliderTitle: "Your Core Guiding Strength",
      q8SliderTooltip: "Which type of strength is more central to what you naturally bring as a Guide?",
      q8Range1: "1 \u2014 Local knowledge, planning, and practical expertise",
      q8Range9: "9 \u2014 Communication, observation, and guest support",
      q9Question: "Q7. Why do you want to become a YaoTu Guide, and what do you hope guiding will make possible for you?",
      q9Placeholder: "Share your motivation and what guiding could make possible for you...",
      q9HelperText: "There\u2019s no right answer. We\u2019d simply like to understand your motivation and what you hope to get from guiding."
    }
  }
};

// src/i18n/zh-CN.json
var zh_CN_default = {
  becomeGuide: {
    step1: {
      step1PageTitle: "\u57FA\u672C\u4FE1\u606F\u4E0E\u670D\u52A1\u4FE1\u606F"
    },
    step2: {
      title: "\u81EA\u6211\u8BA4\u77E5\u8BC4\u4F30",
      subtitle: '\u7528\u4E8E\u5339\u914D"\u5929\u9009\u5730\u966A"\u6807\u7B7E\uFF0C\u8BF7\u8BDA\u5B9E\u8BC4\u4EF7\u81EA\u5DF1',
      sliderInstruction: "\u8BF7\u9009\u62E9\u6700\u63A5\u8FD1\u4F60\u81EA\u7136\u505A\u6CD5\u7684\u4F4D\u7F6E\u3002\u6ED1\u5757\u4E24\u7AEF\u6CA1\u6709\u81EA\u52A8\u7684\u4F18\u52A3\u4E4B\u5206\u3002",
      sliderUnselected: "\u672A\u9009\u62E9",
      q1Question: "Q1. \u5982\u679C\u5BA2\u4EBA\u5728\u884C\u7A0B\u4E2D\u63D0\u51FA\u4E00\u9879\u8D85\u51FA\u539F\u8BA1\u5212\u7684\u8BF7\u6C42\uFF0C\u800C\u8BE5\u8BF7\u6C42\u53EF\u80FD\u8FDD\u53CD\u5F53\u5730\u89C4\u5B9A\u6216\u5E26\u6765\u5B89\u5168\u98CE\u9669\uFF0C\u4F60\u4F1A\u5982\u4F55\u5904\u7406\uFF1F\uFF08\u8BF7\u9009\u62E9\u6240\u6709\u7B26\u5408\u7684\u9009\u9879\u3002\uFF09",
      q1Options: {
        understandRequest: "\u5148\u4E86\u89E3\u5BA2\u4EBA\u7684\u5177\u4F53\u9700\u6C42\uFF0C\u518D\u5224\u65AD\u662F\u5426\u53EF\u884C",
        refuseUnsafe: "\u5BF9\u4E0D\u5408\u6CD5\u3001\u4E0D\u5B89\u5168\u6216\u660E\u663E\u8D85\u51FA\u670D\u52A1\u8303\u56F4\u7684\u90E8\u5206\u4E88\u4EE5\u62D2\u7EDD\uFF0C\u5E76\u8BF4\u660E\u539F\u56E0",
        offerAlternative: "\u5728\u6761\u4EF6\u5141\u8BB8\u7684\u60C5\u51B5\u4E0B\uFF0C\u63D0\u4F9B\u5408\u6CD5\u3001\u5B89\u5168\u7684\u66FF\u4EE3\u65B9\u6848",
        contactPlatform: "\u5982\u679C\u60C5\u51B5\u6301\u7EED\u3001\u5B58\u5728\u4E89\u8BAE\u6216\u9700\u8981\u8FDB\u4E00\u6B65\u534F\u52A9\uFF0C\u8054\u7CFB\u5E73\u53F0",
        satisfyFirst: "\u4E3A\u4E86\u907F\u514D\u5BA2\u4EBA\u4E0D\u6EE1\uFF0C\u6211\u4F1A\u5148\u5C3D\u91CF\u6EE1\u8DB3\u8BF7\u6C42",
        doNotEngage: "\u8FD9\u662F\u5BA2\u4EBA\u7684\u4E2A\u4EBA\u9009\u62E9\uFF0C\u6211\u4E0D\u4F1A\u53C2\u4E0E\uFF0C\u4E5F\u4E0D\u4F1A\u63D0\u4F9B\u4EFB\u4F55\u8BF4\u660E\u6216\u5E2E\u52A9"
      },
      q1SliderTitle: "\u7075\u6D3B\u914D\u5408\u4E0E\u539F\u5219\u5224\u65AD",
      q1SliderTooltip: "\u5F53\u5BA2\u4EBA\u63D0\u51FA\u8BA1\u5212\u5916\u8BF7\u6C42\u65F6\uFF0C\u54EA\u79CD\u65B9\u5F0F\u66F4\u63A5\u8FD1\u4F60\u7684\u81EA\u7136\u7B2C\u4E00\u53CD\u5E94\uFF1F",
      q1Range1: "1 \u2014 \u6211\u4F1A\u5148\u4E86\u89E3\u662F\u5426\u80FD\u591F\u914D\u5408",
      q1Range9: "9 \u2014 \u6211\u4F1A\u5148\u5224\u65AD\u662F\u5426\u5408\u9002\u5E76\u7B26\u5408\u660E\u786E\u8FB9\u754C",
      q3Question: "Q2. \u5F53\u5BA2\u4EBA\u770B\u8D77\u6765\u9047\u5230\u56F0\u96BE\u6216\u72B6\u6001\u4E0D\u592A\u597D\u65F6\uFF0C\u4F60\u901A\u5E38\u4F1A\u5148\u600E\u4E48\u505A\uFF1F",
      q3Options: {
        askAndSupport: "\u4E3B\u52A8\u8BE2\u95EE\u5BF9\u65B9\u662F\u5426\u9700\u8981\u5E2E\u52A9\uFF0C\u5E76\u6839\u636E\u56DE\u5E94\u63D0\u4F9B\u652F\u6301",
        observeThenCheck: "\u5148\u89C2\u5BDF\u60C5\u51B5\uFF0C\u9009\u62E9\u5408\u9002\u7684\u65F6\u673A\u7B80\u5355\u786E\u8BA4",
        activelyHelp: "\u4E3B\u52A8\u966A\u4F34\u5E76\u5E2E\u52A9\u5BF9\u65B9\u89E3\u51B3\u95EE\u9898",
        waitForRequest: "\u5C0A\u91CD\u5BF9\u65B9\u7684\u7A7A\u95F4\uFF0C\u7B49\u5BF9\u65B9\u660E\u786E\u63D0\u51FA\u9700\u6C42",
        doNotIntervene: "\u9664\u975E\u5BF9\u65B9\u4E3B\u52A8\u6C42\u52A9\uFF0C\u5426\u5219\u6211\u901A\u5E38\u4E0D\u4F1A\u4ECB\u5165"
      },
      q3SliderTitle: "\u5E2E\u52A9\u4E0E\u4FDD\u7559\u7A7A\u95F4",
      q3SliderTooltip: "\u5F53\u5BA2\u4EBA\u770B\u8D77\u6765\u9047\u5230\u56F0\u96BE\u65F6\uFF0C\u54EA\u79CD\u56DE\u5E94\u65B9\u5F0F\u5BF9\u4F60\u6765\u8BF4\u66F4\u81EA\u7136\uFF1F",
      q3Range1: "1 \u2014 \u6211\u503E\u5411\u4E3B\u52A8\u786E\u8BA4\u5E76\u63D0\u4F9B\u5E2E\u52A9",
      q3Range9: "9 \u2014 \u6211\u503E\u5411\u5148\u7ED9\u4E88\u7A7A\u95F4\uFF0C\u7B49\u5F85\u66F4\u660E\u786E\u7684\u4FE1\u53F7",
      q4Question: "Q3. \u5728\u4F53\u9A8C\u8FC7\u7A0B\u4E2D\uFF0C\u4F60\u5E0C\u671B\u548C\u5BA2\u4EBA\u4FDD\u6301\u4EC0\u4E48\u6837\u7684\u4E92\u52A8\uFF1F\uFF08\u53EF\u591A\u9009\uFF09",
      q4Options: {
        shareStories: "\u4E3B\u52A8\u804A\u5929\uFF0C\u5206\u4EAB\u9002\u5F53\u7684\u4E2A\u4EBA\u7ECF\u5386\u6216\u672C\u5730\u6545\u4E8B",
        localConnections: "\u5728\u53CC\u65B9\u90FD\u613F\u610F\u4E14\u5B89\u6392\u5408\u9002\u7684\u60C5\u51B5\u4E0B\uFF0C\u5E26\u5BA2\u4EBA\u8BA4\u8BC6\u5F53\u5730\u4EBA\u6216\u53C2\u4E0E\u672C\u5730\u6D3B\u52A8",
        takePhotos: "\u5728\u5BA2\u4EBA\u613F\u610F\u7684\u60C5\u51B5\u4E0B\uFF0C\u5E2E\u5BA2\u4EBA\u62CD\u7167\u3001\u8BB0\u5F55\u65C5\u7A0B",
        adjustPace: "\u6839\u636E\u5BA2\u4EBA\u7684\u72B6\u6001\u548C\u9700\u6C42\u7075\u6D3B\u8C03\u6574\u4E92\u52A8\u6216\u884C\u7A0B\u8282\u594F",
        quietCompany: "\u966A\u5BA2\u4EBA\u5B89\u9759\u5730\u65C5\u884C\uFF0C\u4E0D\u8FC7\u5EA6\u804A\u5929",
        giveSpace: "\u7ED9\u4E88\u5BA2\u4EBA\u5145\u5206\u7A7A\u95F4\uFF0C\u8BA9\u5BA2\u4EBA\u6309\u81EA\u5DF1\u7684\u8282\u594F\u63A2\u7D22",
        stayInTouch: "\u5982\u679C\u53CC\u65B9\u90FD\u613F\u610F\uFF0C\u884C\u7A0B\u7ED3\u675F\u540E\u53EF\u4EE5\u7EE7\u7EED\u4FDD\u6301\u8054\u7CFB",
        professionalRelationship: "\u884C\u7A0B\u7ED3\u675F\u540E\uFF0C\u4FDD\u6301\u793C\u8C8C\u4F46\u4EE5\u4E13\u4E1A\u5173\u7CFB\u4E3A\u4E3B"
      },
      q4SliderTitle: "\u4E0E\u5BA2\u4EBA\u7684\u4E92\u52A8\u98CE\u683C",
      q4SliderTooltip: "\u5728\u884C\u7A0B\u4E2D\uFF0C\u54EA\u79CD\u4E92\u52A8\u7A0B\u5EA6\u5BF9\u4F60\u6765\u8BF4\u66F4\u81EA\u7136\uFF1F",
      q4Range1: "1 \u2014 \u6211\u66F4\u559C\u6B22\u4E3B\u52A8\u3001\u70ED\u95F9\u4E14\u5171\u540C\u53C2\u4E0E\u7684\u4F53\u9A8C",
      q4Range9: "9 \u2014 \u6211\u66F4\u559C\u6B22\u5B89\u9759\u3001\u72EC\u7ACB\u4E14\u4FDD\u7559\u66F4\u591A\u4E2A\u4EBA\u7A7A\u95F4\u7684\u4F53\u9A8C"
    },
    step4: {
      step4PageTitle: "\u670D\u52A1\u7C7B\u578B\u4E0E\u504F\u597D"
    },
    step3: {
      title: "\u4E2A\u6027\u5316\u63D0\u95EE",
      subtitle: "\u5E2E\u52A9\u6211\u4EEC\u4E86\u89E3\u4F60\u7684\u5E26\u9886\u504F\u597D\u4E0E\u4F18\u52BF",
      sliderInstruction: "\u8BF7\u9009\u62E9\u6700\u63A5\u8FD1\u4F60\u81EA\u7136\u505A\u6CD5\u7684\u4F4D\u7F6E\u3002\u6ED1\u5757\u4E24\u7AEF\u6CA1\u6709\u81EA\u52A8\u7684\u4F18\u52A3\u4E4B\u5206\u3002",
      sliderUnselected: "\u672A\u9009\u62E9",
      q6Question: "Q4. \u5982\u679C\u5BA2\u4EBA\u5728\u4F53\u9A8C\u4E2D\u5BF9\u4F60\u8868\u73B0\u51FA\u4E0D\u5C0A\u91CD\uFF0C\u4F60\u53EF\u80FD\u4F1A\u600E\u4E48\u505A\uFF1F\uFF08\u53EF\u591A\u9009\uFF09",
      q6Options: {
        stateBoundary: "\u4FDD\u6301\u51B7\u9759\uFF0C\u793C\u8C8C\u8BF4\u660E\u81EA\u5DF1\u7684\u611F\u53D7\u6216\u670D\u52A1\u8FB9\u754C",
        adjustInteraction: "\u6839\u636E\u4E25\u91CD\u7A0B\u5EA6\u8C03\u6574\u4E92\u52A8\u65B9\u5F0F\uFF0C\u907F\u514D\u60C5\u51B5\u8FDB\u4E00\u6B65\u5347\u7EA7",
        contactPlatform: "\u5982\u679C\u884C\u4E3A\u6301\u7EED\u3001\u5F71\u54CD\u670D\u52A1\u6216\u6D89\u53CA\u5B89\u5168\uFF0C\u8054\u7CFB\u5E73\u53F0\u534F\u52A9\u5904\u7406",
        stopService: "\u5728\u5B89\u5168\u548C\u6C9F\u901A\u90FD\u65E0\u6CD5\u4FDD\u8BC1\u7684\u60C5\u51B5\u4E0B\uFF0C\u8003\u8651\u505C\u6B62\u670D\u52A1",
        endureSilently: "\u4E3A\u4E86\u987A\u5229\u5B8C\u6210\u884C\u7A0B\uFF0C\u6211\u901A\u5E38\u4F1A\u5FCD\u8010\uFF0C\u4E0D\u8868\u8FBE\u4EFB\u4F55\u610F\u89C1",
        argue: "\u5F53\u573A\u4E0E\u5BA2\u4EBA\u4E89\u6267\uFF0C\u575A\u6301\u8BA9\u5BF9\u65B9\u627F\u8BA4\u9519\u8BEF"
      },
      q6SliderTitle: "\u9762\u5BF9\u51B2\u7A81\u548C\u4E0D\u5C0A\u91CD\u7684\u53CD\u5E94",
      q6SliderTooltip: "\u5F53\u5BA2\u4EBA\u8868\u73B0\u51FA\u4E0D\u5C0A\u91CD\u65F6\uFF0C\u54EA\u79CD\u65B9\u5F0F\u66F4\u63A5\u8FD1\u4F60\u7684\u81EA\u7136\u5904\u7406\u503E\u5411\uFF1F",
      q6Range1: "1 \u2014 \u6211\u4F1A\u5148\u8C03\u6574\u4E92\u52A8\u65B9\u5F0F\uFF0C\u5C3D\u91CF\u7F13\u548C\u5C40\u9762",
      q6Range9: "9 \u2014 \u6211\u4F1A\u5148\u660E\u786E\u8BF4\u660E\u8FB9\u754C\uFF0C\u5E76\u5728\u5FC5\u8981\u65F6\u91C7\u53D6\u6B63\u5F0F\u5904\u7406",
      q7Question: "Q5. \u5982\u679C\u4F60\u5728\u5DF2\u9884\u7EA6\u7684\u4F53\u9A8C\u5F00\u59CB\u524D\u4E34\u65F6\u65E0\u6CD5\u5C65\u7EA6\uFF0C\u4F60\u901A\u5E38\u4F1A\u600E\u4E48\u505A\uFF1F",
      q7Options: {
        notifyGuestAndYaotu: "\u5C3D\u5FEB\u901A\u77E5\u5BA2\u4EBA\u548C YaoTu\uFF0C\u8BF4\u660E\u60C5\u51B5\uFF0C\u5E76\u6309\u7167\u5E73\u53F0\u7684\u53D6\u6D88\u6216\u6539\u671F\u6D41\u7A0B\u5904\u7406\u3002",
        arrangeDirectly: "\u8054\u7CFB\u5BA2\u4EBA\uFF0C\u5C1D\u8BD5\u79C1\u4E0B\u53E6\u7EA6\u4E00\u4E2A\u65F6\u95F4\u3002",
        waitAndSee: "\u7B49\u5230\u66F4\u63A5\u8FD1\u5F00\u59CB\u65F6\u95F4\u518D\u770B\u60C5\u51B5\uFF0C\u4E07\u4E00\u6211\u53C8\u53EF\u4EE5\u5C65\u7EA6\u3002",
        substituteWithoutPlatform: "\u4E0D\u901A\u8FC7\u5E73\u53F0\uFF0C\u76F4\u63A5\u8BF7\u522B\u4EBA\u4EE3\u66FF\u6211\u5B8C\u6210\u4F53\u9A8C\u3002",
        cancelIfAsked: "\u5148\u53D6\u6D88\u4F53\u9A8C\uFF0C\u9664\u975E\u5BA2\u4EBA\u4E3B\u52A8\u8054\u7CFB\u6211\uFF0C\u5426\u5219\u4E0D\u518D\u901A\u77E5\u3002"
      },
      q8Question: "Q6. \u4F60\u8BA4\u4E3A\u81EA\u5DF1\u4F5C\u4E3A\u5730\u966A\u6700\u5927\u7684\u4F18\u52BF\u662F\u4EC0\u4E48\uFF1F\uFF08\u6700\u591A\u9009\u62E9\u4E09\u9879\uFF09",
      q8Options: {
        hiddenSpots: "\u719F\u6089\u5F53\u5730\u5C0F\u4F17\u666F\u70B9",
        conversation: "\u64C5\u957F\u804A\u5929\u3001\u6D3B\u8DC3\u6C14\u6C1B",
        planning: "\u884C\u7A0B\u89C4\u5212\u80FD\u529B\u5F3A",
        adaptability: "\u5E94\u53D8\u80FD\u529B\u597D",
        photography: "\u62CD\u7167\u6280\u672F\u597D",
        food: "\u719F\u6089\u7F8E\u98DF",
        shopping: "\u719F\u6089\u8D2D\u7269",
        transportation: "\u719F\u6089\u4EA4\u901A",
        firstTimeVisitors: "\u64C5\u957F\u7167\u987E\u7B2C\u4E00\u6B21\u6765\u65E5\u672C\u7684\u6E38\u5BA2",
        observeNeeds: "\u5584\u4E8E\u89C2\u5BDF\u5BA2\u4EBA\u7684\u9700\u6C42",
        respectPace: "\u5C0A\u91CD\u5BA2\u4EBA\u7684\u8282\u594F\u548C\u4E2A\u4EBA\u7A7A\u95F4",
        multilingual: "\u591A\u8BED\u8A00\u6C9F\u901A",
        unexpectedSituations: "\u89E3\u51B3\u7A81\u53D1\u60C5\u51B5\u80FD\u529B\u5F3A"
      },
      q8ExampleQuestion: "\u8BF7\u5206\u4EAB\u4E00\u4E2A\u6700\u80FD\u4F53\u73B0\u4F60\u4F5C\u4E3A\u5730\u966A\u80FD\u529B\u7684\u5177\u4F53\u7ECF\u5386\u6216\u4F8B\u5B50\u3002\uFF08\u6700\u591A 100 \u8BCD\uFF09",
      q8ExamplePlaceholder: "\u8BF7\u5206\u4EAB\u4E00\u4EF6\u6700\u80FD\u4EE3\u8868\u4F60\u5730\u966A\u80FD\u529B\u7684\u4E8B\u60C5\u3002",
      q8SliderTitle: "\u4F60\u7684\u6838\u5FC3\u5E26\u9886\u4F18\u52BF",
      q8SliderTooltip: "\u54EA\u4E00\u7C7B\u80FD\u529B\u66F4\u63A5\u8FD1\u4F60\u4F5C\u4E3A\u5730\u966A\u6700\u81EA\u7136\u3001\u6700\u6838\u5FC3\u7684\u4F18\u52BF\uFF1F",
      q8Range1: "1 \u2014 \u672C\u5730\u77E5\u8BC6\u3001\u884C\u7A0B\u89C4\u5212\u4E0E\u5B9E\u7528\u80FD\u529B",
      q8Range9: "9 \u2014 \u6C9F\u901A\u4E92\u52A8\u3001\u89C2\u5BDF\u4E0E\u7167\u987E\u5BA2\u4EBA\u7684\u80FD\u529B",
      q9Question: "Q7. \u4F60\u4E3A\u4EC0\u4E48\u60F3\u6210\u4E3A YaoTu \u5730\u966A\uFF1F\u4F60\u5E0C\u671B\u5E26\u9886\u4F53\u9A8C\u4E3A\u4F60\u5E26\u6765\u4EC0\u4E48\u53EF\u80FD\uFF1F",
      q9Placeholder: "\u5206\u4EAB\u4F60\u7684\u52A8\u673A\uFF0C\u4EE5\u53CA\u4F60\u5E0C\u671B guiding \u4E3A\u4F60\u5E26\u6765\u4EC0\u4E48\u53EF\u80FD...",
      q9HelperText: "\u8FD9\u9898\u6CA1\u6709\u6807\u51C6\u7B54\u6848\u3002\u6211\u4EEC\u53EA\u662F\u60F3\u4E86\u89E3\u4F60\u7684\u52A8\u673A\uFF0C\u4EE5\u53CA\u4F60\u5E0C\u671B\u4ECE\u5E26\u9886\u4F53\u9A8C\u4E2D\u83B7\u5F97\u4EC0\u4E48\u3002"
    }
  }
};

// src/i18n/index.ts
var guideFormEnglishMessages = en_default;
var guideFormChineseMessages = zh_CN_default;
var messagesByLocale = {
  en: en_default,
  "zh-CN": zh_CN_default,
  zh: zh_CN_default
};
var getNestedMessage = (messages, key) => {
  let current = messages;
  for (const segment of key.split(".")) {
    if (!current || typeof current !== "object" || !(segment in current)) return void 0;
    current = current[segment];
  }
  return typeof current === "string" ? current : void 0;
};
var createGuideFormTranslator = (locale = "en") => {
  const messages = messagesByLocale[locale] ?? messagesByLocale.en;
  return (key) => getNestedMessage(messages, key) ?? key;
};

// src/components/EvaluationSlider.tsx
var import_jsx_runtime2 = require("react/jsx-runtime");
var valueFromPointer = (event) => {
  const rect = event.currentTarget.getBoundingClientRect();
  const ratio = Math.min(1, Math.max(0, (event.clientX - rect.left) / rect.width));
  return Math.round(ratio * 8) + 1;
};
var EvaluationSlider = ({
  title,
  tooltip,
  instruction,
  unselectedLabel,
  rangeStart,
  rangeEnd,
  value,
  onChange,
  ui
}) => {
  const {
    Slider,
    Tooltip,
    TooltipContent,
    TooltipProvider,
    TooltipTrigger,
    Info
  } = ui;
  const hasValue = typeof value === "number";
  const position = hasValue ? Math.min(97, Math.max(3, (value - 1) / 8 * 100)) : 50;
  const tooltipEnabled = Tooltip && TooltipContent && TooltipProvider && TooltipTrigger && Info;
  const infoButton = tooltipEnabled ? /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(TooltipProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(Tooltip, { children: [
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(TooltipTrigger, { asChild: true, children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
      "button",
      {
        type: "button",
        className: "text-gray-400 transition-colors hover:text-gray-600 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary",
        "aria-label": tooltip,
        children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(Info, { className: "h-4 w-4" })
      }
    ) }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(TooltipContent, { className: "max-w-xs text-sm leading-relaxed", children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { children: tooltip }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { className: "mt-1 text-xs opacity-80", children: instruction })
    ] })
  ] }) }) : null;
  return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "border-t border-gray-200 pt-5 dark:border-gray-700", children: [
    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { className: "text-sm font-semibold text-gray-800 dark:text-gray-100", children: title }),
      infoButton
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "mt-5", children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { className: "relative mb-2 h-5", "aria-live": "polite", children: hasValue ? /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
        "span",
        {
          className: "absolute -translate-x-1/2 rounded bg-primary px-2 py-0.5 text-xs font-semibold text-primary-foreground",
          style: { left: `${position}%` },
          children: value
        }
      ) : /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { className: "absolute left-1/2 -translate-x-1/2 text-xs text-gray-400", children: unselectedLabel }) }),
      hasValue ? /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
        Slider,
        {
          min: 1,
          max: 9,
          step: 1,
          value: [value],
          onValueChange: ([nextValue]) => onChange(nextValue),
          "aria-label": title
        }
      ) : /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
        "button",
        {
          type: "button",
          className: "relative flex h-7 w-full cursor-pointer items-center focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2",
          onClick: (event) => onChange(event.detail === 0 ? 5 : valueFromPointer(event)),
          "aria-label": `${title}: ${unselectedLabel}`,
          children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { className: "h-1.5 w-full rounded-full bg-slate-200 dark:bg-slate-700" })
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "mt-2 grid grid-cols-2 gap-4 text-xs leading-5 text-gray-500 dark:text-gray-300", children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { className: "text-left", children: rangeStart }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { className: "text-right", children: rangeEnd })
      ] })
    ] })
  ] });
};

// src/components/Step2SelfAssessment.tsx
var import_jsx_runtime3 = require("react/jsx-runtime");
var QuestionCard = ({ children }) => /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "space-y-4 rounded-lg border border-gray-200 bg-[#F9FAFB] p-5 dark:border-gray-700 dark:bg-gray-800/40", children });
var Step2SelfAssessment = ({
  control,
  ui,
  t,
  locale = "en"
}) => {
  const {
    Checkbox,
    FormControl,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
    RadioGroup,
    RadioGroupItem
  } = ui;
  const translate = t ?? createGuideFormTranslator(locale);
  return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "space-y-[30px]", children: [
    /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "text-center", children: [
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("h3", { className: "mb-2 text-lg font-semibold text-gray-900 dark:text-white", children: translate("becomeGuide.step2.title") }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("p", { className: "text-sm text-gray-600 dark:text-white", children: translate("becomeGuide.step2.subtitle") })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(QuestionCard, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
        FormField,
        {
          control,
          name: "assessmentQ1",
          render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(FormItem, { children: [
            /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(FormLabel, { className: "text-lg font-semibold text-gray-900 dark:text-white", children: translate("becomeGuide.step2.q1Question") }),
            /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "space-y-3 pt-1", children: ASSESSMENT_Q1_OPTIONS.map((option) => {
              const id = `assessment-q1-${option}`;
              const selected = (field.value || []).includes(option);
              return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "flex items-start gap-3", children: [
                /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
                  Checkbox,
                  {
                    id,
                    checked: selected,
                    onCheckedChange: (checked) => field.onChange(
                      checked ? [...field.value || [], option] : (field.value || []).filter((value) => value !== option)
                    )
                  }
                ) }),
                /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("label", { htmlFor: id, className: "cursor-pointer text-sm leading-6 text-gray-700 dark:text-gray-200", children: translate(`becomeGuide.step2.q1Options.${option}`) })
              ] }, option);
            }) }),
            /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(FormMessage, {})
          ] })
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
        FormField,
        {
          control,
          name: "assessmentQ1Slider",
          render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
            EvaluationSlider,
            {
              ui,
              title: translate("becomeGuide.step2.q1SliderTitle"),
              tooltip: translate("becomeGuide.step2.q1SliderTooltip"),
              instruction: translate("becomeGuide.step2.sliderInstruction"),
              unselectedLabel: translate("becomeGuide.step2.sliderUnselected"),
              rangeStart: translate("becomeGuide.step2.q1Range1"),
              rangeEnd: translate("becomeGuide.step2.q1Range9"),
              value: field.value,
              onChange: field.onChange
            }
          )
        }
      )
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(QuestionCard, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
        FormField,
        {
          control,
          name: "assessmentQ3",
          render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(FormItem, { children: [
            /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(FormLabel, { className: "text-lg font-semibold text-gray-900 dark:text-white", children: translate("becomeGuide.step2.q3Question") }),
            /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(RadioGroup, { value: field.value || "", onValueChange: field.onChange, className: "pt-1", children: ASSESSMENT_Q3_OPTIONS.map((option) => {
              const id = `assessment-q3-${option}`;
              return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(RadioGroupItem, { id, value: option }),
                /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("label", { htmlFor: id, className: "cursor-pointer text-sm leading-6 text-gray-700 dark:text-gray-200", children: translate(`becomeGuide.step2.q3Options.${option}`) })
              ] }, option);
            }) }) }),
            /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(FormMessage, {})
          ] })
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
        FormField,
        {
          control,
          name: "assessmentQ3Slider",
          render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
            EvaluationSlider,
            {
              ui,
              title: translate("becomeGuide.step2.q3SliderTitle"),
              tooltip: translate("becomeGuide.step2.q3SliderTooltip"),
              instruction: translate("becomeGuide.step2.sliderInstruction"),
              unselectedLabel: translate("becomeGuide.step2.sliderUnselected"),
              rangeStart: translate("becomeGuide.step2.q3Range1"),
              rangeEnd: translate("becomeGuide.step2.q3Range9"),
              value: field.value,
              onChange: field.onChange
            }
          )
        }
      )
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(QuestionCard, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
        FormField,
        {
          control,
          name: "assessmentQ4",
          render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(FormItem, { children: [
            /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(FormLabel, { className: "text-lg font-semibold text-gray-900 dark:text-white", children: translate("becomeGuide.step2.q4Question") }),
            /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "space-y-3 pt-1", children: ASSESSMENT_Q4_OPTIONS.map((option) => {
              const id = `assessment-q4-${option}`;
              const selected = (field.value || []).includes(option);
              return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "flex items-start gap-3", children: [
                /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
                  Checkbox,
                  {
                    id,
                    checked: selected,
                    onCheckedChange: (checked) => field.onChange(
                      checked ? [...field.value || [], option] : (field.value || []).filter((value) => value !== option)
                    )
                  }
                ) }),
                /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("label", { htmlFor: id, className: "cursor-pointer text-sm leading-6 text-gray-700 dark:text-gray-200", children: translate(`becomeGuide.step2.q4Options.${option}`) })
              ] }, option);
            }) }),
            /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(FormMessage, {})
          ] })
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
        FormField,
        {
          control,
          name: "assessmentQ4Slider",
          render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
            EvaluationSlider,
            {
              ui,
              title: translate("becomeGuide.step2.q4SliderTitle"),
              tooltip: translate("becomeGuide.step2.q4SliderTooltip"),
              instruction: translate("becomeGuide.step2.sliderInstruction"),
              unselectedLabel: translate("becomeGuide.step2.sliderUnselected"),
              rangeStart: translate("becomeGuide.step2.q4Range1"),
              rangeEnd: translate("becomeGuide.step2.q4Range9"),
              value: field.value,
              onChange: field.onChange
            }
          )
        }
      )
    ] })
  ] });
};

// src/components/Step3PersonalizedQuestions.tsx
var import_react_hook_form2 = require("react-hook-form");
var import_jsx_runtime4 = require("react/jsx-runtime");
var QuestionCard2 = ({ children }) => /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("div", { className: "space-y-4 rounded-lg border border-gray-200 bg-[#F9FAFB] p-5 dark:border-gray-700 dark:bg-gray-800/40", children });
var CharacterCount = ({ value, max }) => /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("p", { className: "text-right text-xs text-gray-400 dark:text-gray-300", children: [
  value.length,
  "/",
  max
] });
var Step3PersonalizedQuestions = ({
  control,
  ui,
  t,
  locale = "en"
}) => {
  const {
    Checkbox,
    FormControl,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
    RadioGroup,
    RadioGroupItem,
    Textarea
  } = ui;
  const translate = t ?? createGuideFormTranslator(locale);
  const watchControl = control;
  const q8Example = (0, import_react_hook_form2.useWatch)({ control: watchControl, name: "personalizedQ8Example" }) || "";
  const q9Answer = (0, import_react_hook_form2.useWatch)({ control: watchControl, name: "personalizedQ9" }) || "";
  return /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "space-y-[30px]", children: [
    /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "text-center", children: [
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("h3", { className: "mb-2 text-lg font-semibold text-gray-900 dark:text-white", children: translate("becomeGuide.step3.title") }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("p", { className: "text-sm text-gray-600 dark:text-white", children: translate("becomeGuide.step3.subtitle") })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(QuestionCard2, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
        FormField,
        {
          control,
          name: "personalizedQ6",
          render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(FormItem, { children: [
            /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(FormLabel, { className: "text-lg font-semibold text-gray-900 dark:text-white", children: translate("becomeGuide.step3.q6Question") }),
            /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("div", { className: "space-y-3 pt-1", children: PERSONALIZED_Q6_OPTIONS.map((option) => {
              const id = `personalized-q6-${option}`;
              const selected = (field.value || []).includes(option);
              return /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "flex items-start gap-3", children: [
                /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
                  Checkbox,
                  {
                    id,
                    checked: selected,
                    onCheckedChange: (checked) => field.onChange(
                      checked ? [...field.value || [], option] : (field.value || []).filter((value) => value !== option)
                    )
                  }
                ) }),
                /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("label", { htmlFor: id, className: "cursor-pointer text-sm leading-6 text-gray-700 dark:text-gray-200", children: translate(`becomeGuide.step3.q6Options.${option}`) })
              ] }, option);
            }) }),
            /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(FormMessage, {})
          ] })
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
        FormField,
        {
          control,
          name: "personalizedQ6Slider",
          render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
            EvaluationSlider,
            {
              ui,
              title: translate("becomeGuide.step3.q6SliderTitle"),
              tooltip: translate("becomeGuide.step3.q6SliderTooltip"),
              instruction: translate("becomeGuide.step3.sliderInstruction"),
              unselectedLabel: translate("becomeGuide.step3.sliderUnselected"),
              rangeStart: translate("becomeGuide.step3.q6Range1"),
              rangeEnd: translate("becomeGuide.step3.q6Range9"),
              value: field.value,
              onChange: field.onChange
            }
          )
        }
      )
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(QuestionCard2, { children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
      FormField,
      {
        control,
        name: "personalizedQ7",
        render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(FormItem, { children: [
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(FormLabel, { className: "text-lg font-semibold text-gray-900 dark:text-white", children: translate("becomeGuide.step3.q7Question") }),
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(RadioGroup, { value: field.value || "", onValueChange: field.onChange, className: "pt-1", children: PERSONALIZED_Q7_OPTIONS.map((option) => {
            const id = `personalized-q7-${option}`;
            return /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(RadioGroupItem, { id, value: option }),
              /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("label", { htmlFor: id, className: "cursor-pointer text-sm leading-6 text-gray-700 dark:text-gray-200", children: translate(`becomeGuide.step3.q7Options.${option}`) })
            ] }, option);
          }) }) }),
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(FormMessage, {})
        ] })
      }
    ) }),
    /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(QuestionCard2, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
        FormField,
        {
          control,
          name: "personalizedQ8Strengths",
          render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(FormItem, { children: [
            /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(FormLabel, { className: "text-lg font-semibold text-gray-900 dark:text-white", children: translate("becomeGuide.step3.q8Question") }) }),
            /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("div", { className: "grid gap-3 pt-1 sm:grid-cols-2", children: PERSONALIZED_Q8_OPTIONS.map((option) => {
              const id = `personalized-q8-${option}`;
              const selected = (field.value || []).includes(option);
              const selectionLimitReached = (field.value || []).length >= 3 && !selected;
              return /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "flex items-start gap-3", children: [
                /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
                  Checkbox,
                  {
                    id,
                    checked: selected,
                    disabled: selectionLimitReached,
                    onCheckedChange: (checked) => field.onChange(
                      checked ? [...field.value || [], option] : (field.value || []).filter((value) => value !== option)
                    )
                  }
                ) }),
                /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
                  "label",
                  {
                    htmlFor: id,
                    className: `text-sm leading-6 ${selectionLimitReached ? "cursor-not-allowed text-gray-400" : "cursor-pointer text-gray-700 dark:text-gray-200"}`,
                    children: translate(`becomeGuide.step3.q8Options.${option}`)
                  }
                )
              ] }, option);
            }) }),
            /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(FormMessage, {})
          ] })
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
        FormField,
        {
          control,
          name: "personalizedQ8Example",
          render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(FormItem, { children: [
            /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(FormLabel, { className: "text-sm font-medium text-gray-800 dark:text-gray-100", children: translate("becomeGuide.step3.q8ExampleQuestion") }),
            /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
              Textarea,
              {
                maxLength: 100,
                placeholder: translate("becomeGuide.step3.q8ExamplePlaceholder"),
                className: "min-h-[90px]",
                value: field.value || "",
                onChange: field.onChange
              }
            ) }),
            /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(CharacterCount, { value: q8Example, max: 100 }),
            /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(FormMessage, {})
          ] })
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
        FormField,
        {
          control,
          name: "personalizedQ8Slider",
          render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
            EvaluationSlider,
            {
              ui,
              title: translate("becomeGuide.step3.q8SliderTitle"),
              tooltip: translate("becomeGuide.step3.q8SliderTooltip"),
              instruction: translate("becomeGuide.step3.sliderInstruction"),
              unselectedLabel: translate("becomeGuide.step3.sliderUnselected"),
              rangeStart: translate("becomeGuide.step3.q8Range1"),
              rangeEnd: translate("becomeGuide.step3.q8Range9"),
              value: field.value,
              onChange: field.onChange
            }
          )
        }
      )
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(QuestionCard2, { children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
      FormField,
      {
        control,
        name: "personalizedQ9",
        render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(FormItem, { children: [
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(FormLabel, { className: "text-lg font-semibold text-gray-900 dark:text-white", children: translate("becomeGuide.step3.q9Question") }),
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("p", { className: "text-sm leading-6 text-gray-600 dark:text-gray-300", children: translate("becomeGuide.step3.q9HelperText") }),
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
            Textarea,
            {
              maxLength: 600,
              placeholder: translate("becomeGuide.step3.q9Placeholder"),
              className: "min-h-[120px]",
              value: field.value || "",
              onChange: field.onChange
            }
          ) }),
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(CharacterCount, { value: q9Answer, max: 600 }),
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(FormMessage, {})
        ] })
      }
    ) })
  ] });
};

// src/components/Step4ServicePreferences.tsx
var import_react3 = require("react");
var import_react_intl2 = require("react-intl");
var import_jsx_runtime5 = require("react/jsx-runtime");
var Step4ServicePreferences = ({
  control,
  ui,
  serviceCategories: propServiceCategories,
  targetGroups = [],
  onLoadServiceCategories
}) => {
  const intl = (0, import_react_intl2.useIntl)();
  const {
    FormField,
    FormItem,
    FormLabel,
    FormControl,
    FormMessage,
    Input,
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
    Checkbox,
    Badge,
    Separator,
    Card,
    CardContent,
    CardHeader,
    CardTitle,
    Slider
  } = ui;
  const [serviceCategories, setServiceCategories] = (0, import_react3.useState)(propServiceCategories || []);
  (0, import_react3.useEffect)(() => {
    console.log("Step4ServicePreferences: serviceCategories\u72B6\u6001\u5DF2\u66F4\u65B0:", serviceCategories);
  }, [serviceCategories]);
  const [loading, setLoading] = (0, import_react3.useState)(false);
  (0, import_react3.useEffect)(() => {
    if (propServiceCategories) {
      console.log("Step4ServicePreferences: \u4ECEprops\u8BBE\u7F6EserviceCategories:", propServiceCategories);
      setServiceCategories(propServiceCategories);
      return;
    }
    if (onLoadServiceCategories) {
      const fetchServiceCategories = async () => {
        try {
          setLoading(true);
          const data = await onLoadServiceCategories();
          console.log("Step4ServicePreferences: \u4ECEAPI\u52A0\u8F7DserviceCategories\u6210\u529F:", data);
          setServiceCategories(data);
        } catch (error) {
          console.error("Failed to fetch service categories:", error);
        } finally {
          setLoading(false);
        }
      };
      fetchServiceCategories();
    }
  }, [propServiceCategories, onLoadServiceCategories]);
  return /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "space-y-8", children: [
    /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(Card, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(CardTitle, { className: "text-base", children: [
        intl.formatMessage({ id: "becomeGuide.step4.targetGroup" }),
        " *"
      ] }) }),
      /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(CardContent, { children: /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
        FormField,
        {
          control,
          name: "targetGroup",
          render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(FormItem, { children: [
            /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "grid grid-cols-2 md:grid-cols-3 gap-3", children: targetGroups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(
              "div",
              {
                className: "flex items-center space-x-2",
                children: [
                  /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
                    Checkbox,
                    {
                      id: `target-${group.value}`,
                      checked: field.value?.includes(group.value) || false,
                      onCheckedChange: (checked) => {
                        const currentValues = field.value || [];
                        if (checked) {
                          field.onChange([...currentValues, group.value]);
                        } else {
                          field.onChange(
                            currentValues.filter((val) => val !== group.value)
                          );
                        }
                      }
                    }
                  ),
                  /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
                    "label",
                    {
                      htmlFor: `target-${group.value}`,
                      className: "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70",
                      children: intl.formatMessage({ id: `becomeGuide.step4.targetGroupOptions.${group.value}` })
                    }
                  )
                ]
              },
              group.value
            )) }) }),
            /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(FormMessage, {})
          ] })
        }
      ) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(Card, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(CardTitle, { className: "text-base", children: [
        intl.formatMessage({ id: "becomeGuide.step4.serviceItems" }),
        " *"
      ] }) }),
      /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(CardContent, { children: loading ? /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "text-center py-4", children: intl.formatMessage({ id: "becomeGuide.step4.loadingCategories" }) }) : /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
        FormField,
        {
          control,
          name: "serviceSelections",
          render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(FormItem, { children: [
            /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "space-y-4", children: serviceCategories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "space-y-2", children: [
              /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("h4", { className: "font-medium text-sm text-gray-700", children: intl.locale === "zh-CN" ? category.nameCn : category.nameEn }),
              /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "grid grid-cols-2 md:grid-cols-3 gap-2", children: category.subcategories.map((subcategory) => /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(
                "div",
                {
                  className: "flex items-center space-x-2",
                  children: [
                    /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
                      Checkbox,
                      {
                        id: `service-${subcategory.id}`,
                        checked: field.value?.includes(subcategory.id) || false,
                        onCheckedChange: (checked) => {
                          const currentValues = field.value || [];
                          if (checked) {
                            field.onChange([...currentValues, subcategory.id]);
                          } else {
                            field.onChange(
                              currentValues.filter((val) => val !== subcategory.id)
                            );
                          }
                        }
                      }
                    ),
                    /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
                      "label",
                      {
                        htmlFor: `service-${subcategory.id}`,
                        className: "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70",
                        children: intl.locale === "zh-CN" ? subcategory.nameCn : subcategory.nameEn
                      }
                    )
                  ]
                },
                subcategory.id
              )) })
            ] }, category.id)) }) }),
            /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(FormMessage, {})
          ] })
        }
      ) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(Card, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(CardTitle, { className: "text-base", children: intl.formatMessage({ id: "becomeGuide.step4.serviceRange" }) }) }),
      /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(CardContent, { children: /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
          FormField,
          {
            control,
            name: "minPeople",
            render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(FormItem, { children: [
              /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(FormLabel, { children: intl.formatMessage({ id: "becomeGuide.step4.minPeople" }) }),
              /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
                Input,
                {
                  type: "number",
                  min: "1",
                  max: "50",
                  value: field.value || "",
                  onChange: (e) => field.onChange(parseInt(e.target.value) || 1)
                }
              ) }),
              /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(FormMessage, {})
            ] })
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
          FormField,
          {
            control,
            name: "maxPeople",
            render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(FormItem, { children: [
              /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(FormLabel, { children: intl.formatMessage({ id: "becomeGuide.step4.maxPeople" }) }),
              /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
                Input,
                {
                  type: "number",
                  min: "1",
                  max: "50",
                  value: field.value || "",
                  onChange: (e) => field.onChange(parseInt(e.target.value) || 10)
                }
              ) }),
              /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(FormMessage, {})
            ] })
          }
        )
      ] }) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(Card, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(CardTitle, { className: "text-base", children: intl.formatMessage({ id: "becomeGuide.step4.serviceDuration" }) }) }),
      /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(CardContent, { children: /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
          FormField,
          {
            control,
            name: "minDuration",
            render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(FormItem, { children: [
              /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(FormLabel, { children: intl.formatMessage({ id: "becomeGuide.step4.minDuration" }) }),
              /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
                Input,
                {
                  type: "number",
                  min: "1",
                  max: "24",
                  value: field.value || "",
                  onChange: (e) => field.onChange(parseInt(e.target.value) || 2)
                }
              ) }),
              /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(FormMessage, {})
            ] })
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
          FormField,
          {
            control,
            name: "maxDuration",
            render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(FormItem, { children: [
              /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(FormLabel, { children: intl.formatMessage({ id: "becomeGuide.step4.maxDuration" }) }),
              /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
                Input,
                {
                  type: "number",
                  min: "1",
                  max: "24",
                  value: field.value || "",
                  onChange: (e) => field.onChange(parseInt(e.target.value) || 8)
                }
              ) }),
              /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(FormMessage, {})
            ] })
          }
        )
      ] }) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(Card, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(CardTitle, { className: "text-base", children: intl.formatMessage({ id: "becomeGuide.step4.pricing" }) }) }),
      /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(CardContent, { children: /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "space-y-4", children: [
        /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
            FormField,
            {
              control,
              name: "basicPricePerHour",
              render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(FormItem, { children: [
                /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(FormLabel, { children: intl.formatMessage({ id: "becomeGuide.step4.basicPricePerHour" }) }),
                /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
                  Input,
                  {
                    type: "number",
                    min: "0",
                    step: "0.01",
                    value: field.value || "",
                    onChange: (e) => field.onChange(parseFloat(e.target.value) || 0),
                    placeholder: "30.00"
                  }
                ) }),
                /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(FormMessage, {})
              ] })
            }
          ),
          /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
            FormField,
            {
              control,
              name: "additionalPricePerPerson",
              render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(FormItem, { children: [
                /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(FormLabel, { children: intl.formatMessage({ id: "becomeGuide.step4.additionalPricePerPerson" }) }),
                /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(FormControl, { children: /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
                  Input,
                  {
                    type: "number",
                    min: "0",
                    step: "0.01",
                    value: field.value || "",
                    onChange: (e) => field.onChange(parseFloat(e.target.value) || 0),
                    placeholder: "5.00"
                  }
                ) }),
                /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(FormMessage, {})
              ] })
            }
          )
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "space-y-2", children: [
          /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(FormLabel, { children: intl.formatMessage({ id: "becomeGuide.step4.currency" }) }),
          /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "flex h-10 items-center rounded-md border border-input bg-muted/40 px-3 text-sm", children: "USD ($)" })
        ] })
      ] }) })
    ] })
  ] });
};

// src/components/ApplicationPreview.tsx
var import_lucide_react = require("lucide-react");
var import_jsx_runtime6 = require("react/jsx-runtime");
var targetGroupLabelKeys = {
  individual: "becomeGuide.preview.individual",
  couple: "becomeGuide.preview.couple",
  family: "becomeGuide.preview.family",
  group: "becomeGuide.preview.group",
  child: "becomeGuide.preview.child",
  elderly: "becomeGuide.preview.elderly",
  business: "becomeGuide.preview.business"
};
var ApplicationPreview = ({
  formData,
  missingFields,
  confirmationChecked,
  setConfirmationChecked,
  onBackToForm,
  onSubmit,
  isSubmitting,
  requiresAccountBeforeSubmit = false,
  validateFormCompleteness: validateFormCompleteness3,
  setMissingFields,
  destinations = [],
  ui,
  intl
}) => {
  const { Card, CardContent, Button, Checkbox } = ui;
  const t = (id, defaultMessage = id, values) => intl?.formatMessage({ id, defaultMessage }, values) ?? defaultMessage;
  const ph = t("becomeGuide.preview.placeholder", "-");
  const list = (values) => values?.length ? values.join(t("becomeGuide.preview.fieldSeparator", ", ")) : ph;
  const formatMissingField = (field) => {
    const descriptor = getMissingFieldMessageDescriptor(field);
    const messages = intl?.messages;
    const messageId = messages && Object.prototype.hasOwnProperty.call(messages, descriptor.id) ? descriptor.id : messages && Object.prototype.hasOwnProperty.call(messages, field) ? field : descriptor.id;
    return t(messageId, descriptor.defaultMessage);
  };
  const destinationById = new Map(destinations.map((destination) => [destination.id, destination]));
  const destinationLabel = (destination) => {
    const locale = intl?.locale ?? "en";
    if (locale.startsWith("zh")) {
      return destination.nameZhCn || destination.nameEn || destination.nameJa || destination.slug;
    }
    if (locale.startsWith("ja")) {
      return destination.nameJa || destination.nameEn || destination.nameZhCn || destination.slug;
    }
    return destination.nameEn || destination.nameJa || destination.nameZhCn || destination.slug;
  };
  const serviceAreaLabels = [
    ...formData.serviceAreas?.map((area) => destinationLabel(area)) ?? [],
    ...(formData.serviceAreaDestinationIds ?? []).map((id) => destinationById.get(Number(id))).filter(Boolean).map((destination) => destinationLabel(destination))
  ];
  const customProposalLabels = formData.customServiceAreaProposals ?? [];
  const serviceAreaValue = Array.from(/* @__PURE__ */ new Set([...serviceAreaLabels, ...customProposalLabels])).join(
    t("becomeGuide.preview.fieldSeparator", ", ")
  ) || ph;
  const handleSubmit = () => {
    if (!confirmationChecked) return;
    const missing = validateFormCompleteness3(formData);
    if (missing.length > 0) {
      setMissingFields(missing);
      return;
    }
    setMissingFields([]);
    onSubmit();
  };
  const optionLabels = (step, question, values) => values?.length ? values.map((value) => t(`becomeGuide.step${step}.${question}Options.${value}`, value)).join(", ") : ph;
  const singleOption = (step, question, value) => value ? t(`becomeGuide.step${step}.${question}Options.${value}`, value) : ph;
  const score = (value) => value == null ? ph : t("becomeGuide.preview.scoreOutOfNine", "{score}/9", { score: value });
  const row = (label, value) => /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("div", { children: [
    /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("label", { className: "text-sm font-medium text-gray-500", children: label }),
    /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("p", { className: "text-gray-900 whitespace-pre-wrap", children: value || ph })
  ] });
  return /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("div", { className: "min-h-screen bg-yellow-50 py-12", children: /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("div", { className: "max-w-4xl mx-auto px-4", children: [
    /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("div", { className: "mb-8", children: [
      /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("h1", { className: "text-3xl font-bold text-gray-900 mb-2", children: t("becomeGuide.preview.title", "Application Preview") }),
      /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("p", { className: "text-gray-600 mb-4", children: t(
        "becomeGuide.preview.subtitle",
        "Review your application details before submitting."
      ) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(Card, { className: "shadow-lg", children: /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)(CardContent, { id: "print-root", className: "p-6 space-y-8", children: [
      /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("section", { children: [
        /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("h3", { className: "text-lg font-semibold text-gray-900 mb-4 border-b pb-2", children: t("becomeGuide.preview.basicInfo", "Basic Information") }),
        /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
          row(t("becomeGuide.preview.name", "Name"), formData.name),
          row(
            t("becomeGuide.preview.age", "Age"),
            formData.age ? t("becomeGuide.preview.ageValue", "{years} years old", {
              years: formData.age
            }) : ph
          ),
          row(
            t("becomeGuide.preview.gender", "Gender"),
            formData.sex === "Male" ? t("becomeGuide.preview.male", "Male") : formData.sex === "Female" ? t("becomeGuide.preview.female", "Female") : t("becomeGuide.preview.preferNotToSay", "Prefer not to say")
          ),
          row(t("becomeGuide.preview.mbti", "MBTI"), formData.mbti),
          /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("div", { className: "md:col-span-2", children: row(t("becomeGuide.preview.socialProfile", "Social profile"), formData.socialProfile) })
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("section", { children: [
        /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("h3", { className: "text-lg font-semibold text-gray-900 mb-4 border-b pb-2", children: t("becomeGuide.preview.serviceInfo", "Service Information") }),
        /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
          row(t("becomeGuide.preview.serviceAreas", "Service Areas"), serviceAreaValue),
          row(
            t("becomeGuide.preview.residenceStartDate", "Residence in Japan since"),
            formData.residenceStartDate
          ),
          /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("div", { className: "md:col-span-2", children: row(t("becomeGuide.preview.residenceInfo", "Address / area"), formData.residenceInfo) }),
          row(t("becomeGuide.preview.residenceZipcode", "Postal code"), formData.residenceZipcode),
          row(t("becomeGuide.preview.occupation", "Occupation"), formData.occupation)
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("section", { children: [
        /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("h3", { className: "text-lg font-semibold text-gray-900 mb-4 border-b pb-2", children: t("becomeGuide.preview.qualifications", "Qualifications & Experience") }),
        /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("div", { className: "space-y-4", children: [
          row(t("becomeGuide.preview.languages", "Languages"), list(formData.languages)),
          /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
            row(t("becomeGuide.preview.guideExperience", "Guide experience"), formData.experienceDuration),
            row(t("becomeGuide.preview.guideSessions", "Guide sessions"), formData.experienceSession)
          ] })
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("section", { children: [
        /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("h3", { className: "text-lg font-semibold text-gray-900 mb-4 border-b pb-2", children: t("becomeGuide.preview.selfAssessment", "Self Assessment") }),
        /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("div", { className: "space-y-4", children: [
          row(t("becomeGuide.step2.q1Question", "Question 1"), optionLabels(2, "q1", formData.assessmentQ1)),
          row(t("becomeGuide.step2.q1SliderTitle", "Question 1 score"), score(formData.assessmentQ1Slider)),
          row(t("becomeGuide.step2.q3Question", "Question 2"), singleOption(2, "q3", formData.assessmentQ3)),
          row(t("becomeGuide.step2.q3SliderTitle", "Question 2 score"), score(formData.assessmentQ3Slider)),
          row(t("becomeGuide.step2.q4Question", "Question 3"), optionLabels(2, "q4", formData.assessmentQ4)),
          row(t("becomeGuide.step2.q4SliderTitle", "Question 3 score"), score(formData.assessmentQ4Slider))
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("section", { children: [
        /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("h3", { className: "text-lg font-semibold text-gray-900 mb-4 border-b pb-2", children: t("becomeGuide.preview.personalizedQuestions", "Personalized Questions") }),
        /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("div", { className: "space-y-4", children: [
          row(t("becomeGuide.step3.q6Question", "Question 4"), optionLabels(3, "q6", formData.personalizedQ6)),
          row(t("becomeGuide.step3.q6SliderTitle", "Question 4 score"), score(formData.personalizedQ6Slider)),
          row(t("becomeGuide.step3.q7Question", "Question 5"), singleOption(3, "q7", formData.personalizedQ7)),
          row(t("becomeGuide.step3.q8Question", "Question 6"), optionLabels(3, "q8", formData.personalizedQ8Strengths)),
          row(t("becomeGuide.step3.q8SliderTitle", "Question 6 score"), score(formData.personalizedQ8Slider)),
          row(t("becomeGuide.step3.q8ExampleQuestion", "Question 6 example"), formData.personalizedQ8Example),
          row(t("becomeGuide.step3.q9Question", "Question 7"), formData.personalizedQ9)
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("section", { children: [
        /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("h3", { className: "text-lg font-semibold text-gray-900 mb-4 border-b pb-2", children: t("becomeGuide.preview.servicePreferences", "Service Preferences") }),
        /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("div", { className: "space-y-4", children: [
          row(
            t("becomeGuide.preview.targetGroup", "Target Group"),
            formData.targetGroup?.length ? formData.targetGroup.map((group) => t(targetGroupLabelKeys[group] ?? group, group)).join(", ") : ph
          ),
          /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
            row(
              t("becomeGuide.preview.serviceRange", "Service Group Size Range"),
              formData.minPeople && formData.maxPeople ? `${formData.minPeople} - ${formData.maxPeople} ${t("becomeGuide.preview.people", "people")}` : ph
            ),
            row(
              t("becomeGuide.preview.serviceDuration", "Service Duration Range"),
              formData.minDuration && formData.maxDuration ? `${formData.minDuration} - ${formData.maxDuration} ${t("becomeGuide.preview.hours", "hours")}` : ph
            )
          ] }),
          row(
            t("becomeGuide.preview.basicPrice", "Basic Hourly Rate"),
            formData.basicPricePerHour !== void 0 ? `${formData.basicPricePerHour.toFixed(2)} USD/${t("becomeGuide.preview.hours", "hours")}` : ph
          ),
          row(
            t("becomeGuide.preview.additionalPrice", "Additional Hourly Rate"),
            formData.additionalPricePerPerson !== void 0 ? `${formData.additionalPricePerPerson.toFixed(2)} USD/${t("becomeGuide.preview.people", "people")}/${t("becomeGuide.preview.hours", "hours")}` : ph
          ),
          row(
            t("becomeGuide.preview.serviceItems", "Services Provided"),
            formData.serviceSelections?.length ? t("becomeGuide.preview.selectedItems", "Selected {count} service items", {
              count: formData.serviceSelections.length
            }) : t("becomeGuide.preview.notSelected", "Not selected")
          )
        ] })
      ] }),
      missingFields.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("div", { className: "bg-red-50 p-4 rounded-lg border-l-4 border-red-500 mb-6", children: /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("p", { className: "text-sm text-red-700", children: [
        /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("strong", { children: t("becomeGuide.preview.missingFields", "The following information is incomplete:") }),
        /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("br", {}),
        missingFields.map(formatMissingField).join(t("becomeGuide.preview.fieldSeparator", ", "))
      ] }) }),
      /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("div", { className: "bg-gray-50 p-6 rounded-lg border-t-4 border-yellow-500", children: /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("div", { className: "flex items-start space-x-3", children: [
        /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(
          Checkbox,
          {
            id: "confirmation",
            checked: confirmationChecked,
            onCheckedChange: (checked) => setConfirmationChecked(checked === true),
            className: "mt-1"
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("label", { htmlFor: "confirmation", className: "text-sm text-gray-700 leading-relaxed", children: t(
          "becomeGuide.preview.previewDeclaration",
          "I confirm that all information above is true and accurate."
        ) })
      ] }) }),
      requiresAccountBeforeSubmit && /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("div", { className: "rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900", children: [
        /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("p", { className: "font-semibold", children: t("becomeGuide.preview.accountRequiredTitle", "Account verification required before submission") }),
        /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("p", { className: "mt-1 leading-relaxed", children: t(
          "becomeGuide.preview.accountRequiredDescription",
          "After you continue, you will create or sign in to an account and verify your email so you can return to this application later. Keep this browser open; your draft is saved locally and will resume after verification."
        ) })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("div", { className: "flex justify-between items-center pt-6 border-t", children: [
        /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)(Button, { type: "button", variant: "outline", onClick: onBackToForm, children: [
          /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(import_lucide_react.ChevronLeft, { className: "h-4 w-4 mr-1" }),
          t("becomeGuide.preview.backToEdit", "Back to Edit")
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(
          Button,
          {
            type: "button",
            onClick: handleSubmit,
            disabled: isSubmitting,
            className: "bg-green-600 hover:bg-green-700",
            children: isSubmitting ? t("becomeGuide.preview.submitting", "Submitting...") : t("becomeGuide.preview.submitApplication", "Confirm Submit Application")
          }
        )
      ] })
    ] }) })
  ] }) });
};

// src/components/FormNavigation.tsx
var import_react_intl3 = require("react-intl");
var import_jsx_runtime7 = require("react/jsx-runtime");
var FormNavigation = ({
  currentPage,
  onPrevPage,
  onNextPage,
  onGoToPreview,
  onSaveDraft,
  isSavingDraft,
  isNavigationDisabled = false,
  ui
}) => {
  const intl = (0, import_react_intl3.useIntl)();
  const { Button, Progress, ChevronLeft: ChevronLeft2, ChevronRight, Save } = ui;
  return /* @__PURE__ */ (0, import_jsx_runtime7.jsxs)("div", { className: "space-y-4 pt-6 border-t", children: [
    /* @__PURE__ */ (0, import_jsx_runtime7.jsxs)("div", { className: "flex justify-between items-center", children: [
      /* @__PURE__ */ (0, import_jsx_runtime7.jsxs)("div", { className: "flex-1 mr-4", children: [
        /* @__PURE__ */ (0, import_jsx_runtime7.jsxs)("div", { className: "flex justify-between text-sm text-gray-500 mb-2", children: [
          /* @__PURE__ */ (0, import_jsx_runtime7.jsx)("span", { children: intl.formatMessage({ id: "becomeGuide.progress.pageInfo" }, { current: currentPage, total: TOTAL_PAGES }) }),
          /* @__PURE__ */ (0, import_jsx_runtime7.jsx)("span", { children: intl.formatMessage({ id: "becomeGuide.progress.completion" }, { percentage: Math.round(currentPage / TOTAL_PAGES * 100) }) })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(
          Progress,
          {
            value: currentPage / TOTAL_PAGES * 100,
            className: "h-2"
          }
        )
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime7.jsxs)(
        Button,
        {
          type: "button",
          variant: "outline",
          onClick: onSaveDraft,
          disabled: isSavingDraft || isNavigationDisabled,
          className: "flex items-center gap-2 ml-4",
          children: [
            Save && /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(Save, { className: "h-4 w-4" }),
            isSavingDraft ? intl.formatMessage({ id: "becomeGuide.navigation.saving" }) : intl.formatMessage({ id: "becomeGuide.navigation.saveDraft" })
          ]
        }
      )
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime7.jsxs)("div", { className: "flex justify-between items-center", children: [
      /* @__PURE__ */ (0, import_jsx_runtime7.jsx)("div", { className: "flex gap-2", children: currentPage > 1 && /* @__PURE__ */ (0, import_jsx_runtime7.jsxs)(
        Button,
        {
          type: "button",
          variant: "outline",
          onClick: onPrevPage,
          disabled: isNavigationDisabled,
          className: "flex items-center gap-2",
          children: [
            ChevronLeft2 && /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(ChevronLeft2, { className: "h-4 w-4" }),
            intl.formatMessage({ id: "becomeGuide.navigation.previous" })
          ]
        }
      ) }),
      /* @__PURE__ */ (0, import_jsx_runtime7.jsx)("div", { className: "flex gap-2", children: currentPage < TOTAL_PAGES ? /* @__PURE__ */ (0, import_jsx_runtime7.jsxs)(
        Button,
        {
          type: "button",
          onClick: onNextPage,
          disabled: isNavigationDisabled,
          className: "flex items-center gap-2",
          children: [
            intl.formatMessage({ id: "becomeGuide.navigation.next" }),
            ChevronRight && /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(ChevronRight, { className: "h-4 w-4" })
          ]
        }
      ) : /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(
        Button,
        {
          type: "button",
          onClick: onGoToPreview,
          disabled: isNavigationDisabled,
          className: "bg-green-600 hover:bg-green-700",
          children: intl.formatMessage({ id: "becomeGuide.navigation.preview" })
        }
      ) })
    ] })
  ] });
};

// src/hooks/usePDFGeneration.ts
var import_react4 = require("react");

// src/utils/pdfGenerator.ts
var import_html2pdf = __toESM(require("html2pdf.js"));
var defaultPDFOptions = {
  margin: [12, 12, 12, 12],
  // 12mm margins
  filename: "guide-application.pdf",
  image: { type: "jpeg", quality: 0.98 },
  html2canvas: {
    scale: 2,
    useCORS: true,
    allowTaint: true,
    backgroundColor: "#ffffff"
  },
  jsPDF: {
    unit: "mm",
    format: "a4",
    orientation: "portrait",
    compress: true
  },
  pagebreak: { mode: ["avoid-all"] }
};
async function generatePDFBlob(elementId, options = {}) {
  const printRoot = document.getElementById(elementId);
  if (!printRoot) {
    throw new Error(`Element with ID '${elementId}' not found`);
  }
  if (!printRoot.textContent?.trim()) {
    throw new Error("Element content is empty");
  }
  const mergedOptions = { ...defaultPDFOptions, ...options };
  console.log("\u{1F504} \u5F00\u59CB\u751F\u6210PDF...", { elementId, options: mergedOptions });
  const pdfWorker = (0, import_html2pdf.default)().set(mergedOptions).from(printRoot);
  const pdfBlob = await pdfWorker.outputPdf("blob");
  console.log("\u{1F4E5} PDF\u751F\u6210\u5B8C\u6210\uFF0C\u5927\u5C0F:", pdfBlob.size, "bytes");
  if (pdfBlob.size === 0) {
    throw new Error("Generated PDF file is empty");
  }
  return pdfBlob;
}
function downloadPDF(pdfBlob, filename) {
  const downloadUrl = URL.createObjectURL(pdfBlob);
  const downloadLink = document.createElement("a");
  downloadLink.href = downloadUrl;
  downloadLink.download = filename;
  document.body.appendChild(downloadLink);
  downloadLink.click();
  document.body.removeChild(downloadLink);
  setTimeout(() => URL.revokeObjectURL(downloadUrl), 1e3);
}
async function uploadPDF(pdfBlob, options) {
  const { applicationId, token, uploadUrl } = options;
  console.log("\u{1F4E4} \u5F00\u59CB\u4E0A\u4F20PDF\u5230\u670D\u52A1\u5668...", {
    size: pdfBlob.size,
    applicationId,
    uploadUrl
  });
  const pdfArrayBuffer = await pdfBlob.arrayBuffer();
  const requestHeaders = {
    Authorization: `Bearer ${token}`,
    "Content-Type": "application/pdf",
    "Content-Length": pdfArrayBuffer.byteLength.toString()
  };
  const uploadResponse = await fetch(uploadUrl, {
    method: "POST",
    headers: requestHeaders,
    body: pdfArrayBuffer
  });
  if (!uploadResponse.ok) {
    const errorText = await uploadResponse.text();
    console.error("\u{1F4E4} PDF\u4E0A\u4F20\u5931\u8D25:", {
      status: uploadResponse.status,
      statusText: uploadResponse.statusText,
      responseText: errorText
    });
    throw new Error(`Upload failed: ${uploadResponse.status} ${uploadResponse.statusText}`);
  }
  const uploadResult = await uploadResponse.json();
  console.log("\u2705 PDF\u4E0A\u4F20\u6210\u529F:", uploadResult.key);
  return uploadResult.key;
}
async function generateAndDownloadPDF(elementId, options = {}) {
  const pdfBlob = await generatePDFBlob(elementId, options);
  const filename = options.filename || "guide-application.pdf";
  downloadPDF(pdfBlob, filename);
}
async function generateAndUploadPDF(elementId, uploadOptions, pdfOptions = {}) {
  const pdfBlob = await generatePDFBlob(elementId, pdfOptions);
  return await uploadPDF(pdfBlob, uploadOptions);
}
async function generateDownloadAndUploadPDF(elementId, uploadOptions, pdfOptions = {}) {
  const pdfBlob = await generatePDFBlob(elementId, pdfOptions);
  const filename = pdfOptions.filename || "guide-application.pdf";
  downloadPDF(pdfBlob, filename);
  return await uploadPDF(pdfBlob, uploadOptions);
}

// src/hooks/usePDFGeneration.ts
function usePDFGeneration(options = {}) {
  const [isProcessing, setIsProcessing] = (0, import_react4.useState)(false);
  const { onSuccess, onError } = options;
  const handleError = (0, import_react4.useCallback)(
    (error) => {
      console.error("PDF generation error:", error);
      onError?.(error);
    },
    [onError]
  );
  const generatePDF = (0, import_react4.useCallback)(
    async (elementId, pdfOptions = {}) => {
      setIsProcessing(true);
      try {
        const pdfBlob = await generatePDFBlob(elementId, pdfOptions);
        onSuccess?.();
        return pdfBlob;
      } catch (error) {
        handleError(error instanceof Error ? error : new Error("Unknown error"));
        throw error;
      } finally {
        setIsProcessing(false);
      }
    },
    [onSuccess, handleError]
  );
  const downloadPDF2 = (0, import_react4.useCallback)(
    async (elementId, pdfOptions = {}) => {
      setIsProcessing(true);
      try {
        await generateAndDownloadPDF(elementId, pdfOptions);
        onSuccess?.();
      } catch (error) {
        handleError(error instanceof Error ? error : new Error("Unknown error"));
      } finally {
        setIsProcessing(false);
      }
    },
    [onSuccess, handleError]
  );
  const uploadPDF2 = (0, import_react4.useCallback)(
    async (elementId, uploadOptions, pdfOptions = {}) => {
      setIsProcessing(true);
      try {
        const fileKey = await generateAndUploadPDF(
          elementId,
          uploadOptions,
          pdfOptions
        );
        onSuccess?.(fileKey);
        return fileKey;
      } catch (error) {
        handleError(error instanceof Error ? error : new Error("Unknown error"));
        throw error;
      } finally {
        setIsProcessing(false);
      }
    },
    [onSuccess, handleError]
  );
  const downloadAndUploadPDF = (0, import_react4.useCallback)(
    async (elementId, uploadOptions, pdfOptions = {}) => {
      setIsProcessing(true);
      try {
        const fileKey = await generateDownloadAndUploadPDF(
          elementId,
          uploadOptions,
          pdfOptions
        );
        onSuccess?.(fileKey);
        return fileKey;
      } catch (error) {
        handleError(error instanceof Error ? error : new Error("Unknown error"));
        throw error;
      } finally {
        setIsProcessing(false);
      }
    },
    [onSuccess, handleError]
  );
  return {
    isProcessing,
    generatePDF,
    downloadPDF: downloadPDF2,
    uploadPDF: uploadPDF2,
    downloadAndUploadPDF
  };
}

// src/components/GuideForm.tsx
var import_react_intl4 = require("react-intl");
var import_jsx_runtime8 = require("react/jsx-runtime");
var GuideForm = ({
  config,
  ui,
  destinations = [],
  destinationsLoading = false,
  destinationsLoadError = false,
  allowCustomDestination = true,
  targetGroups = [],
  serviceCategories,
  onLoadServiceCategories,
  customTitle = "Become a YaoTu Guide",
  customDescription = "Share your local expertise and connect with curious travelers.",
  showProgressBar = true,
  onLoadLocalStorage,
  onSaveLocalStorage,
  onClearLocalStorage,
  initialStep
}) => {
  const intl = (0, import_react_intl4.useIntl)();
  const {
    currentPage,
    setCurrentPage,
    showPreview,
    setShowPreview,
    confirmationChecked,
    setConfirmationChecked,
    missingFields,
    setMissingFields,
    form,
    isLoading,
    isSaving,
    isSubmitting,
    isCreatingSignupIntent,
    funnelState,
    resumeState,
    draftConflict,
    acceptServerDraft,
    saveCurrentPageData,
    handleQualificationFilesChange,
    nextPage,
    prevPage,
    goToPreview,
    backToForm,
    continueToAuth,
    onSubmit,
    validateFormCompleteness: validateForm
  } = useGuideForm(config, onLoadLocalStorage, onSaveLocalStorage, onClearLocalStorage, initialStep);
  const { Form } = ui;
  const authenticated = isAuthenticated(config);
  const emailVerified = isEmailVerified(config);
  const requiresAccountBeforeSubmit = !authenticated || !emailVerified;
  const isVerificationCheckpoint = authenticated && !emailVerified;
  const shouldShowAuthCheckpoint = !authenticated && funnelState === "auth_required" || isVerificationCheckpoint && funnelState === "verification_required";
  const isResumeTransitionPending = resumeState === "loading" || resumeState === "draft_hydrated" || resumeState === "handoff_eligible" || resumeState === "handoff_in_flight";
  const submittedApplicationConflict = draftConflict?.reason === "submitted_application";
  const guideProfileConflict = draftConflict?.reason === "guide_profile_exists";
  const lockedApplicationConflict = submittedApplicationConflict || guideProfileConflict;
  const { downloadPDF: downloadPDF2, isProcessing } = usePDFGeneration({
    onSuccess: () => {
      console.log("PDF generated successfully!");
    },
    onError: (error) => {
      console.error("PDF generation failed:", error);
    }
  });
  const handleDownloadPDF = () => {
    downloadPDF2("print-root", {
      filename: `guide-application-${Date.now()}.pdf`
    });
  };
  if (showPreview) {
    return /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(
      ApplicationPreview,
      {
        formData: form.getValues(),
        missingFields,
        confirmationChecked,
        setConfirmationChecked,
        onBackToForm: backToForm,
        onSubmit,
        isSubmitting: isLoading || isSubmitting,
        requiresAccountBeforeSubmit,
        validateFormCompleteness: validateForm,
        setMissingFields,
        destinations,
        ui,
        intl
      }
    );
  }
  return /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("div", { className: "min-h-screen bg-yellow-50 py-12", children: /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)("div", { className: "max-w-4xl mx-auto px-4", children: [
    /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)("div", { className: "mb-8", children: [
      /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("h1", { className: "text-3xl font-bold text-gray-900 mb-2", children: customTitle }),
      /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("p", { className: "text-gray-600 mb-4", children: customDescription })
    ] }),
    showProgressBar && /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)("div", { className: "mb-6", children: [
      /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)("div", { className: "flex justify-between text-sm text-gray-500 mb-2", children: [
        /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("span", { children: intl.formatMessage({ id: "becomeGuide.progress.pageInfo" }, { current: currentPage, total: TOTAL_PAGES }) }),
        /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("span", { children: intl.formatMessage({ id: "becomeGuide.progress.completion" }, { percentage: Math.round(currentPage / TOTAL_PAGES * 100) }) })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(
        ui.Progress,
        {
          value: currentPage / TOTAL_PAGES * 100,
          className: "h-2"
        }
      )
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)(ui.Card, { className: "rounded-2xl shadow-lg", children: [
      /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)(ui.CardHeader, { className: "bg-yellow-400 rounded-t-2xl", children: [
        /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(ui.CardTitle, { className: "text-black", children: intl.formatMessage({ id: PAGE_TITLES[currentPage] }) }),
        currentPage === 2 && /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("p", { className: "text-sm text-gray-700 mt-2", children: intl.formatMessage({ id: "becomeGuide.step2.subtitle" }) }),
        currentPage === 3 && /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("p", { className: "text-sm text-gray-700 mt-2", children: intl.formatMessage({ id: "becomeGuide.step3.subtitle" }) }),
        currentPage === 4 && /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("p", { className: "text-sm text-gray-700 mt-2", children: intl.formatMessage({ id: "becomeGuide.step4.subtitle" }) })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)(ui.CardContent, { className: "p-6", children: [
        draftConflict && /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)("div", { className: "mb-6 rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900", children: [
          /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("p", { className: "font-semibold", children: guideProfileConflict ? "Guide profile already available" : submittedApplicationConflict ? "Application already submitted" : "Saved application found" }),
          /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("p", { className: "mt-1 leading-relaxed", children: guideProfileConflict ? "This account already has a Guide profile. Open your Guide home to continue." : submittedApplicationConflict ? "This application is already in review. View its current status instead of reopening it as a draft." : "We found an existing saved application for this account. To avoid overwriting server data, the existing saved application remains authoritative. Your local draft is preserved in this browser until you decide what to do." }),
          /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("div", { className: "mt-3 flex flex-wrap gap-2", children: lockedApplicationConflict ? /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(
            ui.Button,
            {
              type: "button",
              onClick: () => guideProfileConflict ? (config.callbacks.onNavigateToGuideHome ?? config.callbacks.onNavigateToStatus)?.() : config.callbacks.onNavigateToStatus?.(),
              children: guideProfileConflict ? "Open Guide home" : "View application status"
            }
          ) : /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(ui.Button, { type: "button", onClick: () => void acceptServerDraft(), children: "Continue existing saved application" }) })
        ] }),
        funnelState === "resume_after_auth" && !draftConflict && /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("div", { className: "mb-6 rounded-lg border border-blue-200 bg-blue-50 p-4 text-sm text-blue-900", children: "Restoring your saved application draft..." }),
        /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(Form, { ...form, children: /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)(
          "form",
          {
            onSubmit: form.handleSubmit(() => {
            }),
            className: "space-y-6",
            children: [
              currentPage === 1 && /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(
                Step1BasicInfo,
                {
                  control: form.control,
                  handleQualificationFilesChange,
                  ui,
                  destinations,
                  destinationsLoading,
                  destinationsLoadError,
                  allowCustomDestination
                }
              ),
              currentPage === 2 && /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(
                Step2SelfAssessment,
                {
                  control: form.control,
                  ui,
                  t: (key) => intl.formatMessage({ id: key })
                }
              ),
              currentPage === 3 && /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(
                Step3PersonalizedQuestions,
                {
                  control: form.control,
                  ui,
                  t: (key) => intl.formatMessage({ id: key })
                }
              ),
              currentPage === 4 && /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(
                Step4ServicePreferences,
                {
                  control: form.control,
                  ui,
                  serviceCategories,
                  targetGroups,
                  onLoadServiceCategories
                }
              ),
              currentPage <= 3 && missingFields.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)(
                "div",
                {
                  role: "alert",
                  "aria-live": "polite",
                  className: "rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-900",
                  children: [
                    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("p", { className: "font-semibold", children: intl.formatMessage({
                      id: "becomeGuide.preview.missingFields",
                      defaultMessage: "The following required answers are incomplete:"
                    }) }),
                    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("ul", { className: "mt-2 list-disc space-y-1 pl-5", children: missingFields.map((field) => {
                      const descriptor = getMissingFieldMessageDescriptor(field);
                      const messageId = Object.prototype.hasOwnProperty.call(
                        intl.messages,
                        descriptor.id
                      ) ? descriptor.id : Object.prototype.hasOwnProperty.call(intl.messages, field) ? field : descriptor.id;
                      return /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("li", { "data-missing-field": field, children: intl.formatMessage({
                        id: messageId,
                        defaultMessage: descriptor.defaultMessage
                      }) }, field);
                    }) })
                  ]
                }
              ),
              shouldShowAuthCheckpoint && /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)("div", { className: "rounded-lg border border-yellow-200 bg-yellow-50 p-4 text-sm text-slate-900", children: [
                /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("p", { className: "font-semibold", children: intl.formatMessage({
                  id: isVerificationCheckpoint ? "becomeGuide.checkpoint.verifyTitle" : "becomeGuide.checkpoint.authTitle",
                  defaultMessage: isVerificationCheckpoint ? "Verify your email to continue" : "Create or sign in to continue"
                }) }),
                /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("p", { className: "mt-1 leading-relaxed text-slate-700", children: intl.formatMessage({
                  id: isVerificationCheckpoint ? "becomeGuide.checkpoint.verifyDescription" : "becomeGuide.checkpoint.authDescription",
                  defaultMessage: isVerificationCheckpoint ? "Your answers and selected files are saved in this browser. Please verify your email before we upload files or save the application to your account." : "Your answers and selected files are saved in this browser. Next, create or sign in to a YaoTu account so this application can be attached to you. Keep this browser open; after verification you will return here to continue."
                }) }),
                /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("div", { className: "mt-3 flex flex-wrap gap-2", children: /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(
                  ui.Button,
                  {
                    type: "button",
                    disabled: isResumeTransitionPending || !isVerificationCheckpoint && isCreatingSignupIntent,
                    onClick: () => isVerificationCheckpoint ? navigateToVerification(config) : void continueToAuth(),
                    children: intl.formatMessage({
                      id: isVerificationCheckpoint ? "becomeGuide.checkpoint.verifyCta" : "becomeGuide.checkpoint.authCta",
                      defaultMessage: isVerificationCheckpoint ? "Continue to email verification" : "Continue to account setup"
                    })
                  }
                ) })
              ] }),
              /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(
                FormNavigation,
                {
                  currentPage,
                  onPrevPage: prevPage,
                  onNextPage: () => void nextPage(),
                  onGoToPreview: () => void goToPreview(),
                  onSaveDraft: saveCurrentPageData,
                  isSavingDraft: isSaving,
                  isNavigationDisabled: isResumeTransitionPending,
                  ui
                }
              )
            ]
          }
        ) })
      ] })
    ] })
  ] }) });
};

// src/components/FounderNoteMail.tsx
var import_react5 = require("react");
var import_framer_motion = require("framer-motion");
var import_lucide_react2 = require("lucide-react");
var import_react_intl5 = require("react-intl");
var import_jsx_runtime9 = require("react/jsx-runtime");
var FOUNDER_NOTE_PARAGRAPH_IDS = [
  "guideForm.founderNote.body1",
  "guideForm.founderNote.body2",
  "guideForm.founderNote.body3",
  "guideForm.founderNote.body4",
  "guideForm.founderNote.body5",
  "guideForm.founderNote.body6",
  "guideForm.founderNote.body7",
  "guideForm.founderNote.body8",
  "guideForm.founderNote.body9",
  "guideForm.founderNote.body10",
  "guideForm.founderNote.body11",
  "guideForm.founderNote.body12",
  "guideForm.founderNote.body13",
  "guideForm.founderNote.body14",
  "guideForm.founderNote.body15",
  "guideForm.founderNote.body16"
];
var FOUNDER_NOTE_DIALOG_ID = "become-guide-founder-note-dialog";
var FOUNDER_NOTE_TITLE_ID = "become-guide-founder-note-title";
var FOUNDER_NOTE_READ_STORAGE_KEY = "yaotu_founder_note_read";
var FOCUSABLE_SELECTOR = 'a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])';
var readFounderNoteReadState = () => {
  if (typeof window === "undefined") return false;
  try {
    return window.localStorage.getItem(FOUNDER_NOTE_READ_STORAGE_KEY) === "true";
  } catch {
    return false;
  }
};
var persistFounderNoteReadState = () => {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(FOUNDER_NOTE_READ_STORAGE_KEY, "true");
  } catch {
  }
};
var useIsDesktopViewport = () => {
  const [isDesktop, setIsDesktop] = (0, import_react5.useState)(
    () => typeof window === "undefined" || typeof window.matchMedia !== "function" ? true : window.matchMedia("(min-width: 768px)").matches
  );
  (0, import_react5.useEffect)(() => {
    if (typeof window === "undefined" || typeof window.matchMedia !== "function") {
      return void 0;
    }
    const mediaQuery = window.matchMedia("(min-width: 768px)");
    const handleChange = () => setIsDesktop(mediaQuery.matches);
    handleChange();
    mediaQuery.addEventListener("change", handleChange);
    return () => mediaQuery.removeEventListener("change", handleChange);
  }, []);
  return isDesktop;
};
var FounderNoteContent = () => {
  const intl = (0, import_react_intl5.useIntl)();
  return /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)("article", { "aria-labelledby": FOUNDER_NOTE_TITLE_ID, className: "space-y-5", children: [
    /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)("div", { children: [
      /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("p", { className: "mb-2 text-xs font-semibold uppercase tracking-[0.18em] text-yellow-700 dark:text-yellow-300", children: intl.formatMessage({ id: "guideForm.founderNote.eyebrow" }) }),
      /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(
        "h2",
        {
          id: FOUNDER_NOTE_TITLE_ID,
          className: "text-2xl font-semibold text-gray-950 dark:text-white",
          children: intl.formatMessage({ id: "guideForm.founderNote.title" })
        }
      )
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("div", { className: "space-y-4 text-base leading-7 text-gray-700 dark:text-gray-200", children: FOUNDER_NOTE_PARAGRAPH_IDS.map((id) => /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("p", { children: intl.formatMessage(
      { id },
      {
        strong: (chunks) => /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("strong", { className: "font-semibold text-gray-950 dark:text-white", children: chunks })
      }
    ) }, id)) })
  ] });
};
var FounderNoteMail = () => {
  const intl = (0, import_react_intl5.useIntl)();
  const [isOpen, setIsOpen] = (0, import_react5.useState)(false);
  const [hasReadFounderNote, setHasReadFounderNote] = (0, import_react5.useState)(readFounderNoteReadState);
  const reduceMotion = (0, import_framer_motion.useReducedMotion)();
  const isDesktop = useIsDesktopViewport();
  const desktopTriggerRef = (0, import_react5.useRef)(null);
  const mobileTriggerRef = (0, import_react5.useRef)(null);
  const lastTriggerRef = (0, import_react5.useRef)(null);
  const dialogRef = (0, import_react5.useRef)(null);
  const closeButtonRef = (0, import_react5.useRef)(null);
  const launcherLabel = intl.formatMessage({
    id: hasReadFounderNote ? "guideForm.founderNote.trigger.read" : "guideForm.founderNote.trigger.unread"
  });
  const closeLabel = intl.formatMessage({ id: "guideForm.founderNote.closeLabel" });
  const close = (0, import_react5.useCallback)(() => setIsOpen(false), []);
  const openFrom = (0, import_react5.useCallback)((trigger) => {
    lastTriggerRef.current = trigger;
    setHasReadFounderNote(true);
    persistFounderNoteReadState();
    setIsOpen(true);
  }, []);
  (0, import_react5.useEffect)(() => {
    if (!isOpen) {
      lastTriggerRef.current?.focus({ preventScroll: true });
      return void 0;
    }
    const frame = window.requestAnimationFrame(() => {
      closeButtonRef.current?.focus({ preventScroll: true });
    });
    const handleKeyDown = (event) => {
      if (event.key === "Escape") {
        event.preventDefault();
        close();
        return;
      }
      if (event.key !== "Tab") return;
      const dialog = dialogRef.current;
      if (!dialog) return;
      const focusable = Array.from(dialog.querySelectorAll(FOCUSABLE_SELECTOR)).filter(
        (element) => element.offsetParent !== null
      );
      if (focusable.length === 0) {
        event.preventDefault();
        closeButtonRef.current?.focus({ preventScroll: true });
        return;
      }
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (!first || !last) return;
      const active = document.activeElement;
      if (event.shiftKey && active === first) {
        event.preventDefault();
        last.focus({ preventScroll: true });
      } else if (!event.shiftKey && active === last) {
        event.preventDefault();
        first.focus({ preventScroll: true });
      }
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => {
      window.cancelAnimationFrame(frame);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [close, isOpen]);
  const panelInitial = reduceMotion ? { opacity: 1, x: 0, y: 0 } : isDesktop ? { opacity: 0, x: 56, y: 0 } : { opacity: 0, x: 0, y: 72 };
  const panelExit = reduceMotion ? { opacity: 1, x: 0, y: 0 } : isDesktop ? { opacity: 0, x: 56, y: 0 } : { opacity: 0, x: 0, y: 72 };
  const iconAnimation = reduceMotion ? void 0 : { rotate: [0, -8, 6, 0], y: [0, -2, 0, 0] };
  return /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)(import_jsx_runtime9.Fragment, { children: [
    /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)(
      import_framer_motion.motion.button,
      {
        ref: desktopTriggerRef,
        type: "button",
        "aria-label": launcherLabel,
        "aria-controls": FOUNDER_NOTE_DIALOG_ID,
        "aria-expanded": isOpen,
        onClick: () => openFrom(desktopTriggerRef.current),
        className: "fixed right-0 top-[45vh] z-40 hidden -translate-y-1/2 items-center gap-2 rounded-l-full border border-r-0 border-yellow-300 bg-white px-4 py-3 text-sm font-semibold text-gray-950 shadow-lg shadow-yellow-900/10 transition-colors hover:bg-yellow-50 focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:ring-offset-2 dark:border-yellow-500/50 dark:bg-gray-900 dark:text-white dark:hover:bg-gray-800 md:flex",
        initial: reduceMotion ? false : { opacity: 0, x: 28 },
        animate: { opacity: 1, x: 0 },
        transition: reduceMotion ? void 0 : { delay: 0.55, duration: 0.35, ease: "easeOut" },
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(
            import_framer_motion.motion.span,
            {
              "aria-hidden": "true",
              animate: iconAnimation,
              transition: reduceMotion ? void 0 : { delay: 0.95, duration: 0.6, ease: "easeOut" },
              children: /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(import_lucide_react2.Mail, { className: "h-4 w-4 text-yellow-600 dark:text-yellow-300" })
            }
          ),
          /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("span", { children: launcherLabel })
        ]
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(
      import_framer_motion.motion.button,
      {
        ref: mobileTriggerRef,
        type: "button",
        "aria-label": launcherLabel,
        "aria-controls": FOUNDER_NOTE_DIALOG_ID,
        "aria-expanded": isOpen,
        onClick: () => openFrom(mobileTriggerRef.current),
        className: "fixed bottom-[calc(env(safe-area-inset-bottom)+5.5rem)] right-4 z-40 flex h-12 w-12 items-center justify-center rounded-full border border-yellow-300 bg-white text-yellow-700 shadow-lg shadow-yellow-900/15 transition-colors hover:bg-yellow-50 focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:ring-offset-2 dark:border-yellow-500/50 dark:bg-gray-900 dark:text-yellow-300 md:hidden",
        initial: reduceMotion ? false : { opacity: 0, scale: 0.92, y: 16 },
        animate: { opacity: 1, scale: 1, y: 0 },
        transition: reduceMotion ? void 0 : { delay: 0.55, duration: 0.35, ease: "easeOut" },
        children: /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(
          import_framer_motion.motion.span,
          {
            "aria-hidden": "true",
            animate: iconAnimation,
            transition: reduceMotion ? void 0 : { delay: 0.95, duration: 0.6, ease: "easeOut" },
            children: /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(import_lucide_react2.Mail, { className: "h-5 w-5" })
          }
        )
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(import_framer_motion.AnimatePresence, { children: isOpen && /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)(import_jsx_runtime9.Fragment, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(
        import_framer_motion.motion.div,
        {
          "aria-hidden": "true",
          className: "fixed inset-0 z-40 bg-black/[0.04] backdrop-blur-[1px]",
          initial: { opacity: 0 },
          animate: { opacity: 1 },
          exit: { opacity: 0 },
          transition: { duration: reduceMotion ? 0 : 0.18 },
          onClick: close
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(
        import_framer_motion.motion.aside,
        {
          id: FOUNDER_NOTE_DIALOG_ID,
          ref: dialogRef,
          role: "dialog",
          "aria-modal": "true",
          "aria-labelledby": FOUNDER_NOTE_TITLE_ID,
          className: "fixed inset-x-0 bottom-0 z-50 max-h-[78dvh] overflow-hidden rounded-t-2xl border border-yellow-200 bg-white shadow-2xl shadow-yellow-950/20 dark:border-yellow-500/30 dark:bg-gray-900 md:inset-x-auto md:bottom-auto md:right-0 md:top-0 md:h-[100dvh] md:max-h-none md:w-[min(430px,calc(100vw-2rem))] md:rounded-none md:rounded-l-2xl md:border-y-0 md:border-r-0",
          initial: panelInitial,
          animate: { opacity: 1, x: 0, y: 0 },
          exit: panelExit,
          transition: reduceMotion ? { duration: 0 } : { type: "spring", stiffness: 360, damping: 34, mass: 0.8 },
          children: /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)("div", { className: "flex max-h-[78dvh] flex-col md:h-full md:max-h-none", children: [
            /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)("div", { className: "border-b border-yellow-100 px-5 pb-4 pt-3 dark:border-yellow-500/20 sm:px-6 md:px-7 md:pt-6", children: [
              /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("div", { className: "mx-auto mb-4 h-1.5 w-12 rounded-full bg-yellow-200 dark:bg-yellow-500/40 md:hidden" }),
              /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)("div", { className: "flex items-start justify-between gap-4", children: [
                /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("span", { className: "flex h-10 w-10 items-center justify-center rounded-full bg-yellow-100 text-yellow-700 dark:bg-yellow-500/15 dark:text-yellow-300", children: /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(import_lucide_react2.Mail, { className: "h-5 w-5", "aria-hidden": "true" }) }),
                  /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("p", { className: "text-sm font-semibold text-gray-950 dark:text-white", children: launcherLabel })
                ] }),
                /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(
                  "button",
                  {
                    ref: closeButtonRef,
                    type: "button",
                    "aria-label": closeLabel,
                    onClick: close,
                    className: "rounded-full p-2 text-gray-500 transition-colors hover:bg-yellow-50 hover:text-gray-950 focus:outline-none focus:ring-2 focus:ring-yellow-400 dark:text-gray-300 dark:hover:bg-gray-800 dark:hover:text-white",
                    children: /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(import_lucide_react2.X, { className: "h-5 w-5", "aria-hidden": "true" })
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("div", { className: "overflow-y-auto px-5 py-6 sm:px-6 md:px-7", children: /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(FounderNoteContent, {}) })
          ] })
        }
      )
    ] }) })
  ] });
};

// src/components/PrintAndSave.tsx
var import_react6 = require("react");
var import_jsx_runtime10 = require("react/jsx-runtime");
function PrintAndSave({
  applicationId,
  token,
  uploadUrl,
  elementId = "print-root",
  pdfOptions = {},
  onSuccess,
  onError,
  className = "",
  children,
  disabled = false
}) {
  const [isProcessing, setIsProcessing] = (0, import_react6.useState)(false);
  const handlePrintAndSave = async () => {
    if (isProcessing || disabled) return;
    if (!token) {
      const error = new Error("Authentication token is required");
      onError?.(error);
      return;
    }
    if (!applicationId) {
      const error = new Error("Application ID is required");
      onError?.(error);
      return;
    }
    setIsProcessing(true);
    try {
      const uploadOptions = {
        applicationId,
        token,
        uploadUrl
      };
      const mergedPdfOptions = {
        filename: `guide-application-${applicationId}.pdf`,
        ...pdfOptions
      };
      console.log("\u{1F504} \u5F00\u59CB\u4E00\u952E\u6253\u5370\u4FDD\u5B58...", {
        applicationId,
        elementId,
        uploadUrl
      });
      const fileKey = await generateDownloadAndUploadPDF(
        elementId,
        uploadOptions,
        mergedPdfOptions
      );
      console.log("\u2705 \u4E00\u952E\u6253\u5370\u4FDD\u5B58\u6210\u529F:", fileKey);
      onSuccess?.(fileKey);
      setTimeout(() => {
        window.print();
      }, 1e3);
    } catch (error) {
      console.error("\u274C \u4E00\u952E\u6253\u5370\u4FDD\u5B58\u5931\u8D25:", error);
      onError?.(error instanceof Error ? error : new Error("Unknown error"));
    } finally {
      setIsProcessing(false);
    }
  };
  return /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
    "button",
    {
      onClick: handlePrintAndSave,
      disabled: isProcessing || disabled,
      className: `inline-flex items-center justify-center px-6 py-3 rounded-xl font-medium transition-colors ${isProcessing || disabled ? "bg-gray-400 text-gray-600 cursor-not-allowed" : "bg-yellow-500 hover:bg-yellow-600 text-black"} ${className}`,
      children: isProcessing ? /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(import_jsx_runtime10.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "w-4 h-4 mr-2 animate-spin border-2 border-current border-t-transparent rounded-full" }),
        "\u5904\u7406\u4E2D..."
      ] }) : children || /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(import_jsx_runtime10.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "flex items-center space-x-1 mr-2", children: [
          /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
            "svg",
            {
              className: "w-4 h-4",
              fill: "none",
              stroke: "currentColor",
              viewBox: "0 0 24 24",
              children: /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
                "path",
                {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                }
              )
            }
          ),
          /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
            "svg",
            {
              className: "w-4 h-4",
              fill: "none",
              stroke: "currentColor",
              viewBox: "0 0 24 24",
              children: /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
                "path",
                {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"
                }
              )
            }
          )
        ] }),
        "\u4E00\u952E\u6253\u5370\u4FDD\u5B58"
      ] })
    }
  );
}

// src/components/ApplicationStatus.tsx
var import_react_intl8 = require("react-intl");

// src/components/ApprovalTimeline.tsx
var import_react_intl6 = require("react-intl");
var import_jsx_runtime11 = require("react/jsx-runtime");
function ApprovalTimeline({
  timeline,
  CheckCircle,
  Clock,
  AlertCircle,
  XCircle,
  FileCheck,
  Upload
}) {
  const intl = (0, import_react_intl6.useIntl)();
  const getTimelineItemInfo = (entry) => {
    switch (entry.type) {
      case "application_submitted":
        return {
          icon: /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(CheckCircle, { className: "h-5 w-5 text-blue-500" }),
          title: intl.formatMessage({ id: "approvalTimeline.applicationSubmitted" }),
          description: intl.formatMessage({ id: "approvalTimeline.applicationSubmittedDescription" }),
          color: "text-blue-600"
        };
      case "admin_action":
        switch (entry.adminAction) {
          case "review":
            return {
              icon: /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(Clock, { className: "h-5 w-5 text-yellow-500" }),
              title: intl.formatMessage({ id: "approvalTimeline.underReview" }),
              description: entry.note || intl.formatMessage({ id: "approvalTimeline.underReviewDescription" }),
              color: "text-yellow-600"
            };
          case "approve":
            return {
              icon: /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(CheckCircle, { className: "h-5 w-5 text-green-500" }),
              title: intl.formatMessage({ id: "approvalTimeline.approved" }),
              description: entry.note || intl.formatMessage({ id: "approvalTimeline.approvedDescription" }),
              color: "text-green-600"
            };
          case "reject":
            return {
              icon: /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(XCircle, { className: "h-5 w-5 text-red-500" }),
              title: intl.formatMessage({ id: "approvalTimeline.rejected" }),
              description: entry.note || intl.formatMessage({ id: "approvalTimeline.rejectedDescription" }),
              color: "text-red-600"
            };
          case "require_more_info":
            return {
              icon: /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(AlertCircle, { className: "h-5 w-5 text-orange-500" }),
              title: intl.formatMessage({ id: "approvalTimeline.requireMoreInfo" }),
              description: entry.note || intl.formatMessage({ id: "approvalTimeline.requireMoreInfoDescription" }),
              color: "text-orange-600"
            };
          default:
            return {
              icon: /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(Clock, { className: "h-5 w-5 text-gray-500" }),
              title: intl.formatMessage({ id: "approvalTimeline.adminAction" }),
              description: entry.note || intl.formatMessage({ id: "approvalTimeline.adminActionDescription" }),
              color: "text-gray-600"
            };
        }
      case "user_response":
        return {
          icon: /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(FileCheck, { className: "h-5 w-5 text-blue-500" }),
          title: intl.formatMessage({ id: "approvalTimeline.supplementalMaterialsUploaded" }),
          description: intl.formatMessage({ id: "approvalTimeline.supplementalMaterialsUploadedDescription" }),
          color: "text-blue-600"
        };
      default:
        return {
          icon: /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(Clock, { className: "h-5 w-5 text-gray-500" }),
          title: intl.formatMessage({ id: "approvalTimeline.unknownStatus" }),
          description: "",
          color: "text-gray-600"
        };
    }
  };
  const getSupplementaryMaterialStatus = () => {
    const lastRequireMoreInfo = timeline.filter((entry) => entry.type === "admin_action" && entry.adminAction === "require_more_info").pop();
    if (!lastRequireMoreInfo) return null;
    const lastRequireMoreInfoTime = new Date(lastRequireMoreInfo.timestamp).getTime();
    const hasUserResponseAfter = timeline.some(
      (entry) => entry.type === "user_response" && new Date(entry.timestamp).getTime() > lastRequireMoreInfoTime
    );
    return {
      needsResponse: !hasUserResponseAfter,
      lastRequireMoreInfo
    };
  };
  const supplementaryStatus = getSupplementaryMaterialStatus();
  return /* @__PURE__ */ (0, import_jsx_runtime11.jsxs)("div", { className: "space-y-6", children: [
    /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("h3", { className: "text-lg font-semibold text-gray-900", children: intl.formatMessage({ id: "approvalTimeline.title" }) }),
    /* @__PURE__ */ (0, import_jsx_runtime11.jsxs)("div", { className: "relative", children: [
      /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("div", { className: "absolute left-6 top-0 bottom-0 w-0.5 bg-gray-200" }),
      /* @__PURE__ */ (0, import_jsx_runtime11.jsxs)("div", { className: "space-y-6", children: [
        timeline.map((entry, index) => {
          const itemInfo = getTimelineItemInfo(entry);
          const isLast = index === timeline.length - 1;
          return /* @__PURE__ */ (0, import_jsx_runtime11.jsxs)("div", { className: "relative flex items-start", children: [
            /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("div", { className: "relative z-10 flex items-center justify-center w-12 h-12 bg-white border-2 border-gray-200 rounded-full", children: itemInfo.icon }),
            /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("div", { className: "ml-4 flex-1 min-w-0", children: /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("div", { className: "bg-white rounded-lg border border-gray-200 p-4 shadow-sm", children: /* @__PURE__ */ (0, import_jsx_runtime11.jsxs)("div", { className: "flex items-start justify-between", children: [
              /* @__PURE__ */ (0, import_jsx_runtime11.jsxs)("div", { className: "flex-1", children: [
                /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("h4", { className: `font-medium ${itemInfo.color}`, children: itemInfo.title }),
                /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("p", { className: "text-sm text-gray-600 mt-1", children: itemInfo.description }),
                entry.adminName && /* @__PURE__ */ (0, import_jsx_runtime11.jsxs)("p", { className: "text-xs text-gray-500 mt-1", children: [
                  intl.formatMessage({ id: "approvalTimeline.reviewer" }),
                  ": ",
                  entry.adminName
                ] })
              ] }),
              /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("time", { className: "text-xs text-gray-500 whitespace-nowrap ml-4", children: new Date(entry.timestamp).toLocaleString("zh-CN", {
                month: "short",
                day: "numeric",
                hour: "2-digit",
                minute: "2-digit"
              }) })
            ] }) }) })
          ] }, `${entry.type}-${entry.id}`);
        }),
        supplementaryStatus?.needsResponse && /* @__PURE__ */ (0, import_jsx_runtime11.jsxs)("div", { className: "relative flex items-start", children: [
          /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("div", { className: "relative z-10 flex items-center justify-center w-12 h-12 bg-white border-2 border-orange-200 rounded-full", children: /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(Upload, { className: "h-5 w-5 text-orange-500" }) }),
          /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("div", { className: "ml-4 flex-1 min-w-0", children: /* @__PURE__ */ (0, import_jsx_runtime11.jsxs)("div", { className: "bg-orange-50 rounded-lg border border-orange-200 p-4 shadow-sm", children: [
            /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("h4", { className: "font-medium text-orange-600", children: intl.formatMessage({ id: "approvalTimeline.supplementalMaterialsNotUploaded" }) }),
            /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("p", { className: "text-sm text-orange-700 mt-1", children: intl.formatMessage({ id: "approvalTimeline.supplementalMaterialsNotUploadedDescription" }) })
          ] }) })
        ] })
      ] })
    ] })
  ] });
}

// src/components/SupplementalMaterialsUpload.tsx
var import_react7 = require("react");
var import_react_intl7 = require("react-intl");
var import_jsx_runtime12 = require("react/jsx-runtime");
function SupplementalMaterialsUpload({
  applicationId,
  onSubmitSuccess,
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  Button,
  Textarea,
  Input,
  Label,
  Upload,
  FileText,
  X: X3,
  CheckCircle,
  onFileUpload,
  onSubmit,
  onToast
}) {
  const intl = (0, import_react_intl7.useIntl)();
  const [description, setDescription] = (0, import_react7.useState)("");
  const [files, setFiles] = (0, import_react7.useState)([]);
  const [uploading, setUploading] = (0, import_react7.useState)(false);
  const [submitting, setSubmitting] = (0, import_react7.useState)(false);
  const handleFileUpload = async (event) => {
    const selectedFile = event.target.files?.[0];
    if (!selectedFile) return;
    const allowedTypes = [
      "image/jpeg",
      "image/jpg",
      "image/png",
      "image/gif",
      "image/webp",
      "application/pdf",
      "application/msword",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    ];
    if (!allowedTypes.includes(selectedFile.type)) {
      onToast?.({
        title: intl.formatMessage({ id: "supplementalMaterials.unsupportedFileType" }),
        description: intl.formatMessage({ id: "supplementalMaterials.unsupportedFileTypeDescription" }),
        variant: "destructive"
      });
      return;
    }
    const maxSize = 10 * 1024 * 1024;
    if (selectedFile.size > maxSize) {
      onToast?.({
        title: intl.formatMessage({ id: "supplementalMaterials.fileTooLarge" }),
        description: intl.formatMessage({ id: "supplementalMaterials.fileTooLargeDescription" }),
        variant: "destructive"
      });
      return;
    }
    setUploading(true);
    try {
      if (!onFileUpload) {
        throw new Error(intl.formatMessage({ id: "supplementalMaterials.uploadNotConfigured" }));
      }
      const result = await onFileUpload(selectedFile);
      const newFile = {
        id: result.fileId,
        name: selectedFile.name,
        url: result.publicUrl,
        size: selectedFile.size,
        description: ""
      };
      setFiles((prev) => [...prev, newFile]);
      onToast?.({
        title: intl.formatMessage({ id: "supplementalMaterials.uploadSuccess" }),
        description: intl.formatMessage({ id: "supplementalMaterials.uploadSuccessDescription" }, { fileName: selectedFile.name })
      });
    } catch (error) {
      console.error("\u6587\u4EF6\u4E0A\u4F20\u5931\u8D25:", error);
      onToast?.({
        title: intl.formatMessage({ id: "supplementalMaterials.uploadFailed" }),
        description: error instanceof Error ? error.message : intl.formatMessage({ id: "supplementalMaterials.uploadFailedDescription" }),
        variant: "destructive"
      });
    } finally {
      setUploading(false);
      if (event.target) {
        event.target.value = "";
      }
    }
  };
  const removeFile = (fileId) => {
    setFiles((prev) => prev.filter((f) => f.id !== fileId));
  };
  const updateFileDescription = (fileId, description2) => {
    setFiles((prev) => prev.map(
      (f) => f.id === fileId ? { ...f, description: description2 } : f
    ));
  };
  const handleSubmit = async () => {
    if (!description.trim() && files.length === 0) {
      onToast?.({
        title: intl.formatMessage({ id: "supplementalMaterials.pleaseFillContent" }),
        description: intl.formatMessage({ id: "supplementalMaterials.pleaseFillContentDescription" }),
        variant: "destructive"
      });
      return;
    }
    setSubmitting(true);
    try {
      const userResponse = {};
      if (description.trim()) {
        userResponse.description = description.trim();
      }
      if (files.length > 0) {
        userResponse.certifications = {};
        files.forEach((file, index) => {
          const key = `supplemental_${Date.now()}_${index}`;
          userResponse.certifications[key] = {
            proof: file.url,
            description: file.description || file.name,
            visible: true
          };
        });
      }
      if (!onSubmit) {
        throw new Error(intl.formatMessage({ id: "supplementalMaterials.submitNotConfigured" }));
      }
      await onSubmit({
        applicationId,
        userResponse
      });
      onToast?.({
        title: intl.formatMessage({ id: "supplementalMaterials.submitSuccess" }),
        description: intl.formatMessage({ id: "supplementalMaterials.submitSuccessDescription" })
      });
      setDescription("");
      setFiles([]);
      onSubmitSuccess?.();
    } catch (error) {
      console.error("\u63D0\u4EA4\u8865\u5145\u6750\u6599\u5931\u8D25:", error);
      onToast?.({
        title: intl.formatMessage({ id: "supplementalMaterials.submitFailed" }),
        description: error instanceof Error ? error.message : intl.formatMessage({ id: "supplementalMaterials.submitFailedDescription" }),
        variant: "destructive"
      });
    } finally {
      setSubmitting(false);
    }
  };
  const formatFileSize = (bytes) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };
  return /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)(Card, { className: "rounded-2xl shadow-lg border-orange-200 bg-orange-50", children: [
    /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)(CardHeader, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)(CardTitle, { className: "flex items-center gap-2 text-orange-800", children: [
        /* @__PURE__ */ (0, import_jsx_runtime12.jsx)(Upload, { className: "h-5 w-5" }),
        intl.formatMessage({ id: "supplementalMaterials.title" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("p", { className: "text-sm text-orange-600", children: intl.formatMessage({ id: "supplementalMaterials.description" }) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)(CardContent, { className: "space-y-4", children: [
      /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)("div", { className: "space-y-2", children: [
        /* @__PURE__ */ (0, import_jsx_runtime12.jsx)(Label, { htmlFor: "description", children: intl.formatMessage({ id: "supplementalMaterials.supplementalDescription" }) }),
        /* @__PURE__ */ (0, import_jsx_runtime12.jsx)(
          Textarea,
          {
            id: "description",
            placeholder: intl.formatMessage({ id: "supplementalMaterials.supplementalDescriptionPlaceholder" }),
            value: description,
            onChange: (e) => setDescription(e.target.value),
            rows: 4,
            className: "resize-none"
          }
        )
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)("div", { className: "space-y-2", children: [
        /* @__PURE__ */ (0, import_jsx_runtime12.jsx)(Label, { children: intl.formatMessage({ id: "supplementalMaterials.supplementalFiles" }) }),
        /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)("div", { className: "border-2 border-dashed border-orange-300 rounded-lg p-4 text-center", children: [
          /* @__PURE__ */ (0, import_jsx_runtime12.jsx)(
            Input,
            {
              type: "file",
              onChange: handleFileUpload,
              disabled: uploading,
              className: "hidden",
              id: "file-upload",
              accept: "image/*,.pdf,.doc,.docx"
            }
          ),
          /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)(
            Label,
            {
              htmlFor: "file-upload",
              className: "cursor-pointer flex flex-col items-center space-y-2",
              children: [
                /* @__PURE__ */ (0, import_jsx_runtime12.jsx)(Upload, { className: "h-8 w-8 text-orange-500" }),
                /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("span", { className: "text-sm text-orange-600", children: uploading ? intl.formatMessage({ id: "supplementalMaterials.uploading" }) : intl.formatMessage({ id: "supplementalMaterials.clickToSelectFile" }) }),
                /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("span", { className: "text-xs text-gray-500", children: intl.formatMessage({ id: "supplementalMaterials.supportedFormats" }) })
              ]
            }
          )
        ] })
      ] }),
      files.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)("div", { className: "space-y-2", children: [
        /* @__PURE__ */ (0, import_jsx_runtime12.jsx)(Label, { children: intl.formatMessage({ id: "supplementalMaterials.uploadedFiles" }) }),
        /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("div", { className: "space-y-2", children: files.map((file) => /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)("div", { className: "flex items-center space-x-3 p-3 bg-white rounded-lg border", children: [
          /* @__PURE__ */ (0, import_jsx_runtime12.jsx)(FileText, { className: "h-5 w-5 text-blue-500 flex-shrink-0" }),
          /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)("div", { className: "flex-1 min-w-0", children: [
            /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("p", { className: "text-sm font-medium text-gray-900 truncate", children: file.name }),
            /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("p", { className: "text-xs text-gray-500", children: formatFileSize(file.size) }),
            /* @__PURE__ */ (0, import_jsx_runtime12.jsx)(
              Input,
              {
                placeholder: intl.formatMessage({ id: "supplementalMaterials.fileDescriptionPlaceholder" }),
                value: file.description,
                onChange: (e) => updateFileDescription(file.id, e.target.value),
                className: "mt-1 text-xs"
              }
            )
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime12.jsx)(
            Button,
            {
              variant: "ghost",
              size: "sm",
              onClick: () => removeFile(file.id),
              className: "text-red-500 hover:text-red-700",
              children: /* @__PURE__ */ (0, import_jsx_runtime12.jsx)(X3, { className: "h-4 w-4" })
            }
          )
        ] }, file.id)) })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("div", { className: "pt-4", children: /* @__PURE__ */ (0, import_jsx_runtime12.jsx)(
        Button,
        {
          onClick: handleSubmit,
          disabled: submitting || !description.trim() && files.length === 0,
          className: "w-full bg-orange-600 hover:bg-orange-700",
          children: submitting ? intl.formatMessage({ id: "supplementalMaterials.submitting" }) : /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)(import_jsx_runtime12.Fragment, { children: [
            /* @__PURE__ */ (0, import_jsx_runtime12.jsx)(CheckCircle, { className: "h-4 w-4 mr-2" }),
            intl.formatMessage({ id: "supplementalMaterials.submitSupplementalMaterials" })
          ] })
        }
      ) })
    ] })
  ] });
}

// src/components/ApplicationStatus.tsx
var import_jsx_runtime13 = require("react/jsx-runtime");
function ApplicationStatus({
  application,
  fullApplication,
  timelineData,
  isLoading = false,
  error,
  timelineLoading = false,
  isJustSubmitted = false,
  onRefetchTimeline,
  onDownloadPDF,
  onNavigateToGuide,
  onNavigateToBecomeGuide,
  onFileUpload,
  onSubmitSupplemental,
  onToast,
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  Button,
  Badge,
  Textarea,
  Input,
  Label,
  CheckCircle,
  Clock,
  AlertCircle,
  XCircle,
  Download,
  Upload,
  FileText,
  History
}) {
  const intl = (0, import_react_intl8.useIntl)();
  const needsSupplementalMaterials = () => {
    if (!timelineData?.timeline || !application) return false;
    if (application.applicationStatus === "needs_more_info") {
      return true;
    }
    const timeline = timelineData.timeline;
    const lastRequireMoreInfo = timeline.filter((entry) => entry.type === "admin_action" && entry.adminAction === "require_more_info").sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())[0];
    if (!lastRequireMoreInfo) return false;
    const hasUserResponseAfter = timeline.some(
      (entry) => entry.type === "user_response" && new Date(entry.timestamp) > new Date(lastRequireMoreInfo.timestamp)
    );
    return !hasUserResponseAfter;
  };
  const handleSupplementalMaterialsSubmitted = () => {
    onRefetchTimeline?.();
  };
  const getStatusInfo = (status) => {
    switch (status) {
      case "pending":
        return {
          icon: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(Clock, { className: "h-6 w-6 text-yellow-500" }),
          text: intl.formatMessage({ id: "applicationStatus.pending" }),
          color: "bg-yellow-50 border-yellow-200 text-yellow-800",
          description: intl.formatMessage({ id: "applicationStatus.pendingDescription" })
        };
      case "needs_more_info":
        return {
          icon: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(AlertCircle, { className: "h-6 w-6 text-orange-500" }),
          text: intl.formatMessage({ id: "applicationStatus.needsMoreInfo" }),
          color: "bg-orange-50 border-orange-200 text-orange-800",
          description: intl.formatMessage({ id: "applicationStatus.needsMoreInfoDescription" })
        };
      case "approved":
        return {
          icon: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(CheckCircle, { className: "h-6 w-6 text-green-500" }),
          text: intl.formatMessage({ id: "applicationStatus.approved" }),
          color: "bg-green-50 border-green-200 text-green-800",
          description: intl.formatMessage({ id: "applicationStatus.approvedDescription" })
        };
      case "rejected":
        return {
          icon: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(XCircle, { className: "h-6 w-6 text-red-500" }),
          text: intl.formatMessage({ id: "applicationStatus.rejected" }),
          color: "bg-red-50 border-red-200 text-red-800",
          description: intl.formatMessage({ id: "applicationStatus.rejectedDescription" })
        };
      default:
        return {
          icon: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(Clock, { className: "h-6 w-6 text-gray-500" }),
          text: intl.formatMessage({ id: "applicationStatus.unknown" }),
          color: "bg-gray-50 border-gray-200 text-gray-800",
          description: intl.formatMessage({ id: "applicationStatus.unknownDescription" })
        };
    }
  };
  if (isLoading) {
    return /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("div", { className: "min-h-screen bg-yellow-50 py-12", children: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("div", { className: "max-w-4xl mx-auto px-4", children: /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)("div", { className: "animate-pulse", children: [
      /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("div", { className: "h-8 bg-gray-200 rounded mb-4" }),
      /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("div", { className: "h-64 bg-gray-200 rounded" })
    ] }) }) });
  }
  if (error || !application) {
    return /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("div", { className: "min-h-screen bg-yellow-50 py-12", children: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("div", { className: "max-w-4xl mx-auto px-4", children: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(Card, { className: "rounded-2xl shadow-lg", children: /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)(CardContent, { className: "p-8 text-center", children: [
      /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(AlertCircle, { className: "h-16 w-16 text-red-500 mx-auto mb-4" }),
      /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("h2", { className: "text-2xl font-bold text-gray-900 mb-2", children: intl.formatMessage({ id: "applicationStatus.noApplicationFound" }) }),
      /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("p", { className: "text-gray-600 mb-6", children: intl.formatMessage({ id: "applicationStatus.noApplicationDescription" }) }),
      /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(
        Button,
        {
          onClick: onNavigateToBecomeGuide,
          className: "bg-yellow-500 hover:bg-yellow-600 text-black",
          children: intl.formatMessage({ id: "applicationStatus.startApplication" })
        }
      )
    ] }) }) }) });
  }
  const statusInfo = getStatusInfo(application.applicationStatus);
  return /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("div", { className: "min-h-screen bg-yellow-50 py-12", children: /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)("div", { className: "max-w-4xl mx-auto px-4", children: [
    /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)("div", { className: "mb-8", children: [
      /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("h1", { className: "text-3xl font-bold text-gray-900 mb-2", children: intl.formatMessage({ id: "applicationStatus.title" }) }),
      /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("p", { className: "text-gray-600", children: intl.formatMessage({ id: "applicationStatus.subtitle" }) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)("div", { className: "space-y-6", children: [
      /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)(Card, { className: "rounded-2xl shadow-lg", children: [
        /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(CardHeader, { className: "bg-yellow-400 rounded-t-2xl", children: /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)(CardTitle, { className: "text-black flex items-center gap-3", children: [
          statusInfo.icon,
          intl.formatMessage({ id: "applicationStatus.statusTitle" })
        ] }) }),
        /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)(CardContent, { className: "p-6", children: [
          /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("div", { className: `p-4 rounded-lg border ${statusInfo.color} mb-4`, children: /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)("div", { children: [
              /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("h3", { className: "font-semibold text-lg", children: statusInfo.text }),
              /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("p", { className: "mt-1", children: statusInfo.description })
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)(Badge, { variant: "outline", className: "ml-4", children: [
              intl.formatMessage({ id: "applicationStatus.applicationId" }),
              ": ",
              application.id.substring(0, 8)
            ] })
          ] }) }),
          /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4 text-sm", children: [
            /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)("div", { children: [
              /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)("span", { className: "font-medium text-gray-700", children: [
                intl.formatMessage({ id: "applicationStatus.submittedAt" }),
                "\uFF1A"
              ] }),
              /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("span", { className: "text-gray-600", children: new Date(application.createdAt).toLocaleString("zh-CN") })
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)("div", { children: [
              /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)("span", { className: "font-medium text-gray-700", children: [
                intl.formatMessage({ id: "applicationStatus.lastUpdated" }),
                "\uFF1A"
              ] }),
              /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("span", { className: "text-gray-600", children: new Date(application.updatedAt).toLocaleString("zh-CN") })
            ] })
          ] })
        ] })
      ] }),
      application.applicationStatus !== "drafted" && /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)(Card, { className: "rounded-2xl shadow-lg", children: [
        /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)(CardTitle, { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(History, { className: "h-5 w-5" }),
          intl.formatMessage({ id: "applicationStatus.approvalHistory" })
        ] }) }),
        /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(CardContent, { className: "p-6", children: timelineLoading ? /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("div", { className: "animate-pulse", children: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("div", { className: "space-y-4", children: [1, 2, 3].map((i) => /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)("div", { className: "flex items-start space-x-4", children: [
          /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("div", { className: "w-12 h-12 bg-gray-200 rounded-full" }),
          /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)("div", { className: "flex-1 space-y-2", children: [
            /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("div", { className: "h-4 bg-gray-200 rounded w-1/3" }),
            /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("div", { className: "h-3 bg-gray-200 rounded w-2/3" })
          ] })
        ] }, i)) }) }) : timelineData?.timeline ? /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(
          ApprovalTimeline,
          {
            timeline: timelineData.timeline,
            CheckCircle,
            Clock,
            AlertCircle,
            XCircle,
            FileCheck: FileText,
            Upload
          }
        ) : /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("p", { className: "text-gray-500 text-center py-4", children: intl.formatMessage({ id: "applicationStatus.noApprovalHistory" }) }) })
      ] }),
      needsSupplementalMaterials() && application?.id && /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(
        SupplementalMaterialsUpload,
        {
          applicationId: application.id,
          onSubmitSuccess: handleSupplementalMaterialsSubmitted,
          Card,
          CardContent,
          CardHeader,
          CardTitle,
          Button,
          Textarea,
          Input,
          Label,
          Upload,
          FileText,
          X: XCircle,
          CheckCircle,
          onFileUpload,
          onSubmit: onSubmitSupplemental,
          onToast
        }
      ),
      application.applicationStatus !== "drafted" && /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)(Card, { className: "rounded-2xl shadow-lg", children: [
        /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)(CardTitle, { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(FileText, { className: "h-5 w-5" }),
          intl.formatMessage({ id: "applicationStatus.applicationDocuments" })
        ] }) }),
        /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)(CardContent, { className: "p-6", children: [
          isJustSubmitted && /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)("div", { className: "bg-green-50 border border-green-200 rounded-lg p-4 mb-4", children: [
            /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)("p", { className: "text-green-800 font-medium", children: [
              "\u{1F389} ",
              intl.formatMessage({ id: "applicationStatus.submissionSuccess" })
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("p", { className: "text-green-700 text-sm mt-1", children: intl.formatMessage({ id: "applicationStatus.downloadPDFInstruction" }) })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("p", { className: "text-gray-600 mb-4", children: intl.formatMessage({ id: "applicationStatus.pdfDescription" }) }),
          /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("div", { className: "flex justify-center", children: /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)(
            Button,
            {
              onClick: onDownloadPDF,
              className: "bg-blue-600 hover:bg-blue-700 text-black",
              children: [
                /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(Download, { className: "w-4 h-4 mr-2" }),
                intl.formatMessage({ id: "applicationStatus.downloadPDF" })
              ]
            }
          ) }),
          /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("p", { className: "text-center text-sm text-gray-500 mt-3", children: intl.formatMessage({ id: "applicationStatus.pdfArchived" }) })
        ] })
      ] }),
      application.applicationStatus === "needs_more_info" && application.notes && /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)(Card, { className: "rounded-2xl shadow-lg border-orange-200", children: [
        /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(CardHeader, { className: "bg-orange-50", children: /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)(CardTitle, { className: "text-orange-800 flex items-center gap-2", children: [
          /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(AlertCircle, { className: "h-5 w-5" }),
          intl.formatMessage({ id: "applicationStatus.supplementalMaterialsNeeded" })
        ] }) }),
        /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)(CardContent, { className: "p-6", children: [
          /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("div", { className: "bg-orange-50 border border-orange-200 rounded-lg p-4 mb-4", children: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("p", { className: "text-orange-800 whitespace-pre-line", children: application.notes }) }),
          /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)(Button, { className: "bg-orange-600 hover:bg-orange-700 text-black", children: [
            /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(Upload, { className: "h-4 w-4 mr-2" }),
            intl.formatMessage({ id: "applicationStatus.uploadSupplementalMaterials" })
          ] })
        ] })
      ] })
    ] })
  ] }) });
}

// src/hooks/useApprovalTimeline.ts
function useApprovalTimeline(applicationId) {
  return {
    data: void 0,
    isLoading: false,
    error: null,
    refetch: () => {
    }
  };
}

// src/hooks/useApplicationStatus.ts
function useApplicationStatus() {
  return {
    data: void 0,
    isLoading: false,
    error: null,
    refetch: () => {
    }
  };
}

// src/utils/applicationContinuation.ts
var resolveGuideApplicationContinuation = ({
  authenticated,
  hasGuideProfile = false,
  hasApplication = false,
  applicationStatus,
  hasLocalDraft = false
}) => {
  if (authenticated && hasGuideProfile) return "guide_home";
  if (authenticated && (hasApplication || applicationStatus)) {
    if (applicationStatus === "drafted") return "continue_server_draft";
    if (applicationStatus === "needs_more_info") return "continue_required_changes";
    return "view_status";
  }
  if (hasLocalDraft) return "continue_local_draft";
  return "start_application";
};
var isEditableGuideContinuation = (intent) => intent === "start_application" || intent === "continue_local_draft" || intent === "continue_server_draft" || intent === "continue_required_changes";

// src/components/ui/toast.tsx
var React2 = __toESM(require("react"));
var import_class_variance_authority = require("class-variance-authority");
var import_lucide_react3 = require("lucide-react");
var import_jsx_runtime14 = require("react/jsx-runtime");
var ToastProvider = React2.forwardRef(({ ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("div", { ref, ...props }));
ToastProvider.displayName = "ToastProvider";
var ToastViewport = React2.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(
  "div",
  {
    ref,
    className: `fixed top-4 right-4 z-[100] flex max-h-screen w-full flex-col-reverse gap-2 sm:flex-col md:max-w-[420px] ${className || ""}`,
    ...props
  }
));
ToastViewport.displayName = "ToastViewport";
var toastVariants = (0, import_class_variance_authority.cva)(
  "group pointer-events-auto relative flex w-full items-center justify-between space-x-4 overflow-hidden rounded-md border p-6 pr-8 shadow-lg transition-all data-[swipe=cancel]:translate-x-0 data-[swipe=end]:translate-x-[var(--radix-toast-swipe-end-x)] data-[swipe=move]:translate-x-[var(--radix-toast-swipe-move-x)] data-[swipe=move]:transition-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[wipe=end]:animate-out data-[state=closed]:fade-out-80 data-[state=closed]:slide-out-to-right-full data-[state=open]:slide-in-from-right-full",
  {
    variants: {
      variant: {
        default: "border bg-background text-foreground",
        destructive: "destructive group border-destructive bg-destructive text-destructive-foreground",
        success: "border-green-500 bg-green-500 text-white"
      }
    },
    defaultVariants: {
      variant: "default"
    }
  }
);
var Toast = React2.forwardRef(({ className, variant, onOpenChange, ...props }, ref) => {
  return /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(
    "div",
    {
      ref,
      className: toastVariants({ variant }) + (className ? ` ${className}` : ""),
      ...props
    }
  );
});
Toast.displayName = "Toast";
var ToastAction = React2.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(
  "button",
  {
    ref,
    className: `inline-flex h-8 shrink-0 items-center justify-center rounded-md border bg-transparent px-3 text-sm font-medium ring-offset-background transition-colors hover:bg-secondary focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 group-[.destructive]:border-muted/40 group-[.destructive]:hover:border-destructive/30 group-[.destructive]:hover:bg-destructive group-[.destructive]:hover:text-destructive-foreground group-[.destructive]:focus:ring-destructive ${className || ""}`,
    ...props
  }
));
ToastAction.displayName = "ToastAction";
var ToastClose = React2.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(
  "button",
  {
    ref,
    className: `absolute right-2 top-2 rounded-md p-1 text-foreground/50 opacity-0 transition-opacity hover:text-foreground focus:opacity-100 focus:outline-none focus:ring-2 group-hover:opacity-100 group-[.destructive]:text-red-300 group-[.destructive]:hover:text-red-50 group-[.destructive]:focus:ring-red-400 group-[.destructive]:focus:ring-offset-red-600 ${className || ""}`,
    "toast-close": "",
    ...props,
    children: /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_lucide_react3.X, { className: "h-4 w-4" })
  }
));
ToastClose.displayName = "ToastClose";
var ToastTitle = React2.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(
  "div",
  {
    ref,
    className: `text-base font-semibold ${className || ""}`,
    ...props
  }
));
ToastTitle.displayName = "ToastTitle";
var ToastDescription = React2.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(
  "div",
  {
    ref,
    className: `text-sm opacity-90 ${className || ""}`,
    ...props
  }
));
ToastDescription.displayName = "ToastDescription";

// src/hooks/use-toast.ts
var React3 = __toESM(require("react"));
var TOAST_LIMIT = 1;
var actionTypes = {
  ADD_TOAST: "ADD_TOAST",
  UPDATE_TOAST: "UPDATE_TOAST",
  DISMISS_TOAST: "DISMISS_TOAST",
  REMOVE_TOAST: "REMOVE_TOAST"
};
var count = 0;
function genId() {
  count = (count + 1) % Number.MAX_SAFE_INTEGER;
  return count.toString();
}
var toastTimeouts = /* @__PURE__ */ new Map();
var reducer = (state, action) => {
  switch (action.type) {
    case actionTypes.ADD_TOAST:
      return {
        ...state,
        toasts: [action.toast, ...state.toasts].slice(0, TOAST_LIMIT)
      };
    case actionTypes.UPDATE_TOAST:
      return {
        ...state,
        toasts: state.toasts.map(
          (t) => t.id === action.toast.id ? { ...t, ...action.toast } : t
        )
      };
    case actionTypes.DISMISS_TOAST: {
      const { toastId } = action;
      if (toastId) {
        const timeout = toastTimeouts.get(toastId);
        if (timeout) clearTimeout(timeout);
        toastTimeouts.set(
          toastId,
          setTimeout(() => {
            dispatch({
              type: actionTypes.REMOVE_TOAST,
              toastId
            });
          }, 100)
        );
      }
      return {
        ...state,
        toasts: state.toasts.map(
          (t) => t.id === toastId || toastId === void 0 ? {
            ...t,
            open: false
          } : t
        )
      };
    }
    case actionTypes.REMOVE_TOAST:
      if (action.toastId === void 0) {
        return {
          ...state,
          toasts: []
        };
      }
      return {
        ...state,
        toasts: state.toasts.filter((t) => t.id !== action.toastId)
      };
  }
};
var listeners = [];
var memoryState = { toasts: [] };
function dispatch(action) {
  memoryState = reducer(memoryState, action);
  listeners.forEach((listener) => {
    listener(memoryState);
  });
}
function toast({ ...props }) {
  const id = genId();
  const update = (props2) => dispatch({
    type: actionTypes.UPDATE_TOAST,
    toast: { ...props2, id }
  });
  const dismiss = () => dispatch({ type: actionTypes.DISMISS_TOAST, toastId: id });
  dispatch({
    type: actionTypes.ADD_TOAST,
    toast: {
      ...props,
      id,
      open: true,
      onOpenChange: (open) => {
        if (!open) dismiss();
      }
    }
  });
  return {
    id,
    dismiss,
    update
  };
}
function useToast() {
  const [state, setState] = React3.useState(memoryState);
  React3.useEffect(() => {
    listeners.push(setState);
    return () => {
      const index = listeners.indexOf(setState);
      if (index > -1) {
        listeners.splice(index, 1);
      }
    };
  }, []);
  return {
    ...state,
    toast,
    dismiss: (toastId) => dispatch({ type: actionTypes.DISMISS_TOAST, toastId })
  };
}

// src/components/ui/toaster.tsx
var React4 = __toESM(require("react"));
var import_react_dom = require("react-dom");
var import_jsx_runtime15 = require("react/jsx-runtime");
function Toaster() {
  const { toasts } = useToast();
  const [isMounted, setIsMounted] = React4.useState(false);
  React4.useEffect(() => {
    setIsMounted(true);
    return () => setIsMounted(false);
  }, []);
  return /* @__PURE__ */ (0, import_jsx_runtime15.jsxs)(ToastProvider, { children: [
    toasts.map(function({ id, title, description, action, ...props }) {
      return /* @__PURE__ */ (0, import_jsx_runtime15.jsxs)(Toast, { ...props, children: [
        /* @__PURE__ */ (0, import_jsx_runtime15.jsxs)("div", { className: "grid gap-1", children: [
          title && /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(ToastTitle, { children: title }),
          description && /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(ToastDescription, { children: description })
        ] }),
        action,
        /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(ToastClose, {})
      ] }, id);
    }),
    isMounted ? (0, import_react_dom.createPortal)(/* @__PURE__ */ (0, import_jsx_runtime15.jsx)(ToastViewport, {}), document.body) : null
  ] });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ANONYMOUS_DRAFT_STORAGE_KEY,
  ANONYMOUS_DRAFT_VERSION,
  ApplicationPreview,
  ApplicationStatus,
  ApprovalTimeline,
  CURRENCY_OPTIONS,
  DEFAULT_RESUME_PATH,
  FOUNDER_NOTE_READ_STORAGE_KEY,
  FounderNoteMail,
  GUIDE_APPLICATION_IDENTITY_INTENT_STORAGE_KEY,
  GuideForm,
  LEGACY_GUIDE_FORM_DRAFT_KEY,
  LEGACY_QUALIFICATION_FILES_KEY,
  MAX_AGE,
  MAX_DURATION,
  MAX_PEOPLE,
  MBTI_OPTIONS,
  MIN_AGE,
  MIN_DURATION,
  MIN_PEOPLE,
  PAGE_TITLES,
  POSTAL_CODE_REGEX,
  PrintAndSave,
  SCORE_EXPLANATIONS,
  SCORE_MAX,
  SCORE_MIN,
  SEX_OPTIONS,
  Step2SelfAssessment,
  Step3PersonalizedQuestions,
  SupplementalMaterialsUpload,
  TOTAL_PAGES,
  Toast,
  ToastAction,
  ToastClose,
  ToastDescription,
  ToastProvider,
  ToastTitle,
  ToastViewport,
  Toaster,
  clearAnonymousDraft,
  clearStagedQualificationFiles,
  convertCentsToYuan,
  convertYuanToCents,
  createAnonymousDraft,
  createGuideFormTranslator,
  defaultPDFOptions,
  downloadPDF,
  evaluationFormValuesFromStorage,
  evaluationStorageFieldsFromForm,
  formSchema,
  formatCurrency,
  formatPostalCode,
  generateAndDownloadPDF,
  generateAndUploadPDF,
  generateDownloadAndUploadPDF,
  generatePDFBlob,
  getAuthRedirectUrl,
  getMissingFieldMessageDescriptor,
  getResumePath,
  getStagedQualificationFile,
  getVerificationRedirectUrl,
  guideFormChineseMessages,
  guideFormEnglishMessages,
  hasVersionTwoEvaluationAnswers,
  indexedDbQualificationStorageAvailable,
  isAuthenticated,
  isEditableGuideContinuation,
  isEmailVerified,
  isValidPostalCode,
  listStagedQualificationFiles,
  loadAnonymousDraft,
  loadOrCreateAnonymousDraft,
  markAnonymousDraftConflict,
  markAnonymousDraftMigrated,
  markAnonymousDraftMigrating,
  markStagedQualificationFileUploaded,
  prepareEvaluationPayload,
  processDatabaseDataForForm,
  processFormDataForDatabase,
  removeStagedQualificationFile,
  resolveGuideApplicationContinuation,
  sanitizePostalCode,
  saveAnonymousDraft,
  serializeGuideSignupIntentRequest,
  stageQualificationFile,
  toast,
  uploadPDF,
  upsertAnonymousDraft,
  useApplicationStatus,
  useApprovalTimeline,
  useGuideForm,
  usePDFGeneration,
  useToast,
  validateEvaluationQuestions,
  validateFormCompleteness
});
